<?php

 include 'db.php';
  function make_rand($one, $two, $three) {
      $id = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 10);
      return $id;
  }
    
  if(isset($_POST['update_details'])) {
       
      $hotel_id      = $_SESSION['hotel_id'];
     
       $datetime   = date("Y-m-d H:i:s");
        $_FILES["image"]["name"];
        $uploadfile   = $_FILES["image"]["tmp_name"];
        $folder       = "logo/";
        $extension    = explode(".",$_FILES["image"]["name"])[1];
        
        if(strtoupper($extension) == "JPG" || strtoupper($extension) == "PNG" || strtoupper($extension) == "JPEG" || strtoupper($extension) == "GIF"){
          $rand_number   = make_rand($hotel_id, $datetime,rand(1000000,9999999));
          $new_name      = $hotel_id."_".$rand_number;
          move_uploaded_file($_FILES["image"]["tmp_name"], "$folder".$new_name.".".$extension);
        }

       $company_name  = $_POST['company_name'];
       $address       = $_POST['address'];
       $website_url   = $_POST['website_url'];
       $email         = $_POST['email'];
       $star_rating   = $_POST['star_rating'];
       $currency      = $_POST['currency'];
       $full_name     = $_POST['full_name'];
       $job_position  = $_POST['job_position'];
       $mobile_no1    = $_POST['mobile_no1'];
       $rooms         = $_POST['rooms'];
       $country       = $_POST['country'];
       $state         = $_POST['state'];
       $city          = $_POST['city'];
       $hotel_image   = $new_name.'.'.$extension;

       $update_hotel = "UPDATE hotel_signup SET company_name ='$company_name', address ='$address', website_url ='$website_url', hotel_image='$hotel_image',email ='$email', star_rating ='$star_rating', currency ='$currency', full_name ='$full_name', job_position ='$job_position' ,mobile_no1='$mobile_no1',rooms ='$rooms' WHERE hotel_id='$hotel_id'";
       $updated = $conn->query($update_hotel);

       if($updated){
           header("location:../edit-profile.php");
          $msg = "YOUR DETAILS UPDATED SUCCESSFULLY...!";
       }else{
         $msg_error = "Opps Somthing Went Wrong..!";
       }
   }
               
?>
