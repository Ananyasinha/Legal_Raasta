<?php
	error_reporting(0);
	session_start();

	$timezone 	= "Asia/Calcutta";
	date_default_timezone_set($timezone);
	$datetime 	= date('Y-m-d H:i:s');
	$date     	= date('Y-m-d');

/*
	$servername   = "166.62.28.120";
	$username 	  = "b2badmin";
	$password	  = "admin@b2b";
	$dbname       = "b2b_new";*/


	$servername   = "localhost";
	$username 	  = "root";
	$password	  = "";
	$dbname       = "b2b";

	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
	    die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully";
 
?>