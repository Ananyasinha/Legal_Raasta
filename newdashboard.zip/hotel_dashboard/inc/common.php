<?php 
error_reporting(0);
	include 'db.php';
	$ref = $_POST['ref'];

	switch ($ref) {
		case 'add_room_type':
		
			$hotel_id   = $_SESSION['hotel_id'];
			$room_type  = $_POST['room_type'];
			$user_id    = 123;

			if(empty($room_type)){
				$out = array(
					'success' => false,
					'message' => "Please Fill Category Name..!",
				);
			}

		    $insert 	= "INSERT INTO room_category VALUES(null,'$hotel_id','$user_id','$room_type')";
			$inserted   = $conn->query($insert);

			if($inserted){
				$select_id = "SELECT * FROM room_category WHERE hotel_id='$hotel_id'";
				$selected  = $conn->query($select_id);
				$row 	   = $selected->fetch_assoc();
				$id 	   = $row['room_id'];
				$room_type = $row['room_type'];

				$out       = array('success' => true,'room_type'=>$room_type,'room_id'=>$id);
			}else{
				$out = array(
					'success' => false,
					'message' => "oops somthing went wrong..!",
				);
			}
			echo json_encode($out);
		break;

		case 'image_box':
		
			$hotel_id   = $_SESSION['hotel_id'];
			$image_id   = $_POST['image_id'];

			$delete_image 	= "DELETE FROM `hotel_image_details` WHERE id='$image_id'";
			$deleted 	 	= $conn->query($delete_image);
			if($deleted){
				$out       = array('success' => true);
			}else{
				$out = array(
					'success' => false,
					'message' => "oops somthing went wrong..!",
				);
			}
			echo json_encode($out);
		break;

		case 'video_box':
		
			$hotel_id   = $_SESSION['hotel_id'];
			$video_id   = $_POST['video_id'];

			$delete_video	= "DELETE FROM `hotel_image_details` WHERE id='$video_id'";
			$deleted_video	 	= $conn->query($delete_video);
			if($deleted_video){
				$out       = array('success' => true);
			}else{
				$out = array(
					'success' => false,
					'message' => "oops somthing went wrong..!",
				);
			}
			echo json_encode($out);
		break;


		case 'add_form_data' :
		    $hotel_id           = $_SESSION['hotel_id'];
			$hotel_name         = $_SESSION['hotel_name'];
			$user_id            = "123";
			$datetime           = date("Y-m-d H:i:s");
			$description 		= $_POST['description'];
			$policies 			= $_POST['policies'];
			$hotel_policies     = $_POST['hotel_policies'];
			$check_in	        = $_POST['check_in'];
		    $check_out 	        = $_POST['check_out'];
			$mobile_no 			= $_POST['mobile_no'];
			$contact_no1 		= $_POST['contact_no1'];
			$mobile_no 			= $_POST['mobile_no'];
			$weburl 			= $_POST['weburl'];
			$email 				= $_POST['email'];
			$couple_friendly 	= $_POST['couple_friendly'];
			$hotel_facilities   = implode(',',$_POST['check_list']);
			$room_facilities    = implode(',',$_POST['room_facilities']);
			$roomArr 			= $_POST['roomArr'];
			$minPrice           = $_POST['minPrice'];
			$category_details 	= json_encode($roomArr);

			$check_hotel = "SELECT hotel_id FROM hotel_details WHERE h_id='$hotel_id'";
			$checked = $conn->query($check_hotel);

			if($checked->num_rows > 0) {
			  	$update  	= "UPDATE hotel_details SET h_id='$hotel_id',hotel_name='$hotel_name',description='$description',policies='$policies',hotel_policies= '$hotel_policies', check_in='$check_in',check_out ='$check_out', contact_no1='$contact_no1',mobile_no='$mobile_no',weburl='$weburl',email='$email',couple_friendly='$couple_friendly',category_details='$category_details',hotel_facilities='$hotel_facilities',room_facilities='$room_facilities',created_on='$datetime' WHERE h_id='$hotel_id'";
			  	$updated    = $conn->query($update);

			  	if($updated){
					$out  = array(
						'success' => true,
						'message'=>"Your Details Upated Successfully..!",
					);
				}else{
				    $out = array(
						'success' => false,
						'message' => "oops somthing went wrong..!",
					);
				}
			}else {
				 $insert  	= "INSERT INTO hotel_details(hotel_id,h_id,hotel_name,description,policies,hotel_policies,check_in,check_out,contact_no1,mobile_no,weburl,email,couple_friendly,category_details,hotel_facilities,room_facilities,created_on) VALUES ('','$hotel_id','$hotel_name','$description','$policies','$hotel_policies','$check_in','$check_out','$contact_no1','$mobile_no','$weburl','$email','$couple_friendly','$category_details','$hotel_facilities','$room_facilities','$datetime')";
				$inserted   = $conn->query($insert);

				if($inserted){
					$out  = array(
						'success' => true,
						'message'=>"Your Details Added Successfully..!",
					);
				}else{
				    $out = array(
						'success' => false,
						'message' => "oops somthing went wrong..!",
					);
				}
			}
			echo json_encode($out);
			 $update_price   = "UPDATE hotel_signup SET hotel_price = '$minPrice' WHERE hotel_id='$hotel_id'";
			 $updated_price  = $conn->query($update_price);

		break;


		case 'fetch_details':

			$hotel_id = $_SESSION['hotel_id'];
			$selectDetails    = "SELECT * FROM hotel_details WHERE h_id='$hotel_id'";
			$details       	  = $conn->query($selectDetails); 
			$row           	  = $details->fetch_assoc();
			$hotel_id      	  = $row['h_id'];
			$hotel_name       = $row['hotel_name'];
			$description      = $row['description'];
			$hotel_policies   = $row['hotel_policies'];
			$policies         = $row['policies'];
			$check_in         = $row['check_in'];
			$check_out        = $row['check_out'];
			$contact_no1      = $row['contact_no1'];
			$mobile_no        = $row['mobile_no'];
			$email      	  = $row['email'];
			$couple_friendly  = $row['couple_friendly'];
			$category_details = $row['category_details'];
			$hotel_facilities = $row['hotel_facilities'];
			$room_Facilities  = $row['room_Facilities'];
			$category_details = json_decode($category_details);

			echo json_encode(array('status'=>true,'categoriesDetails'=>$category_details,'hotel_id'=>$hotel_id,'hotel_name'=>$hotel_name,'description'=>$description,'hotel_policies'=>$hotel_policies,'policies'=>$policies,'check_in'=>$check_in,'check_out'=>$check_out,'$contact_no1'=>$contact_no1,'mobile_no'=>$mobile_no,'email'=>$email,'couple_friendly'=>$couple_friendly,'hotel_facilities'=>$hotel_facilities,'room_Facilities'=>$room_Facilities));

		break;

		default:
			echo "Oops an error occured!";
		break;
	}


/*
	function make_rand($one, $two, $three) {
      $id = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 10);
      return $id;
  }
    
  if(isset($_POST['update_details'])) {
       
      $hotel_id      = $_SESSION['hotel_id'];
     
       $datetime   = date("Y-m-d H:i:s");
        $_FILES["image"]["name"];
        $uploadfile   = $_FILES["image"]["tmp_name"];
        $folder       = "logo/";
        $extension    = explode(".",$_FILES["image"]["name"])[1];
        
        if(strtoupper($extension) == "JPG" || strtoupper($extension) == "PNG" || strtoupper($extension) == "JPEG" || strtoupper($extension) == "GIF"){
          $rand_number   = make_rand($hotel_id, $datetime,rand(1000000,9999999));
          $new_name      = $hotel_id."_".$rand_number;
          move_uploaded_file($_FILES["image"]["tmp_name"], "$folder".$new_name.".".$extension);
        }

       $company_name  = $_POST['company_name'];
       $address       = $_POST['address'];
       $website_url   = $_POST['website_url'];
       $email         = $_POST['email'];
       $star_rating   = $_POST['star_rating'];
       $currency      = $_POST['currency'];
       $full_name     = $_POST['full_name'];
       $job_position  = $_POST['job_position'];
       $mobile_no1    = $_POST['mobile_no1'];
       $rooms         = $_POST['rooms'];
       $country       = $_POST['country'];
       $state         = $_POST['state'];
       $city          = $_POST['city'];
       $hotel_image   = $new_name.'.'.$extension;

       $update_hotel = "UPDATE hotel_signup SET company_name ='$company_name', address ='$address', website_url ='$website_url', hotel_image='$hotel_image',email ='$email', star_rating ='$star_rating', currency ='$currency', full_name ='$full_name', job_position ='$job_position' ,mobile_no1='$mobile_no1',rooms ='$rooms' WHERE hotel_id='$hotel_id'";
       $updated = $conn->query($update_hotel);

       if($updated){
          $msg = "YOUR DETAILS UPDATED SUCCESSFULLY...!";
       }else{
         $msg_error = "Opps Somthing Went Wrong..!";
       }
   }*/
               
?>