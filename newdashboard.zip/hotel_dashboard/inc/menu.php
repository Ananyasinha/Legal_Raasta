<?php 
include 'inc/db.php';

  $hotel_id = $_SESSION['hotel_id'];
  $select   = "SELECT hotel_image FROM hotel_signup WHERE hotel_id ='$hotel_id'";
  $selected = $conn->query($select);

  if($selected){
    while($row = $selected->fetch_assoc()){
      $image   = $row['hotel_image'];
    }
  }
?>
<div class="wrapper">
  <div class="sidebar" data-color="rose" data-background-color="black" data-image="assets/img/sidebar-1.jpg">
    <div class="sidebar-wrapper">
      <div class="user">
          <div class="photo">
             <!--  <img src="assets/img/faces/avatar.jpg" /> -->
            <img src="logo/<?php echo $image;?>" />
          </div>

          <div class="user-info">
              <a data-toggle="collapse" href="#collapseExample" class="username">
                <span>
                  <b> PROFILE</b>
                <b class="caret"></b>
              </span>
              </a>
              <div class="collapse" id="collapseExample">
                  <ul class="nav">
                      <li class="nav-item">
                          <a class="nav-link" href="profile.php">
                              <span class="sidebar-mini"> MP </span>
                              <span class="sidebar-normal"> My Profile </span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="edit-profile.php">
                              <span class="sidebar-mini"> EP </span>
                              <span class="sidebar-normal"> Edit Profile </span>
                          </a>
                      </li>
                      <li class="nav-item">
                          <a class="nav-link" href="change-password.php">
                              <span class="sidebar-mini"> CP </span>
                              <span class="sidebar-normal"> Change Password </span>
                          </a>
                      </li>
                  </ul>
              </div>
          </div>
      </div>
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">
              <i class="material-icons">dashboard</i>
              <p> Dashboard </p>
          </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="update_profile.php">
                <i class="material-icons">dashboard </i>
                <p> Add More Details </p>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link" href="gallery.php">
                <i class="material-icons">image </i>
                <p> Create Gallery </p>
            </a>
        </li>
      </ul>
    </div>
  </div>

  <div class="main-panel">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-transparent  navbar-absolute fixed-top">
      <div class="container-fluid">
        <div class="navbar-wrapper">
            <div class="navbar-minimize">
                <button id="minimizeSidebar" class="btn btn-just-icon btn-white btn-fab btn-round">
                    <i class="material-icons text_align-center visible-on-sidebar-regular">more_vert</i>
                    <i class="material-icons design_bullet-list-67 visible-on-sidebar-mini">view_list</i>
                </button>
            </div>
            <a class="navbar-brand" href="index.php" style="font-weight:400">1 WAY HOTEL MANAGMENT SYSTEM</a>
        </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="sr-only">Toggle navigation</span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
            <span class="navbar-toggler-icon icon-bar"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" id="username" aria-expanded="false">
                     <i class="material-icons">person</i>
                    <p>
                      <span class="d-lg-none d-md-block">Account</span>
                    </p>
                    <span><?php echo $_SESSION['hotel_name'] ;?></span>
                </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="logout.php" id="userprofil" aria-expanded="false">
                <i class="material-icons">power_settings_new</i>
                  <p>
                    <span class="d-lg-none d-md-block">Account</span>
                  </p>
                  <span>LOGOUT</span>
                </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <!-- End Navbar -->
<script src="assets/js/core/jquery.min.js"></script>
<script>
 $(".nav a").each(function() {
    if ((window.location.pathname.indexOf($(this).attr('href'))) > -1) {
        $(this).parent().addClass('active');
        $('li a').removeClass("active");
    }
});
</script>