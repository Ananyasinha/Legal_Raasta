<!-- EDIT HOTEL BASIC DETAILS  -->
<?php
    include 'inc/header.php';
    include 'inc/db.php';

    if(empty($_SESSION['hotel_id'])){
      header('location:login.php');
    }
      
    $hotel_id = $_SESSION['hotel_id'];
    $data = mysqli_query($conn,"SELECT * FROM `hotel_signup`INNER JOIN countries ON hotel_signup.country = countries.id INNER JOIN states ON hotel_signup.state = states.id INNER JOIN cities ON hotel_signup.city = cities.id  WHERE `hotel_id`= '$hotel_id'");
    $rec  = mysqli_fetch_array($data);

 /* $data  = mysqli_query($conn,"SELECT * FROM `hotel_signup` WHERE `hotel_id`= 1");
  $rec   = mysqli_fetch_array($data);
*/

  function make_rand($one, $two, $three) {
      $id = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 10);
      return $id;
  }
    
  if(isset($_POST['update_details'])) {
       
     $hotel_id      = $_SESSION['hotel_id'];
     
       $datetime   = date("Y-m-d H:i:s");
        $_FILES["image"]["name"];
        $uploadfile   = $_FILES["image"]["tmp_name"];
        $folder       = "logo/";
        $extension    = explode(".",$_FILES["image"]["name"])[1];
        
        if(strtoupper($extension) == "JPG" || strtoupper($extension) == "PNG" || strtoupper($extension) == "JPEG" || strtoupper($extension) == "GIF"){
          $rand_number   = make_rand($hotel_id, $datetime,rand(1000000,9999999));
          $new_name      = $hotel_id."_".$rand_number;
          move_uploaded_file($_FILES["image"]["tmp_name"], "$folder".$new_name.".".$extension);
        }
          
       //$id ='1';
       $company_name  = $_POST['company_name'];
       $address       = $_POST['address'];
       $website_url   = $_POST['website_url'];
       $email         = $_POST['email'];
       $star_rating   = $_POST['star_rating'];
       $currency      = $_POST['currency'];
       $full_name     = $_POST['full_name'];
       $job_position  = $_POST['job_position'];
       $mobile_no1    = $_POST['mobile_no1'];
       $rooms         = $_POST['rooms'];
       $country       = $_POST['country'];
       $state         = $_POST['state'];
       $city          = $_POST['city'];
       $hotel_image   = $new_name.'.'.$extension;

       $update_hotel = "UPDATE hotel_signup SET company_name ='$company_name', address ='$address', website_url ='$website_url', hotel_image ='$hotel_image',email ='$email', star_rating ='$star_rating', currency ='$currency', full_name ='$full_name', job_position ='$job_position',mobile_no1='$mobile_no1',rooms ='$rooms' WHERE hotel_id='$hotel_id'";
       $updated = $conn->query($update_hotel);

       if($updated){
          header("location:edit-profile.php");
          $msg = "YOUR DETAILS UPDATED SUCCESSFULLY...!";
       }else{
         $msg_error = "Opps Somthing Went Wrong..!";
       }
   }

               
?>

<style type="text/css">
  .card .card-body .col-form-label, .card .card-body .label-on-right {
    padding: 16px 5px 0 0;
    text-align: center;
}

img.user-img.img-circle {
    width: 100%!important;
    height: 100%!important;
}
</style>


  <?php include 'inc/menu.php';?>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-10 ml-auto mr-auto">
          <div class="alert alert-dismissible alert-success" style="<?php if(!empty($mgs)){ echo "display:block"; }else {echo "display: none"; }?>">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong><?php echo $mgs;?></strong>.
          </div>

          <div class="alert alert-dismissible alert-danger" style="<?php if(!empty($msg_error)){ echo "display:block"; }else {echo "display: none"; }?>">
              <button type="button" class="close" data-dismiss="alert">&times;</button>
              <strong><?php echo $msg_error;?></strong>.
          </div>

          <form id="RangeValidation" class="form-horizontal" action="edit-profile.php" method="POST" enctype="multipart/form-data">
            <div class="card">
              <div class="card-header card-header-rose card-header-text">
                <div class="card-text">
                  <h4 class="card-title">EDIT HOTEL DETAILS</h4>
                </div>
              </div>

              <div class="card-body">
                <div class="hotelSignup">

                    <div class="row">
                      <label class="col-sm-4 col-form-label">Update Hotel Profile Image</label>
                      <div class="col-sm-4" style="margin-left: 8%;">
                        <div class="fileinput fileinput-new text-center" data-provides="fileinput">
                            <div class="fileinput-new thumbnail">
                             <!--  <img src="assets/img/image_placeholder.jpg" alt="..."> -->

                            <?php if(!empty($image)){ ?>
                                  <img src="logo/<?php echo $image;?>" class="user-img img-circle" alt="logo" style="width:120px; height:120px;">
                              <?php }else{ ?>
                                   <img src="assets/img/image_placeholder.jpg" class="user-img img-circle" alt="logo" style="width:120px; height:120px;"/>
                              <?php } ?> 
                            </div>
                            <div class="fileinput-preview fileinput-exists thumbnail"></div>

                            <div>
                                <span class="btn btn-rose btn-round btn-file">
                                    <span class="fileinput-new">Select image</span>
                                    <span class="fileinput-exists">Change</span>
                                    <input type="file" name="image" />
                                </span>
                                <a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Remove</a>
                            </div>
                        </div>
                      </div>
                    </div>


                    <div class="row">
                      <label class="col-sm-4 col-form-label"> Type</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="type" value="<?php echo $rec['register_type']; ?>" readonly/>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <label class="col-sm-4 col-form-label">Hotel Name</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="hotel_name" value="<?php echo $rec['hotel_name']; ?>" readonly/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Company Name</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="company_name" value="<?php echo $rec['company_name']; ?>" readonly/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Address</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="address" value="<?php echo $rec['address']; ?>" readonly/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Website URL</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="website_url" value="<?php echo $rec['website_url'];?>" placeholder="if yes then" readonly/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Email</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="email" value="<?php echo $rec['email']; ?>" readonly>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Star Rating</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control num" type="text" name="star_rating" maxlength="1" value="<?php echo $rec['star_rating'];?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Currency</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="text" name="currency" value="<?php echo $rec['currency']; ?>" readonly>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Full Name</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control pos" type="text" name="full_name" value="<?php echo $rec['full_name']; ?>" >
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Job Position</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control pos" type="text" name="job_position" value="<?php echo $rec['job_position']; ?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">Contact No.</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control" type="mobile_no1" name="mobile_no1" value="<?php echo $rec['mobile_no1']; ?>" readonly>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">No. of Room</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <input class="form-control num" type="text" name="rooms" value="<?php echo $rec['rooms']; ?>">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                    
                      <label class="col-sm-4 col-form-label">Country</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                        <select class="form-control" id="sel1" name="country" readonly="">
                          <option value=""><?php echo $rec['sortname']; ?>
                          <?php
                        //     $data = mysqli_query($con, "select name from `countries` inner join `hotel_signup` on `countries`.id = `hotel_signup`.country");
                        //       while ($rec = mysqli_fetch_array($data)) {
                        //   echo "<option value='$rec[id]'>$rec[name]</option>";
                        // }
                          ?> 
                        </option>
                        </select>
                      </div>
                      </div>
                    </div>
                    <div class="row">
                      
                     <?php 
                        $state_id = $rec['state']; 
                        $state = "SELECT name FROM states WHERE id ='$state_id'";
                        $row =  $conn->query($state);
                      ?>
                      <label class="col-sm-4 col-form-label">State</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                        <select class="form-control" id="sel1" name="state" readonly>
                          <option><?php echo $rec['name']; ?></option>
                        </select>
                      </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-4 col-form-label">City</label>
                      <div class="col-sm-6">
                        <div class="form-group">
                        <select class="form-control" id="sel1" data-style="btn select-with-transition" name="city" readonly>
                          <option value=""><?php echo $rec['name']; ?></option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <hr>
              <div class="card-footer ml-auto mr-auto">
                 <button type="submit" class="btn btn-rose" name="update_details">UPDATE</button> 
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
   
<?php include 'inc/footer.php';?>

<script type="text/javascript">
 $( document ).ready(function(){
  //restrict numbers
    $( ".pos" ).keypress(function(e) {
        var key = e.keyCode;
        if (key >= 48 && key <= 57) {
            e.preventDefault();
        }
    });

 //restrict alphabets
    $('.num').keypress(function(key) {
        if(key.charCode < 48 || key.charCode > 57) return false;
    });
});

</script>

