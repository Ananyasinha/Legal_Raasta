<?php
   include 'inc/db.php';
   
   if(empty($_SESSION['hotel_id'])){
     header('location:login.php');
   }

  if(isset($_POST['update_password'])){

    $password         = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    $email            = $_SESSION['email'];
    $id               = $_SESSION['hotel_id'];
    
    if($password != $confirm_password) {
        $msg= "password Does not match..!";
        echo "<script type='text/javascript'>alert('$msg');</script>";
    }else{
      $update_pass   = "UPDATE hotel_signup SET password ='$password' WHERE hotel_id='$id'";
      $updated  = $conn->query($update_pass);

      if($updated){
        $succes_mgs = 'your password updated succesfully...';
      }else{
        $msg = 'oops somthing went wrong..!';
      }
    }
  }


 include 'inc/header.php';
 ?>

<style type="text/css">
  .alert.alert-dismissible.alert-success {
    text-align: center;
}

.card .card-body {
    padding: 2.9375rem 20px !important;
}

.card {
    margin-top: 60px!important;
  }

  .card .card-category {
     margin-top: 0px!important;
}
</style>

 <?php include 'inc/menu.php';?>
  <div class="content">
      <div class="container">
          <div class="row">
            <div class="col-md-8">
              <div class="alert alert-dismissible alert-success" style="<?php if(!empty($succes_mgs)){ echo "display:block"; }else {echo "display: none"; }?>">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <strong><?php echo $succes_mgs;?></strong>.
              </div>

              <div class="card">
                  <div class="card-header card-header-rose card-header-icon">
                    <div class="card-icon">
                        <i class="material-icons">lock</i>
                      </div>
                      <h4 class="card-title">Change Password</h4>
                  </div>

                  <div class="card-body ">
                      <form class="form-horizontal" action="change-password.php" method="POST">
                         <div class="row">
                              <label class="col-md-3 col-form-label">New Password</label>
                              <div class="col-md-8">
                                  <div class="form-group">
                                      <input type="password" class="form-control pas" name="password"  id="new_password"  minlength="8" maxlength="20" onkeyup="CheckPasswordStrength(this.value)" required>
                                  </div>
                              </div>

                              <span id="password_strength" style="font-weight:bold;"></span>
                          </div>

                          <div class="row">
                              <label class="col-md-3 col-form-label">Confirm password</label>
                              <div class="col-md-8">
                                  <div class="form-group">
                                      <input type="password" class="form-control" name="confirm-password" id="confirm_password"  minlength="8" maxlength="20" required onChange="checkPasswordMatch();">
                                  </div>
                              </div>
                          </div>

                          <div class="row">
                              <label class="col-md-3"></label>
                                <span id="ptest" style="font-weight:bold;color:#9c27b0"></span>
                          </div>

                          <div class="card-footer">
                            <div class="row">
                                <div class="col-md-12">
                                  <button type="submit" class="btn btn-fill btn-rose" id="update_password" name="update_password">Update password</button>
                                    <button type="reset" data-tooltip="Reset"  class="btn btn-default">Reset</button>
                                </div>
                            </div>
                          </div>
                      </form>
                  </div>
              </div>
            </div>

            <div class="col-md-4">
                <div class="card card-profile">
                    <div class="card-avatar">
                        <a href="#pablo">
                           <i class="material-icons" style="font-size: 100px;padding: 10px;">lock</i>
                        </a>
                    </div>

                    <div class="card-body">
                      <!--   <h4 class="card-category text-gray" style="font-weight:400">Valid Password Rule:</h4> -->
                       <h4 class="card-title" style="font-weight:400">Valid Password Rule:</h4>
                        <p class="card-description">
                          <ul>
                            <li>Should contain minimum 8 characters </li>
                            <li>Should be alphanumeric </li>
                            <li>Should contain one special character - &^%$#@ </li>
                          </ul>
                        </p>
                      
                    </div>
                </div>
            </div> 
          </div>
      </div>
  </div>

<!--       
    </div>
</div>
 -->
<?php include 'inc/footer.php';?>

<script type="text/javascript">

/* var value = $(this).val();
  if ( value.length > 0 && value != "Default text" ) */

  function CheckPasswordStrength(password) 
  {
    var password_strength = document.getElementById("password_strength");
    if (password.length == 0) 
    {
      password_strength.innerHTML = "";
      return;
    }
    var regex = new Array();
    regex.push("[A-Z]"); 
    regex.push("[a-z]"); 
    regex.push("[0-9]"); 
    regex.push("[$@$!%*#?&]");
    var passed = 0;

    for (var i = 0; i < regex.length; i++) 
    {
      if(new RegExp(regex[i]).test(password)) 
      {
        passed++;
      }
    }
    if (passed > 2 && password.length > 8) 
    {
      passed++;
    }
    var color = "";
    var strength = "";
    switch (passed) 
    {
      case 0:
      case 1:
      strength = "Weak";
      color = "red";
      break;
      case 2:
      strength = "Good";
      color = "darkorange";
      break;
      case 3:
      case 4:
      strength = "Strong";
      color = "green";
      break;
      case 5:
      strength = "Very Strong";
      color = "darkgreen";
      break;
    }
    password_strength.innerHTML = strength;
    password_strength.style.color = color;
  }

  function checkPasswordMatch() {
    var password = $("#new_password").val();
    var confirmPassword = $("#confirm_password").val();
    $('#save').prop('disabled', true);

    if (password != confirmPassword){
      $("#ptest").html("Password do not match!");
        $("#update_password").attr("disabled", "disabled");
    }else{
      $("#ptest").html("Password match.");
        $("#update_password").removeAttr("disabled");
    }
  }

  $(document).ready(function () {
     $("#confirm_password").keyup(checkPasswordMatch);
  });





</script>
