<?php 
  include 'inc/header.php';
  include 'inc/db.php';

  if(empty($_SESSION['hotel_id'])){
    header('location:login.php');
  }

?>

<style type="text/css">
img {
    height: 80px;
    width: 100px;
    border: 1px solid;
    margin: 10px;
}

div#error_register {
    text-align: center;
}
.row.filed {
    margin-top: 20px;
}

p.cross {
    margin-top: -28px;
    float: right;
    cursor: pointer;
    font-weight: 600;
}

i.material-icons.new{
    background: rebeccapurple;
    cursor: pointer;
    color: #fff;
}

a.nav-link.active.show {
    background-color: #663399!important;
}


.nav-pills.nav-pills-warning .nav-item .nav-link.active{
  background-color: #663399!important;
}

span.red {
    color: red;
    font-size: 20px;
}
</style>


 <!--  <div class="wrapper">
 <div class="main-panel"> -->

<?php include 'inc/menu.php';?>

  <div class="content">
    <div class="container">
      <div id="error_register" class="alert alert-dismissible alert-success" style="display: none">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
      </div> 
      
     <!--  <div class="alert alert-dismissible alert-danger" style="<?php if(!empty($message)){ echo "display:block"; }else {echo "display: none"; }?>">
          <button type="button" class="close" data-dismiss="alert">&times;</button>
          <strong><?php echo $message;?></strong>.
      </div> -->

      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header card-header-icon card-header-rose">
              <div class="card-icon">
                  <i class="material-icons">perm_identity</i>
              </div>
              <h4 class="card-title">Add More Details - <small class="category">Complete your profile</small></h4>
            </div>
            <div class="card-body">
            <!--   <form action="upload.php" method="post"> -->

                <div class="row filed" style="margin-top:25px">
                  <label class="col-md-2 col-form-label">Hotel Description <span class="red"> * </span></label>
                  <div class="col-md-8">
                    <div class="form-group has-default">
                        <textarea class="form-control description" rows="5" name="description" maxlength="500" required=""></textarea>
                    </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Hotel Policies <span class="red"> * </span></label>
                    <div class="col-sm-1">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input policies" type="radio" name="policies" value="YES" id="yes_policy">
                              YES
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-1">
                       <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input policies" type="radio" name="policies" value="NO" id="no_policy">
                              NO
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row filed" id="policies" style="display:none; ">
                  <label class="col-md-2 col-form-label">Add Policies</label>
                  <div class="col-md-8">
                      <div class="form-group">
                          <textarea class="form-control hotel_policies" rows="5" name="hotel_policies" maxlength="1000"></textarea>
                      </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Check IN <span class="red"> * </span></label>
                  <div class="col-md-3">
                    <div class="form-group">
                      <input type="text" class="form-control check_in" name="check_in" required>
                    </div>
                  </div>

                   <label class="col-sm-1 col-form-label">Check Out <span class="red"> * </span></label>
                  <div class="col-md-4">
                    <div class="form-group">
                      <input type="text" class="form-control check_out" name="check_out" required>
                    </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Contact No <span class="red"> * </span></label>
                  <div class="col-md-3">
                    <div class="form-group">
                      <input type="text" class="form-control contact_no1 num" name="contact_no1" maxlength="11" required>
                    </div>
                  </div>

                  <label class="col-sm-1 col-form-label">Mobile. No</label>
                  <div class="col-md-4">
                    <div class="form-group">
                      <input type="text" class="form-control mobile_no num" name="mobile_no" maxlength="11">
                    </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Website URL <span class="red"> * </span></label>
                  <div class="col-md-8">
                    <div class="form-group">
                      <input type="text" class="form-control weburl" name="weburl">
                    </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Email <span class="red"> * </span></label>
                  <div class="col-md-8">
                    <div class="form-group">
                      <input type="email" class="form-control email" name="email" required>
                    </div>
                  </div>
                </div>

                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Couple Friendly <span class="red"> * </span></label>
                    <div class="col-sm-1">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input couple_friendly" type="radio" name="couple_friendly" value="YES">
                              YES
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-1">
                       <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input couple_friendly" type="radio" name="couple_friendly" value="NO">
                              NO
                              <span class="circle">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row filed">
                  <label class="col-md-2 col-form-label">Rooms <span class="red"> * </span></label>
                  <div class="col-md-5">
                    <select class="form-control list room_category" title="Select rooms" id="rooms" name="room_category">
                      <option>Select</option>
                       <?php
                           $data = mysqli_query($conn, "SELECT * FROM `room_category`");
                              while($rec = mysqli_fetch_array($data)) { ?>
                               <option data-id="<?php echo $rec['room_id']; ?>" value='<?php echo $rec['room_id']; ?>'><?php echo $rec['room_type'];?></option>
                            <?php }
                         ?> 
                      </select>
                  </div>

                  <label class="col-sm-2 col-form-label">Add New Room Category</label>
                  <div class="col-md-3">
                    <div class="form-group">
                      <div class="card-icon">
                        <a data-toggle="modal" data-target="#myModal"><span><i class="material-icons new">add</i></span></a>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="row deluxe">
                </div>

                <br>
                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Hotel Facilities</label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Free Wifi">
                               Free Wifi 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Free Breakfast">
                              Free Breakfast 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Free Cancelation">
                              Free Cancelation
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Airport Trasportation ">
                               Airport Trasportation 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Bar">
                               Bar 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Restaurant">
                               Restaurant
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Laundary Facilities">
                               Laundary Facilities 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="24-hour Front Desk">
                               24-hour Front Desk 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Travel Counter">
                               Travel Counter 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Lift">
                                Lift 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Room Services">
                              Room Services
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Parking">
                               Parking
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Swimming Pool">
                                 Swimming Pool
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Health Club">
                             Health Club 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input check_list" type="checkbox" name="check_list[]" value="Spa">
                              Spa
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <br>
                <div class="row filed">
                  <label class="col-sm-2 col-form-label">Room Facilities</label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Room Facilities">
                                Free Toiletries 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Bathtub or Shower">
                               Bathtub or Shower  
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Towels">
                               Towels
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Wardrobe / Closet">
                                 Wardrobe / Closet 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Tea / Coffee Maker">
                             Tea / Coffee Maker
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Air Conditioning">
                               Air Conditioning
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Ironing Facilities">
                               Ironing Facilities
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Bathroom">
                               Bathroom 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Telephone">
                              Telephone 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Flat-Screen Tv">
                                Flat-Screen Tv 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Satelite Channels">
                               Satelite Channels
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="News Paper">
                               News Paper 
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                <div class="row">
                  <label class="col-sm-2 col-form-label"></label>
                    <div class="col-sm-3">
                      <div class="form-check">
                          <label class="form-check-label">
                              <input class="form-check-input room_facilities" type="checkbox" name="room_facilities[]" value="Wake-Up Services">
                                 Wake-Up Services
                              <span class="form-check-sign">
                                  <span class="check"></span>
                              </span>
                          </label>
                      </div>
                    </div>
                </div>

                  <hr>
                  <button type="submit" class="btn btn-rose pull-right" id="update_profile" name="submit">Update Profile</button>
                  <div class="clearfix"></div>
             <!--  </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<!-- Modal -->
 <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <!-- Modal content-->
      <div class="modal-content" id="myModal1">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Add New Room Category</h4>
        </div>
        <div class="modal-body">
          <div class="row">
             <div class="col-md-12">
                 <div class="row filed room">
                 <label class="col-sm-3 col-form-label">Add New Category</label>
                 <div class="col-md-8">
                   <div class="form-group">
                     <input type="text" class="form-control" id="room" name="room_type" required="true">
                   </div>
                 </div>
               </div>
             </div>
           </div>
           <div class="modal-footer">
             <button type="button" class="btn btn-primary" id="add">Save</button>
           </div>
         </div>
      </div>
    </div>
  </div>

<!--   </div>
</div> -->

<?php include 'inc/footer.php';?>

<script>
  $("#update_profile").on('click',function(){
      var description     = $('.description').val();
      var policies        = $("input[name='policies']:checked").val();
      var hotel_policies  = $('.hotel_policies').val();
      var check_in        = $('.check_in').val();
      var check_out       = $('.check_out').val();
      var contact_no1     = $('.contact_no1').val();
      var mobile_no       = $('.mobile_no').val();
      var weburl          = $('.weburl').val();
      var email           = $('.email').val();
      var contact_no1     = $('.contact_no1').val();
      var mobile_no       = $('.mobile_no').val();  
      var couple_friendly = $("input[name='couple_friendly']:checked").val();
      
      var room_facilities = [];
      $('.room_facilities:checked').each(function(i){
        room_facilities[i] = $(this).val();
      });

      var check_list = [];
      $('.check_list:checked').each(function(i){
        check_list[i] = $(this).val();
      });

      var roomArr   = [];
      $(".deluxe").find('.main').each(function() {
        var roomsJson = {};
        $(this).find('input').each(function(){
          var className = $(this).attr('class');
          var value     = $(this).val();
          var class_id  = className.split(" ")[1];
          roomsJson[class_id] = value;
        });
        roomArr.push(roomsJson);
        console.log(roomArr);
      });

      var priceArr   = [];
      $(".deluxe").find('.price,.bf_price,.bf_lunch_price').each(function() {
        var value = $(this).val();
        priceArr.push(value);
      });

      var minPrice = Math.min.apply(null, priceArr);

      if(description == '' || policies =='' || check_in =='' || check_out=='' || contact_no1 =='' || weburl==''|| email==''|| couple_friendly ==''|| !description || !policies || !check_in || !check_out || !contact_no1 || !mobile_no || !weburl || !email || !couple_friendly){

        alert('Please Fill all required fields...!');
        return false;
      }else{
        var ref     = "add_form_data";
          $.ajax({
            url       : "inc/common.php",
            type      : "POST",
            dataType  : "JSON",
            data      : {
              ref                 : ref,
              description         : description,
              policies            : policies,
              hotel_policies      : hotel_policies,
              check_in            : check_in,
              check_out           : check_out,
              contact_no1         : contact_no1,
              mobile_no           : mobile_no,
              weburl              : weburl,
              email               : email,
              couple_friendly     : couple_friendly,
              room_facilities     : room_facilities,
              check_list          : check_list,
              roomArr             : roomArr,
              minPrice            : minPrice,
            }
          }).done(function(res){
              if(res.success){
                /*$('#error_register').show();
                $('#error_register').html(res.message);*/
                alert("Your Details Updated Succesfully...!");
                window.location.reload(true);
              }else{
              alert("Oops Somthing went wrong..!");
                window.location.reload(true);
              }
          });
      }
  });

</script>



<script>
  $(document).ready(function() {
      $('form').ajaxForm(function() {
          alert("Your Details Updated Succesfully...!");
          window.location.reload(true);
      });
  });

  function preview_image() {
      var total_file = document.getElementById("upload_file").files.length;
      for (var i = 0; i < total_file; i++) {
          $('#image_preview').append("<div class='col-md-3 img'><img src='" + URL.createObjectURL(event.target.files[i]) + "'></div>");
      }
  }
</script>

<script>

  $("#yes_policy").on('click',function() {
     $("#policies").show();
  });

   $("#no_policy").on('click',function() {
     $("#policies").hide();
  });


//add room category tab dynamicaly
  $('#rooms').on('change',function() {
    var room_id = $('#rooms :selected').val();
    var name    = $('#rooms :selected').text();

    if(room_id == "Select"){
       return false;
    }
    var lh= $('.deluxe').find('.room'+room_id);
    if(lh.length==0){

    $('.deluxe').append('<div class="col-md-9 ml-auto mr-auto main room'+room_id+'"><div class="card"><div class="card-header"><h4 class="card-title category_name1" name="category_name">'+name+'</h4><input type="hidden" class="form-control category_id" value="'+room_id+'"><input type="hidden" value="'+name+'" class="form-control category_name"><p value='+room_id+' class="cross" name="room_id">X</p></div> <div class="card-body"><ul class="nav nav-pills nav-pills-warning" role="tablist"><li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#link1'+room_id+'" role="tablist"> Room Only</a></li><li class="nav-item"><a class="nav-link" data-toggle="tab" href="#link2'+room_id+'" role="tablist"> With Breakfast</a></li><li class="nav-item"><a class="nav-link" data-toggle="tab" href="#link3'+room_id+'" role="tablist">With Breakfast & lunch</a></li></ul><div class="tab-content tab-space"><div class="tab-pane active" id="link1'+room_id+'"><div class="row filed"><label class="col-sm-2 col-form-label">Max Guest</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control max_guest num" name="max_guest"></div></div><label class="col-sm-2 col-form-label">Highlights</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control highlights" name="highlights"></div></div><label class="col-sm-1 col-form-label">Price</label> <div class="col-md-2"><div class="form-group"> <input type="text" class="form-control price" name="price"></div> </div></div></div><div class="tab-pane" id="link2'+room_id+'"><div class="row filed"><label class="col-sm-2 col-form-label">Max Guest</label> <div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_max_guest num" name="bf_max_guest"> </div></div><label class="col-sm-2 col-form-label">Highlights</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_highlights" name="bf_highlights"></div></div><label class="col-sm-1 col-form-label">Price</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_price" name="bf_price"></div></div></div></div><div class="tab-pane" id="link3'+room_id+'"> <div class="row filed"><label class="col-sm-2 col-form-label">Max Guest</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_lunch_max_guest num" name="bf_lunch_max_guest"></div></div><label class="col-sm-2 col-form-label">Highlights</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_lunch_highlights" name="bf_lunch_highlights"></div></div> <label class="col-sm-1 col-form-label">Price</label><div class="col-md-2"><div class="form-group"><input type="text" class="form-control bf_lunch_price" name="bf_lunch_price"></div></div></div></div></div></div></div></div>');
	 }
});


 // function to remove room category tab
  $('.deluxe').on('click','.cross',function(){
    $(this).parents('.main').remove();
  });


//add new room category
  $('#add').on('click',function() {
    var room_type = $('#room').val();
    if(room_type == ""){
      alert('Please Add Category Name..!');
      return false;
    }else{
      var ref   = "add_room_type";
      $.ajax({
        url       :"inc/common.php",
        type      :"POST",
        dataType  :"JSON",
        data :{
            ref      : ref,
            room_type: room_type
          }
      }).done(function(res){
        if(res.success){
          $("#myModal").modal("hide");
          var optionsVal = "";
          $.each(res,function(index,value){
            optionsVal += '<option value ='+value['room_id']+'>'+value['room_type']+'</option>';
          });
          
          //$('.list').html("");
          $('#list').html(optionsVal);
        }
      });
    }
    
  });


 //restrict alphabets
  $('.num').keypress(function(key) {
      if(key.charCode < 48 || key.charCode > 57) return false;
  });

/* $('.deluxe').keyup('.price', function() {
   var a = $(this).val();
      a =a
      .replace(/[^\d.]/g, '')             // numbers and decimals only
      .replace(/(^[\d]{2})[\d]/g, '$1')   // not more than 2 digits at the beginning
      .replace(/(\..*)\./g, '$1')         // decimal can't exist more than once
      .replace(/(\.[\d]{4})./g, '$1');    // not more than 4 digits after decimal
  });*/


</script>

