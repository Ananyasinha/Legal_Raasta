<?php 
    include 'inc/header.php'; 
    include "inc/db.php";

    if(empty($_SESSION['hotel_id'])){
        header('location:login.php');
    }
?>

<style type="text/css">
    .footer {
    padding: .9375rem 0;
    text-align: center;
    display: flex;
    margin-top: 24%!important;
</style>

<!-- <div class="wrapper">
     <div class="main-panel"> -->
        <!-- Navbar -->
<?php include 'inc/menu.php'; ?>

<!-- End Navbar -->
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <a href="profile.php">
                                    <div class="card card-stats">
                                        <div class="card-header card-header-warning card-header-icon">
                                            <div class="card-icon">
                                                <i class="material-icons">person</i>
                                            </div>
                                            <p class="card-category">My Profile</p>
                                            <h3 class="card-title"></h3>

                                            
                                        </div>
                                        <div class="card-footer">
                                            <!-- <div class="stats">
                                                <i class="material-icons text-danger">warning</i>
                                                <a href="#pablo"></a>
                                            </div> -->
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <a href="update_profile.php">
                                    <div class="card card-stats">
                                        <div class="card-header card-header-rose card-header-icon">
                                            <div class="card-icon">
                                                <i class="material-icons">equalizer</i>
                                            </div>
                                            <p class="card-category">Add More Details</p>
                                            <h3 class="card-title"></h3>
                                        </div>
                                        <div class="card-footer">
                                           <!--  <div class="stats">
                                                <i class="material-icons">local_offer</i> 
                                            </div> -->
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <a href="gallery.php">
                                    <div class="card card-stats">
                                        <div class="card-header card-header-success card-header-icon">
                                            <div class="card-icon">
                                                <i class="material-icons">store</i>
                                            </div>
                                            <p class="card-category">Create Gallery</p>
                                            <h3 class="card-title"></h3>
                                        </div>
                                        <div class="card-footer">
                                            <!-- <div class="stats">
                                                <i class="material-icons">date_range</i>
                                            </div> -->
                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>

                        <div class="row">
                        </div>
                    </div>
                </div>

                <footer class="footer ">
                    <div class="container">
                        <div class="copyright">
                            <p>Copyright &copy; <script>
                                document.write(new Date().getFullYear())
                            </script>  1wayy.com  All rights reserved.</p>
                            <!-- &copy;
                            <script>
                                document.write(new Date().getFullYear())
                            </script>, Copyright <a href="#" target="_blank">1 wayy.com</a>  All Rights Reserved. -->
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>
</div> 

<!--     </div>   
</div>  -->
<!-- end of wrapper -->
         
<?php include 'inc/footer.php';?>
