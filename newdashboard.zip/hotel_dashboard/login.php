<?php 
   include 'inc/db.php';
    
    if(!empty($_SESSION['hotel_id'])){
        header('location:index.php');
    }

    if(isset($_POST['login'])){

        $email     = $_POST['email'];
        $password  = $_POST['password'];

        if($email=='' || $password==''){
            $out = "All Fields are Required..!";
        }else{
            if(!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/",$email)){

                $out = 'Invalid Email Pattern';
            }else{  
                $check_login = "SELECT * FROM hotel_signup WHERE email='$email' AND password='$password'";
                $logged_in = $conn->query($check_login);
                if($logged_in->num_rows >0){
                    $select_id   = "SELECT * FROM hotel_signup WHERE email='$email'";
                    $selected_id = $conn->query($select_id);
                    $row         = $selected_id->fetch_assoc();
                    $id          = $row['hotel_id'];
                    $name        = $row['hotel_name'];
                    $email_id    = $row['email'];
                    $image       = $row['hotel_image'];

                    $activity    = "Logged In";
                    $user_id     = '1';

                    $_SESSION['session']    ="success";
                    $_SESSION['hotel_id']   = $id;
                    $_SESSION['hotel_name'] = $name;
                    $_SESSION['email']      = $email_id;
                    $_SESSION['hotel_image']= $image;

                    $log = "INSERT INTO logs VALUES(null,'$user_id ','$id','$name','$activity','$datetime')";
                    $logged = $conn->query($log);
                   
                    //$out1 = "Login successfully...!";
                    header("location:index.php");

                }else{
                    $out2 = 'Wrong Email And Password Combination..!';
                }
            }
        }       
    }

?>  

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" name="viewport" />
    <!-- Favicons -->
    <link rel="apple-touch-icon" href="../assets/img/apple-icon.png">
    <!-- <link rel="icon" href="assets/img/favicon.png"> -->
    <link href="assets/img/x-icon.png" rel="icon" type="image/x-icon">

    <title>
        User Dashboard
    </title>
    <link rel="canonical" href="https://www.creative-tim.com/product/material-dashboard-pro" />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" />

    <link rel="stylesheet" href="assets/css/material-dashboard.min790f.css?v=2.0.1">
</head>


<style type="text/css">
/* Large devices (laptops/desktops, 992px and up) */
@media only screen and (min-width: 992px) {
    .col-md-8.col-md-offset-3.mr-auto {
    margin-left: 15%;
    }

    .card.card-signup {
        width: 80%;
        margin-top: 10vh;
    }
    .mr-auto, .mx-auto {
        margin-right:0px !important;
    }

} 

div#error_register {
    width: 80%;
    text-align: center;
}


div#error_register1 {
    width: 80%;
    text-align: center;
}
</style>

<body>
    <div class="wrapper wrapper-full-page">
        <div class="page-header register-page header-filter" filter-color="black" style="background-image: url('assets/img/register.jpg'); background-size: cover; background-position: top center;">
            <div class="container">
                <div class="row">
                     
                    <div class="col-md-10 ml-auto mr-auto">
                        <div id="error_register" class="alert alert-dismissible alert-success" style="<?php if(!empty($out1)){ echo "display:block"; }else {echo "display: none"; }?>">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <strong><?php echo $out1;?></strong>.
                        </div>
              
                        <div id="error_register1"class="alert alert-dismissible alert-danger" style="<?php if(!empty($out2)){ echo "display:block"; }else {echo "display: none"; }?>">
                            <button type="button" class="close" data-dismiss="alert">&times;</button>
                            <strong><?php echo $out2;?></strong>.
                        </div>

                        <div class="card card-signup">
                            <h2 class="card-title text-center">LOG IN</h2>
                            <div class="card-body">
                                <div class="row">

                                    <div class="col-md-8 col-md-offset-3 mr-auto">
                                         <form method="post" action="login.php">
                                            <div class="form-group has-default">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                        <i class="material-icons">mail</i>
                                                    </span>
                                                    </div>
                                                    <input type="text" class="form-control" placeholder="Email..."  name="email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required="">
                                                </div>
                                            </div>
                                            <div class="form-group has-default">
                                                <div class="input-group">
                                                    <div class="input-group-prepend">
                                                        <span class="input-group-text">
                                                        <i class="material-icons">lock_outline</i>
                                                    </span>
                                                    </div>
                                                    <input type="password" placeholder="Password..." class="form-control" name="password" required="">
                                                </div>
                                            </div>
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                  <!--   <input class="form-check-input" type="checkbox" value="" checked="">
                                                    <span class="form-check-sign">
                                                    <span class="check"></span>
                                                    </span>
                                                    I agree to the -->
                                                    <a href="forget_password.php">Forget Password?</a>
                                                </label>
                                            </div> 
                                            <div class="text-center">

                                                <button class="btn btn-primary btn-round mt-4" name="login">LOG IN</button>
                                                <!-- <a href="" class="btn btn-primary btn-round mt-4" >LOG IN</a> -->
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

<!--   Core JS Files   -->
<script src="assets/js/core/jquery.min.js"></script>
<script src="assets/js/core/popper.min.js"></script>

<script type="text/javascript" src="assets/js/jquery.form.js"></script>

<script src="assets/js/bootstrap-material-design.min.js"></script>

<script src="assets/js/plugins/perfect-scrollbar.jquery.min.js"></script>

<!-- Material Kit Core initialisations of plugins and Bootstrap Material Design Library -->
<script src="assets/js/material-dashboard790f.js?v=2.0.1"></script>

</html>