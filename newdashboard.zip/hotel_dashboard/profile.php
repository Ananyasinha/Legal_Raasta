<?php
    include 'inc/header.php';
    include 'inc/db.php';

    if(empty($_SESSION['hotel_id'])){
      header('location:login.php');
    }
    
    $id = $_SESSION['hotel_id'];
    $data = mysqli_query($conn,"SELECT * FROM `hotel_signup`INNER JOIN countries ON hotel_signup.country = countries.id INNER JOIN states ON hotel_signup.state = states.id INNER JOIN cities ON hotel_signup.city = cities.id  WHERE `hotel_id`= '$id'");
    $rec  = mysqli_fetch_array($data);

        
   /* $data=mysqli_query($conn,"SELECT * FROM `hotel_signup` WHERE `hotel_id`= 1");
    $rec=mysqli_fetch_array($data);*/

?>

<style type="text/css">
  .card .card-body .col-form-label, .card .card-body .label-on-right {
    padding: 16px 5px 0 0;
    text-align: center;
}

a.card-title {
    float: right;
}

small.category {
    color: rebeccapurple;
}
</style>


<?php include 'inc/menu.php';?>

  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-10 ml-auto mr-auto">
          <form id="RangeValidation" class="form-horizontal" action="#" method="">
            <div class="card">
              <div class="card-header card-header-icon card-header-rose">
                  <div class="card-icon">
                      <h4 class="card-title" style="color:#fff;font-weight:400">HOTEL PROFILE</h4>
                  </div>
                  <h4 class="card-title"> <a class="card-title" href="edit-profile.php"><small class="category"><i class="material-icons">edit</i>Edit Hotel Profile </small></a></h4>
              </div>
              
              <div class="card-body">
                <div class="hotelSignup">
                  <div class="row">
                    <label class="col-sm-4 col-form-label"> Type</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="min_length" value="<?php echo $rec['register_type']; ?>" disabled/>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <label class="col-sm-4 col-form-label">Hotel Name</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="min_length" value="<?php echo $rec['hotel_name']; ?>" disabled/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Company Name</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max_length" 
                        value="<?php echo $rec['company_name']; ?>" disabled/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Address</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="range" 
                        value="<?php echo $rec['address']; ?>" disabled/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Website URL</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="min" 
                        value="<?php echo $rec['website_url']; ?>" placeholder="if yes then" disabled/>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Email</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['email']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Star Rating</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['star_rating']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Currency</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['currency']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Full Name</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['full_name']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Job Position</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['job_position']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Contact No.</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['mobile_no1']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">No. of Room</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                        <input class="form-control" type="text" name="max" value="<?php echo $rec['rooms']; ?>" disabled>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">Country</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                      <select class="form-control" id="sel1" disabled>
                        <option value=""><?php echo $rec['sortname']; ?>
                        <?php
                      //     $data = mysqli_query($con, "select name from `countries` inner join `hotel_signup` on `countries`.id = `hotel_signup`.country");
                      //       while ($rec = mysqli_fetch_array($data)) {
                      //   echo "<option value='$rec[id]'>$rec[name]</option>";
                      // }
                        ?> 
                      </option>
                      </select>
                    </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">State</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                      <select class="form-control" id="sel1" disabled>
                        <option><?php echo $rec['name']; ?></option>
                      </select>
                    </div>
                    </div>
                  </div>
                  <div class="row">
                    <label class="col-sm-4 col-form-label">City</label>
                    <div class="col-sm-6">
                      <div class="form-group">
                      <select class="form-control" id="sel1" data-style="btn select-with-transition" disabled>
                        <option value=""><?php echo $rec['name']; ?></option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

                <!-- <div class="patenerSignup" style="display:none">
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Patner Name</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="min_length"/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Company Name</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max_length"/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Address</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="range"/>
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Website URL</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="min" placeholder="if yes then" />
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Email</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Star Rating</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Currency</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Full Name</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Job Position</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Contact No.</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">No. of Room</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                          <input class="form-control" type="text" name="max">
                        </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">Country</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                        <select class="form-control" id="sel1">
                          <option>Select Country</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                      </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">State</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                        <select class="form-control" id="sel1">
                          <option>Select State</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                      </div>
                      </div>
                    </div>
                    <div class="row">
                      <label class="col-sm-2 col-form-label">City</label>
                      <div class="col-sm-8">
                        <div class="form-group">
                        <select class="form-control" id="sel1" data-style="btn select-with-transition">
                          <option>Select City</option>
                          <option>2</option>
                          <option>3</option>
                          <option>4</option>
                        </select>
                      </div>
                      </div>
                    </div>
                </div> -->

  
              </div>
              <div class="card-footer ml-auto mr-auto">
                <!-- <button type="submit" class="btn btn-rose">Save</button> -->
              </div>
            </div>
          </form>
      </div>
  </div>
</div>

<?php include 'inc/footer.php';?>