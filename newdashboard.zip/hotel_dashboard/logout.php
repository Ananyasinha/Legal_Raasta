<?php 
	session_start();
	$email_id 	= $_SESSION['email'];
	$id 		= $_SESSION['hotel_id'];
	$name       = $_SESSION['hotel_name'];
	session_destroy();
	header("location:login.php")
?>