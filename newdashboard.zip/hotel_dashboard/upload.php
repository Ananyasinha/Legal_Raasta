<?php 
  include 'inc/db.php';

    function make_rand($one, $two, $three) {
      $id = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 10);
      return $id;
  }

 if(isset($_POST['submit'])){

    $hotel_id           = $_SESSION['hotel_id'];
    $name               = $_SESSION['hotel_name'];

    $user_id            = "123";
    $datetime           = date("Y-m-d H:i:s");

    $hotel_description  = $_POST['description'];
    $hotel_policies     = $_POST['policies'];
    $policies           = $_POST['hotel_policies'];
    $check_in           = $_POST['check_in'];
    $check_out          = $_POST['check_out'];
    $contact_no         = $_POST['contact_no1'];
    $mobile_no          = $_POST['mobile_no'];
    $weburl             = $_POST['weburl'];
    $email              = $_POST['email'];
    $couple_friendly    = $_POST['couple_friendly'];
    $hotel_facilities   = implode(',' , $_POST['check_list']);
    $room_facilities    = implode(',' , $_POST['room_facilities']);
    $rooms_name    = $_POST['room_category'];
    $room_id            = $_POST['room_id'];


   // count($rooms_name);
    for($i = 0; $i <count($rooms_name); $i++){

      $room_name          = $_POST['category_name']."<br>";
      
      $max_guest          = $_POST['max_guest']."<br>";
      $highlights         = $_POST['highlights']."<br>";
      $price              = $_POST['price']."<br>";
      
      $bf_max_guest       = $_POST['bf_max_guest']."<br>";
      $bf_highlights      = $_POST['bf_highlights']."<br>";
      $bf_price           = $_POST['bf_price']."<br>";

      $bf_lunch_max_guest  = $_POST['bf_lunch_max_guest']."<br>";
      $bf_lunch_highlights = $_POST['bf_lunch_highlights']."<br>";
      $bf_lunch_price      = $_POST['bf_lunch_price']."<br>";
      

      /*$insert1  = "INSERT INTO hotel_room_details (hotel_id,user_id,room_name,room_only,max_guest ,images,highlights,price,with_breakfast,bf_max_guest,bf_highlights,bf_price,bf_lunch,bf_lunch_max_guest,bf_lunch_highlights,bf_lunch_price) VALUES('$hotel_id',$user_id','$room_name','$room_only','$max_guest','$highlights','$price','$with_breakfast','$bf_max_guest','$bf_highlights','$bf_price','$bf_lunch','$bf_lunch_max_guest','$bf_lunch_highlights','$bf_lunch_price')";
      $inserted1 = $conn->query($insert1);*/
    }


    die('asdasdasd');


    $check_hotel  = "SELECT hotel_id FROM hotel_details WHERE hotel_id='$hotel_id'";
    $checked     = $conn->query($check_hotel);

    if($checked->num_rows > 0){
      $update  = "UPDATE hotel_details SET hotel_id ='$hotel_id', hotel_name ='$name',hotel_description ='$hotel_description',hotel_policies ='$hotel_policies',policies ='$policies', couple_friendly ='$couple_friendly',room_type ='$room_type',room_category='$room_category',hotel_facilities='$hotel_facilities', room_facilities='$room_facilities',created_on='$datetime' WHERE hotel_id='$hotel_id'";
      $updated   = $conn->query($update);

    }else{

      $insert  = "INSERT INTO hotel_details VALUES (null,'$hotel_name','$hotel_description','$hotel_policies','$couple_friendly','$room_type','$room_category','$hotel_facilities','$room_facilities','$datetime')";
      
      $inserted = $conn->query($insert);
      count($room_id);
      for($i = 0; $i <count($room_id); $i++){

        $room_name          = $_POST['category_name']."<br>";
        
        $max_guest          = $_POST['max_guest']."<br>";
        $highlights         = $_POST['highlights']."<br>";
        $price              = $_POST['price']."<br>";
        
        $bf_max_guest       = $_POST['bf_max_guest']."<br>";
        $bf_highlights      = $_POST['bf_highlights']."<br>";
        $bf_price           = $_POST['bf_price']."<br>";

        $bf_lunch_max_guest  = $_POST['bf_lunch_max_guest']."<br>";
        $bf_lunch_highlights = $_POST['bf_lunch_highlights']."<br>";
        $bf_lunch_price      = $_POST['bf_lunch_price']."<br>";
        

        /*$insert1  = "INSERT INTO hotel_room_details (hotel_id,user_id,room_name,room_only,max_guest ,images,highlights,price,with_breakfast,bf_max_guest,bf_highlights,bf_price,bf_lunch,bf_lunch_max_guest,bf_lunch_highlights,bf_lunch_price) VALUES('$hotel_id',$user_id','$room_name','$room_only','$max_guest','$highlights','$price','$with_breakfast','$bf_max_guest','$bf_highlights','$bf_price','$bf_lunch','$bf_lunch_max_guest','$bf_lunch_highlights','$bf_lunch_price')";
        $inserted1 = $conn->query($insert1);*/
      }
    
     //exit();

      if($inserted1){
         //header("location:update_profile.php");
          $succesmsg = "Your Details Updated Succesfully...!";
        }else{
        $message = 'opps somthing went wrong...!';
      }
    }
  }
  
?>

