<?php 
	session_start();
	if(!empty($_SESSION['email'])) {
		header('location:/');
	}
	include 'inc/header.php';
?>
	<style type="text/css">
		.bootstrap-select{
			margin-left: -10px !important;
			width:101% !important; 
		}
	</style>
	<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=AIzaSyDu938CDvMulD5wTTOwTIrFzROmgyQx8G0&&libraries=places"></script>
    <script type="text/javascript">
    google.maps.event.addDomListener(window, 'load', function () {
        var places = new google.maps.places.Autocomplete(document.getElementById('address'));
        google.maps.event.addListener(places, 'place_changed', function () {
            var place = places.getPlace();
            var address = place.formatted_address;
            var latitude = place.geometry.location.lat();
            var longitude = place.geometry.location.lng();
            var details = "Address: " + address;
            details += "\nLatitude: " + latitude;
            details += "\nLongitude: " + longitude;
            // alert(details);
        });
    });
    </script>
	<div class="page-header header-filter" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	    	<div class="container">
				<div class="row">
	    			<div class="col-md-10 col-md-offset-1">
						<div class="card card-signup">
	                        <h2 class="card-title text-center">S'inscrire</h2>
	                        <div class="row">
	                            <div class="col-md-10 col-md-offset-1">
	                            		<div id="error_register" class="alert alert-dismissible" style="margin-bottom: 50px"></div>
										<div class="card-content" style="margin-top:-62px">
											<div class="row">
												<div class="col-md-6">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="material-icons" style="margin-top:12px">face</i>
														</span>
														<input type="text" class="form-control registerfirstname reg-details" placeholder="prénom">
													</div>
												</div>
												<div class="col-md-6">
													<input type="text" class="form-control registerlastname reg-details" placeholder="nom de famille">
												</div>
											</div>
												
											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">add_location</i>
												</span>
												<input type="text" class="form-control registeraddress reg-details" placeholder="adresse" id="address">
											</div>

											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">email</i>
												</span>
												<input type="text" class="form-control registermail reg-details" placeholder="EMAIL">
											</div>

											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">lock_outline</i>
												</span>
												<input type="password" placeholder="mot de passe" class="form-control registerpass reg-details" />
											</div>
											
											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">lock_outline</i>
												</span>
												<input type="password" placeholder="Confirmez le mot de passe" class="form-control registercnfpass reg-details" />
											</div>
											
											<div class="row" style="margin-top: 10px">
												<div class="col-md-1">
													<div class="input-group" style="margin-top:10px">
														<span class="input-group-addon">
															<i class="material-icons">people</i>
														</span>
													</div>		
												</div>
												<div class="col-md-11">
													<select id="registerusertype" class="selectpicker reg-details" data-style="select-with-transition" title="sélectionnez le type d'utilisateur" data-size="7">
														<option disabled> sélectionnez le type d'utilisateur</option>
														<option value="seeker">chercheur</option>
														<option value="supplier">fournisseur</option>
													</select>
												</div>
											</div>	

											<div class="checkbox">
												<label>
													<input type="checkbox" name="optionsCheckboxes" class="registerterm" checked="checked" disabled="disabled">
													J'accepte les <a target="_blank" href="termsofuse.php">termes et conditions</a>.
												</label>
											</div>
										</div>
										<div class="footer text-center">
											<a class="btn btn-primary btn-round" id="register">S'inscrire</a>
										</div>
	                            </div>
	                        </div>
	                	</div>

	                </div>
	            </div>
			</div>
<?php include 'inc/footer.php'; ?>
