<?php include 'inc/header.php'; ?>
<style type="text/css">
    .select-with-transition {background-image:none !important;}
</style>
<div class="page-header header-filter clear-filter" data-parallax="true" style="background-image: url('assets/img/wall1.jpg');height: 60vh;">
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="brand">
                    <div class="text-center"><img src="assets/img/fulllogo.png" style="margin-top:-70px;height: 80px;"></div>
                    <h3 class="title">Land of Sands</h3>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="main main-raised">
    <div class="section section-basic" style="box-shadow:0px 1px 0px 0px #e0e0e0">
        <div class="container-fluid">
            <h3 class="section-title text-center" style="margin-top:-30px;margin-bottom: 50px;font-weight:400">LOCALISER UNE OFFRE</h3>
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-raised card-form-horizontal">

                        <div class="card-content" style="margin-top:10px">
                            <div class="row">
                                <div class="col-md-2">
                                    <button type="button" class="btn sand_buttons" style="background-color:#ff793f">REMBLAIEMENT</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn sand_buttons" style="background-color:#ff793f">DEBLAIEMENT</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn sand_buttons" style="background-color:#ff793f">ARABLE</button>
                                </div>
                                <div class="col-md-2">
                                    <button type="button" class="btn sand_buttons" style="background-color:#ff793f">INERTE</button>
                                </div>
                                <div class="col-md-4">
                                    <a target="_blank" href="construction-listings.php">
                                    <button type="button" class="btn btn-primary pull-right" style="background-color:#ff793f">besoin de matériaux de construction ?</button>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <hr style="margin-bottom: 0">
                        <div class="card-content">
                            <form method="" action="#">
                                <div class="row text-center" id="filtersdiv" style="display: inline-flex;float: none">
                                    <div class="col-sm-2">
                                        <div class="input-group" style="width:130px;margin-top:-8px">
                                            <div class="form-group is-empty">
                                                <select class="selectpicker sand_region form-control" data-style="select-with-transition" name="region" title="REGION" data-size="12">
                                                    <!-- <option disabled> Region</option> -->
                                                    <option value="anvers">ANVERS</option>
                                                    <option value="brabant_wallon">BRABANT WALLON</option>
                                                    <option value="brabant_flamand">BRABANT FLAMAND</option>
                                                    <option value="bruxelles">BRUXELLES</option>
                                                    <option value="flandre_occ">FLANDRE_OCC</option>
                                                    <option value="flandre_orie">FLANDRE_ORIE</option>
                                                    <option value="hainaut">HAINAUT</option>
                                                    <option value="limbourg">LIMBOURG</option>
                                                    <option value="liege">LIEGE</option>
                                                    <option value="luxembourg">LUXEMBOURG</option>
                                                    <option value="NAMUR">NAMUR</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-2" style="margin-left:10px">
                                        <div class="input-group">
                                            <div class="form-group is-empty"><input type="text" name="postal_code" placeholder="CODE POSTAL" class="form-control" onkeypress="return numbersonly(this,event)"><span class="material-input"></span><span class="material-input"></span></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-2" style="margin-left:10px">
                                        <div class="input-group" style="width:130px;margin-top:-8px">
                                            <div class="form-group is-empty">
                                                <select class="selectpicker type_of_sand form-control" data-style="select-with-transition" name="type_of_sand" title="Type de sable" data-size="7">
                                                    <!-- <option disabled> TYPE OF SAND</option> -->
                                                    <option value="remblaiement">REMBLAIEMENT</option>
                                                    <option value="deblaiement">DÉBLAIEMENT</option>
                                                    <option value="arable">ARABLE</option>
                                                    <option value="inerte">INERTE</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-2" style="margin-left:10px">
                                        <div class="input-group" style="width:130px;margin-top:-8px">
                                            <div class="form-group is-empty">
                                                <select class="selectpicker volume form-control" data-style="select-with-transition" name="volume" title="LE VOLUME" data-size="12">
                                                    <!-- <option disabled> Volume</option> -->
                                                    <option value="plus">Plus</option>
                                                    <option value="81_210">81 cu. m. - 210 cu. m.</option>
                                                    <option value="41_80">41 cu. m. - 80 cu. m.</option>
                                                    <option value="10_40">10 cu. m. - 40 cu. m.</option>
                                                    <option value="moins">Moins</option>
                                                </select>
                                            </div>    
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="input-group">
                                            <div class="form-group is-empty">
                                                <input type="text" name="trans_cost" placeholder="COÛT DE TRANSPORT" class="form-control" onkeypress="return numbersonly(this,event)"><span class="material-input"></span><span class="material-input"></span></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-2">
                                        <div class="input-group">
                                            <div class="form-group is-empty">
                                                <input type="text" name="price" placeholder="PRIX" class="form-control" onkeypress="return numbersonly(this,event)"><span class="material-input"></span><span class="material-input"></span></div>
                                        </div>
                                    </div>
                                    <div class="col-sm-2" style="margin-left:10px">
                                        <button type="button" class="btn" id="filter" style="background-color:#f39c12">Filtre</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div id="map-google" class="map" style="box-shadow:0px 0px 0px 1px #e0e0e0;height:500px;margin-top:-25px"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="section-basic text-center" style="margin-top: -47px;font-size: 23px;font-weight:400;">
        <a target="_blank" href="construction-listings.php">besoin de matériaux de construction? cliquez ici</a>
    </div>
    <div class="section section-basic" style="margin-top: 25px">
        <div class="container">
            <h3 class="section-title text-center" style="margin-top:-10px;font-weight:400;margin-bottom:50px">Résultats</h3>
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <?php
                            include 'inc/db.php';
                            $select_posts   = "SELECT * FROM sand_posts ORDER BY id DESC";
                            $selected_posts = $conn->query($select_posts);
                            if($selected_posts->num_rows != 0){   
                        ?>
                        <?php    
                                $i = 0;
                                while($row = $selected_posts->fetch_assoc()){
                        ?>
                                    <div class="col-md-3" style="box-shadow:0px 0px 1px 1px #e0e0e0;margin-bottom:30px;">
                                            <div class="card-image" style="border-radius:20px 20px 20px 20px;overflow: hidden;box-shadow:0px 0px 1px 1px #000;margin-top:20px">
                                                <?php if(!empty($row['post_image'])){ ?>
                                                    <img src="<?php echo "posts/".$row['post_image'];?>" alt="<?php echo $row['type_of_sand'];?>" style="width:300px;height:250px"/>
                                                <?php }else{?>
                                                    <img src="assets/img/sandicon.png" alt="<?php echo $row['type_of_sand'];?>" style="width:300px;height:250px"/>
                                                <?php } ?>    
                                            </div>
                                            <div class="card-content">
                                                <h4 class="card-title text-center" style="cursor: pointer">
                                                    <?php echo strtoupper($row['type_of_sand']);?>
                                                </h4>
                                                <p class="description">
                                                    <b>ADRESSE :</b> <?php echo ucfirst($row['address_build']).' '.ucfirst($row['region']).' '.ucfirst($row['postal_code']); ?>
                                                    
                                                </p>
                                                <p class="description">
                                                    <b>LE VOLUME :</b> <?php echo $row['volume']; ?>
                                                </p>
                                                <p class="description">
                                                    <b>COÛT DE TRANSPORT :</b> <?php echo $row['trans_cost']; ?>
                                                </p>
                                                <p class="description">
                                                    <b>DATE DE DISPONIBILITÉ :</b> <?php echo $row['date_avail']; ?>
                                                </p>
                                                <div class="footer">
                                                    <p class="description">
                                                        <b>PRIX</b>  &euro; <?php echo $row['price'];?>
                                                    </p>
                                                </div>
                                                <center>
                                                    <a target="_blank" href='sand_details.php?sand_id=<?php echo $row['id']; ?>'>
                                                        <h6 style="color:#0099ff;cursor:pointer">Plus de details</h6>
                                                    </a>
                                                </center>
                                            </div>
                                        <!-- </div> -->
                                    </div>
                        <?php
                                }
                        ?>
                        <?php          
                            }else{
                        ?>
                            <div class="col-md-12">
                                <center style="margin-top:40px"><img src="assets/img/not_found.png"></center>
                                <center><h3 style="margin-left:-40px">No Deal Found</h3></center>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>
