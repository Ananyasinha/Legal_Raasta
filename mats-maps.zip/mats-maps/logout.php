<?php 
	session_start();
	$email_id 	= $_SESSION['email'];
	$id 		= $_SESSION['id'];
	$firstname  = $_SESSION['firstname'];
	$usertype 	= $_SESSION['usertype'];
	session_destroy();
	header("location:/")
?>