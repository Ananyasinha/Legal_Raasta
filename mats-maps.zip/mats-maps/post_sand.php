<?php 
	session_start();

	if($_SESSION['usertype'] != "supplier") {
		header("location:/");
	}
	include 'inc/header.php'; 
	include 'inc/db.php';

?>

<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
    <div class="container">
        <div class="row title-row">
            <div class="col-md-4 col-md-offset-8">
				<button id="add_sand_post_sand" class="btn btn-white pull-right" data-toggle="modal" data-target="#postModal"><i class="material-icons">add_to_photos</i> &nbspAdd Sand</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Core -->
<div class="modal fade" id="postModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width:65%">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel" style="font-size:20px;font-weight:600">DÉTAILS POST-SABLE</h4>
      </div>
      <div class="modal-body">
      		<div class="row">
      			<div class="col-md-12">
		        	<div class="form-group">
						<label class="control-label">ADRESSE</label>
						<input type="text" class="form-control address" id="address_auto">
					</div>
				</div>
			</div>
			<div class="row">
      			<div class="col-md-12">
      				<div id="map" style="width: 100%; height: 300px;"></div>
      			</div>
      		</div>
      		<input type="hidden" class="post_id" />
      		<div class="row">
      			<div class="col-md-12">
		        	<div class="form-group label-floating">
						<label class="control-label">ADRESSE DU BÂTIMENT</label>
						<input type="text" class="form-control address_build reset_post">
					</div>
				</div>
			</div>
			<div class="row">		
				<div class="col-md-12">
					<!-- <div class="form-group label-floating">
						<label class="control-label">REGION</label>
						<input type="text" class="form-control region reset_post">
					</div> -->
                    <select id="region" class="selectpicker region reset_post" data-style="select-with-transition" title="REGION" data-size="12" style="font-size: 14px;">
                        <!-- <option disabled> Region</option> -->
                        <option value="anvers">ANVERS</option>
                        <option value="brabant_wallon">BRABANT WALLON</option>
                        <option value="brabant_flamand">BRABANT FLAMAND</option>
                        <option value="bruxelles">BRUXELLES</option>
                        <option value="flandre_occ">FLANDRE_OCC</option>
                        <option value="flandre_orie">FLANDRE_ORIE</option>
                        <option value="hainaut">HAINAUT</option>
                        <option value="limbourg">LIMBOURG</option>
                        <option value="liege">LIEGE</option>
                        <option value="luxembourg">LUXEMBOURG</option>
                        <option value="NAMUR">NAMUR</option>
                    </select>
				</div>
			</div>
			<div class="row">		
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">CODE POSTAL</label>
						<input type="text" class="form-control postal_code reset_post" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
			<input type="hidden" class="lat">
			<input type="hidden" class="long">
			<div class="row">		
				<div class="col-md-12">
					<select id="sand_type" class="selectpicker type_of_sand reset_post" data-style="select-with-transition" title="TYPE DE SABLE" data-size="7">
						<!-- <option disabled> TYPE OF SAND</option> -->
						<option value="remblaiement">REMBLAIEMENT</option>
						<option value="deblaiement">DÉBLAIEMENT</option>
						<option value="arable">ARABLE</option>
						<option value="inerte">INERTE</option>
					</select>
				</div>
			</div>
			<div class="row">		
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">VOLUME (EN MÈTRE CUBIQUE)</label>
						<input type="text" class="form-control volume reset_post" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">COÛT DE TRANSPORT </label>
						<input type="text" class="form-control trans_cost reset_post" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group label-floating date_available">
						<label class="control-label">DATE DE DISPONIBILITÉ (SAND DISPONIBLE POUR LE TRANSPORT)</label>
						<input type="date" class="form-control date_avail reset_post">
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">PRIX</label>
						<input type="text" class="form-control price reset_post" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
			<input type="hidden" class="post_image" />
			<div class="row">
      			<div class="col-md-12">
	  				<center>
	  					<form id="uploadForm" action="upload.php" method="post">
		  					
		  					<div class="fileinput fileinput-new text-center" data-provides="fileinput">
								<div class="fileinput-new thumbnail img-raised">
									<img class="dummyImg" src="assets/img/sandicon.png">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
								<div>
									<span class="btn btn-raised btn-round btn-default btn-file">
										<span class="fileinput-new upload_sand_image" style="cursor: pointer;">Télécharger Sand Image</span>
										<span class="fileinput-exists">Changement</span>
											<input type="file" name="userImage" class="inputFile" />
											<button type="submit" value="Submit" id="btnSubmit" style="display: none"></button>
									</span>
									<a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Retirer</a>
								</div>
							</div>
						</form>
					</center>	
      			</div>
      		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Fermer</button>
        <button type="button" id="post_sand" class="btn btn-info btn-simple">POSTER</button>
        <button type="button" id="update_sand" class="btn btn-info btn-simple" style="display: none">MISE À JOUR DU SABLE</button>
      </div>
    </div>
  </div>
</div>
<div class="section section-gray">
    <div class="container">
        <div class="main main-raised main-product">
            <div class="row">
                <div class="col-md-12 text-center" style="margin-bottom:15px">
                    <h4 style="font-size:22px"><b>SABLE AFFICHÉ</b></h4>
                </div>
                <div class="col-md-10 col-md-offset-1">
                    <div class="table-responsive" style="box-shadow:0px 0px 0px 1px #e0e0e0">
                    <table class="table table-shopping">
                        <thead>
                            <tr>
                                <th class="text-center" style="font-size:16px"><b>Image</b></th>
                                <th class="text-center" style="font-size:16px"><b>Region</b></th>
                                <th class="text-center" style="font-size:16px"><b>Type de sable</b></th>
                                <th class="text-center" style="font-size:16px"><b>Date de disponibilité</b></th>
                                <th class="text-center" style="font-size:16px"><b>Prix</b></th>
                                <th class="text-center" style="font-size:16px"><b>Actes</b></th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php 
                        		$email 	   		= $_SESSION['email'];
                        	    $select_img		= "SELECT * FROM sand_posts WHERE email='$email'";
                        	    //for server
								$selected_img 	= $conn->query($select_img);
								if($selected_img->num_rows != 0){	
									while($row = $selected_img->fetch_assoc()){
								//for local
								// while($row){
                        	?>
			                        	<tr>
			                                <td>
			                                    <div class="img-container">
			                                        <?php if(!empty($row['post_image'])){?>
			                                        	<img src="posts/<?php echo $row['post_image'];?>">
			                                    	<?php }else{ ?>
			                                    		<img src="assets/img/sandicon.png">
			                                    	<?php } ?>
			                                    </div>
			                                </td>
			                                <td class="td-name text-center">
			                                    <a href="#"><?php echo $row['region'];?></a>
			                                    <br /><small><?php echo $row['postal_code'];?></small>
			                                </td>
			                                <td class="text-center"><?php echo ucfirst($row['type_of_sand']);?></td>
			                                <td class="text-center"><?php echo $row['date_avail'];?></td>
			                                <td class="text-center">€ <?php echo $row['price']; ?></td>
			                                <td class="text-center">
			                                	<i class="material-icons edit_sand_post" style="cursor:pointer;font-size:20px;color:#3498db" data-id="<?php echo $row['id']; ?>">border_color</i>&nbsp
			                                	<i class="material-icons delete_sand_post" style="cursor:pointer;font-size:24px;color:#e74c3c" data-id="<?php echo $row['id']; ?>">delete_forever</i>
			                                </td>
			                            </tr>
                            <?php 
                        			}
                        		}else { 
                        	?>
	                        		<tr>
	                        			<td colspan="6"><p class="text-center" style="margin-top:20px;margin-bottom:-3px">No Sand Posté pour l'instant</p></td>
	                        		</tr>
                        	<?php 
                        		} 
                        	?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>
<script type="text/javascript" src='https://maps.google.com/maps/api/js?key=AIzaSyDu938CDvMulD5wTTOwTIrFzROmgyQx8G0&libraries=places'></script>
    <script src="js/locationpicker.jquery.js"></script>
<script>
	$(document).ready(function(){
		$('.date_available').removeClass('is-empty');
		$('[name=userImage]').on('change', validateFileType);
	});

	$("#add_sand_post_sand").click(function(){
		$(".reset_post").val('');
		$(".type_of_sand ").trigger('change');
		$('.dummyImg').attr('src','assets/img/sandicon.png');
	});

    function updateControls(addressComponents) {
        if (addressComponents.country != "BE") {
            $('#address_auto').val('');
            alert('Sorry! We do not support countires other than Belgium yet.');
            return;
        }
        // $('.address_build').val(addressComponents.addressLine1).parents('.label-floating').removeClass('is-empty');
        $('.address_2').val(addressComponents.addressLine2).parents('.label-floating').removeClass('is-empty');
        $('.address_city').val(addressComponents.city).parents('.label-floating').removeClass('is-empty');
        $('.address_state').val(addressComponents.stateOrProvince).parents('.label-floating').removeClass('is-empty');
        $('.postal_code').val(addressComponents.postalCode).parents('.label-floating').removeClass('is-empty');
        $('.address_country').val(addressComponents.country).parents('.label-floating').removeClass('is-empty');
    }
    $('#postModal').on('shown.bs.modal', function (e) {
		$('#map').locationpicker({
		    location: {
		        latitude: 50.848506973217965,
		        longitude: 4.3545795546874615
		    },
		    zoom: 8,
		    radius: 0,
		    inputBinding: {
		        latitudeInput: $('#us3-lat'),
		        longitudeInput: $('#us3-lon'),
		        // radiusInput: $('#us3-radius'),
		        locationNameInput: $('#address_auto')
		    },
		    enableAutocomplete: true,
		    onchanged: function (currentLocation, radius, isMarkerDropped) {
		        var addressComponents = $(this).locationpicker('map').location.addressComponents;
		        updateControls(addressComponents);
		        $('.lat').val(currentLocation.latitude);
		        $('.long').val(currentLocation.longitude);
		        // alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
		    },
		    oninitialized: function (component) {
		    	$('#map').show();
		        var addressComponents = $(component).locationpicker('map').location.addressComponents;
		        updateControls(addressComponents);
		    }
		});
	});


    $("#post_sand").click(function(){
    	var address_build 	= $(".address_build").val();
    	var region 			= $("#region").val();
    	var postal_code 	= $(".postal_code").val();
    	var lat 			= $(".lat").val();
    	var long 			= $(".long").val();
    	var type_of_sand 	= $("#sand_type").val();
    	var volume 			= $(".volume").val();
    	var trans_cost 		= $(".trans_cost").val();
    	var date_avail 		= $(".date_avail").val();
    	var price 			= $(".price").val();
    	var post_image 		= $(".post_image").val();
    	var ref 			= "post_sand";
        
        if (!lat || !long || lat == '' || long == '') {
            alert('Please select location on map');
            return;
        }
    	var coord = [];
    	coord.push(lat);
    	coord.push(long);
    	
    	if(address_build ==""){
    		$(".address_build").focus();
    	}else if(region==""){
    		$(".region").focus();
    	}else if(postal_code==""){
    		$('.postal_code').focus();
    	}else if(type_of_sand==""){
    		$('#sand_type').focus();
    	}else if(volume==""){
    		$(".volume").focus();
    	}else if(trans_cost == ""){
    		$(".trans_cost").focus();
    	}else if(date_avail == ""){
    		$('.date_avail').focus();
    	}else if(price==""){
    		$(".price").focus();
    	}else{
	    	$.ajax({
	    		url : "ajax/common.php",
	    		type : "POST",
	    		dataType: "JSON",
	    		data : {
	    			ref : ref,
	    			address_build : address_build,
	    			region : region,
	    			postal_code : postal_code,
	    			coordinates : coord,
	    			type_of_sand : type_of_sand,
	    			volume : volume,
	    			trans_cost : trans_cost,
	    			date_avail : date_avail,
	    			price : price,
	    			post_image : post_image,
	    		}
	    	}).done(function(res){
	    		if(res.success){
	    		    $('#postModal .close').click();
	    			show_success('Post Added Successfully.'); 
	    		    setTimeout(function(){ 
	    		        hide_success();
	    		        window.location.reload();
	    		    },1500);
	    		}else{
	    		    alert(res.message);
	    		}
	    	});
    	}
    });

    $("#postModal").on('click','#update_sand',function(event){
    	var address_build = $(".address_build").val();
    	var region = $("#region").val();
    	var postal_code = $(".postal_code").val();
    	var lat = $(".lat").val();
    	var long = $(".long").val();
    	var type_of_sand = $("#sand_type").val();
    	var volume = $(".volume").val();
    	var trans_cost = $(".trans_cost").val();
    	var date_avail = $(".date_avail").val();
    	var price = $(".price").val();
    	var post_image 		= $(".post_image").val();
    	var postId = $('.post_id').val();
    	var ref = "update_posted_sand";
        if (!lat || !long || lat == '' || long == '') {
            alert('Please select location on map');
            return;
        }
    	var coord = [];
    	coord.push(lat);
    	coord.push(long);
    	$.ajax({
    		url : "ajax/common.php",
    		type : "POST",
    		dataType: "JSON",
    		data : {
    			ref : ref,
    			address_build : address_build,
    			region : region,
    			postal_code : postal_code,
    			coordinates : coord,
    			type_of_sand : type_of_sand,
    			volume : volume,
    			trans_cost : trans_cost,
    			date_avail : date_avail,
    			price : price,
    			post_image : post_image,
    			post_id : postId
    		}
    	}).done(function(res){
    		if(res.success){
                $('#postModal .close').click();
                show_success('Post Updated Successfully.'); 
                setTimeout(function(){ 
                    hide_success();
                    window.location.reload();
                },1500);
            }else{
                alert(res.message);
            }
    	});
    });
</script>