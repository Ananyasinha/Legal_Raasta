$(document).ready(function(e) {

    $("#contact").on('click', function(){ 
        var firstname   =   $(".firstname").val();
        var lastname    =   $(".lastname").val();
        var email       =   $(".email").val();
        var subject     =   $(".subject").val();
        var message     =   $(".message").val();
        var ref         =   "contact";

        if(!email || email == ''){
            $("#error_register").addClass('alert-danger').html("<center>Email is mandatory</center>");
        }else{
            $(this).addClass('disabled');
            $("#error_register").removeClass().html("");
            $.ajax({
                type: "POST",
                dataType: "JSON",
                url: "ajax/common.php",
                data:{
                    ref                : ref,
                    contactfirstname   : firstname,
                    contactlastname    : lastname,
                    contactemail       : email,
                    contactsubject     : subject,
                    contactmessage     : message
                }
            }).done(function(res){
                if(res.success){
                    show_success(res.message); 
                    setTimeout(function(){ 
                        hide_success();
                        window.location.href="/";
                    },4500);
                }else {
                    $("#contact").removeClass('disabled');
                    var class_name = 'alert alert-danger'+' '+res.class_name;
                    $('#error_register').html('<center>'+res.message+'</center>').removeClass().addClass(class_name).show();
                }
            });
        }
    });


    $("#register").on('click', function(){ 
        var firstname 	=	$(".registerfirstname").val();
        var lastname 	=	$(".registerlastname").val();
        var address		= 	$(".registeraddress").val();
        var email 		= 	$(".registermail").val();
        var password	= 	$(".registerpass").val();
        var cnfpass 	= 	$(".registercnfpass").val();
        var usertype	= 	$("#registerusertype").val();
        var term		= 	$(".registerterm").val();
        var ref 		= 	"register";

        if(password != cnfpass){
        	$("#error_register").addClass('alert-danger').html("<center>Passwords Didn't Match</center>");
        }else{
            $(this).addClass('disabled');
            $("#error_register").removeClass().html("");
    	    $.ajax({
    	        type: "POST",
                dataType: "JSON",
    	        url: "ajax/common.php",
    	        data:{
    	            ref 				: ref,
    	            registerfirstname	: firstname,
    	            registerlastname	: lastname,
    	            registeraddress		: address,
    	        	registeremail		: email,
    	        	registerpass 		: password,
    	        	registerusertype	: usertype,
    	        }
    	    }).done(function(res){
    			if(res.success){
    	            show_success(res.message);
                    setTimeout(function(){ 
                        hide_success();
                        window.location.href="/";
                    },1500);
    	        }else {
                    $("#register").removeClass('disabled');
    	            var class_name = 'alert alert-danger'+' '+res.class_name;
    	            // $(".reg-details").val('');
    	            // $("#registerusertype").val('');
    	            $('#error_register').html('<center>'+res.message+'</center>').removeClass().addClass(class_name).show();
    	        }
    	    });
    	}
    });

    $("#login").on('click', function(){
        var loginemail			= $(".loginemail").val();
    	var loginpass			= $(".loginpass").val();
    	var ref 				= "login";
        if(!loginemail || loginemail == ''){
            $("#error_login").addClass('alert-danger').html("<center>Email is mandatory</center>");
            return;
        }
        else if(!loginpass || loginpass == ''){
            $("#error_login").addClass('alert-danger').html("<center>Password is mandatory</center>");
            return;
        }
        $(this).addClass('disabled');
        $.ajax({
            type: "POST",
            dataType: "JSON",
            url: "ajax/common.php",
            data:{
                ref: ref,
                loginemail: loginemail,
                loginpass: loginpass
            }
        }).done(function(res){
            if(res.success){
                show_success(res.message); 
                setTimeout(function(){ 
                    hide_success();
                    window.location.href="/";
                },1500);
            }else {
                $("#login").removeClass('disabled');
                var class_name = 'alert alert-danger'+' '+res.class_name;
                $('#error_login').html('<center>'+res.message+'</center>').removeClass().addClass(class_name).show();
            }           
        });
    });


    $(".edit_sand_post").on('click', function(){
        var dataId  = $(this).data('id');
        var ref     = "edit_posted_sand";
        $.ajax({
            url  : "ajax/common.php",
            type : "POST",
            dataType:"JSON",
            data : {
                ref : ref,
                dataId : dataId,
            }
        }).done(function(res){
            if(res.status == "edited"){
                $('#postModal').modal('show');
                var postImg = 'posts/'+res.post_image;
                $(".label-floating").removeClass('is-empty');
                $(".address_build").val(res.address_build);
                $(".region").val(res.region);
                $(".postal_code").val(res.postal_code);
                $(".type_of_sand").val(res.type_of_sand);
                $(".type_of_sand").trigger('change');
                $(".volume").val(res.volume);
                $(".trans_cost").val(res.trans_cost);
                $(".date_avail").val(res.date_avail);
                $(".upload_sand_image").html("UPLOAD NEW SAND IMAGE");
                $(".price").val(res.price);
                $(".post_id").val(res.post_id);
                $("#post_sand").hide();
                $("#update_sand").show();
                
                if(res.post_image != ""){
                    $('.dummyImg').attr('src',postImg);
                }else {
                    $('.dummyImg').attr('src','assets/img/sandicon.png');
                }
            }
        });
    });

    $(".delete_sand_post").on('click', function(){
        var $el = $(this).parents('tr');
        var dataId  = $(this).data('id');
        var ref     = "delete_posted_sand";
        $.ajax({
            url  : "ajax/common.php",
            type : "POST",
            data : {
                ref : ref,
                dataId : dataId,
            }
        }).done(function(res){
            if(res == "deleted"){
                show_success('Post Deleted Successfully.');
                $el.remove();
                setTimeout(function(){ 
                    hide_success();
                    // window.location.reload();
                },1500);
            }
        });
    });


    $(".edit_post_goods").on('click', function(){
        var dataId  = $(this).data('id');
        var ref     = "edit_posted_product";
        $.ajax({
            url         : "ajax/common.php",
            type        : "POST",
            dataType    : "JSON",
            data        : {
                ref     : ref,
                dataId  : dataId,
            }
        }).done(function(res){
            if(res.status == "edited"){
                $("#constModal").modal('show');
                var goodImg = 'construction/'+res.const_good_image;
                $(".label-floating").removeClass('is-empty');
                $('.const_address_build').val(res.const_address);
                $('.const_region').val(res.const_region);
                $('.const_postal_code').val(res.const_postal_code);
                $('#product_type').val(res.const_type_of_good);
                $('#product_type').trigger('change');
                $('.const_price').val(res.const_price);

                if(res.const_good_image != ""){
                    $('.dummyImg').attr('src',goodImg);
                }else {
                    $('.dummyImg').attr('src','assets/img/sandicon.png');
                }
                
                $('#const_product').hide();
                $('#update_product').show();
                $('#update_product').attr('data-id',dataId);
            }
        });
    });

    $(".delete_post_goods").on('click', function(){
        var $el = $(this).parents('tr');
        var dataId  = $(this).data('id');
        var ref     = "delete_posted_goods";
        $.ajax({
            url  : "ajax/common.php",
            type : "POST",
            data : {
                ref : ref,
                dataId : dataId,
            }
        }).done(function(res){
            if(res == "deleted"){
                show_success('Product Deleted Successfully.'); 
                $el.remove();
                setTimeout(function(){ 
                    hide_success();
                    // window.location.reload();
                },1500);
            }
        });
    });


    $("#uploadForm").on('submit', (function(e) {
        e.preventDefault();
        /*var trig = $("#post_sand").attr('style');
        if(trig == "display: none;"){
            var status = $(".post_id").val();
        }else{
            var status = "na"; 
        }*/
        $.ajax({
            url: "ajax/upload.php",
            type: "POST",
            dataType: "JSON",
            contentType: false,
            cache: false,
            processData: false,
            // status:status,
            data: new FormData(this),
        }).done(function(res){
            $('.post_image').val(res.name);
        })    
    }));

    $("#uploadProduct").on('submit', (function(e) {
        e.preventDefault();
        $.ajax({
            url: "ajax/uploadproduct.php",
            type: "POST",
            dataType: "JSON",
            contentType: false,
            cache: false,
            processData: false,
            data: new FormData(this),
        }).done(function(res){
            $('.product_image').val(res.name);
        })    
    }));
});


//To check the file type
	function validateFileType(ev){
		ev.preventDefault();
		if (!this.value || this.value == '') {
			return;
		}
		var arr = this.value.split("/"); // getting file name
		var ftype = arr[arr.length-1].split(".")[1]; // getting file type
		// console.log(ftype);
		if(ftype!="png" && ftype!="jpg" && ftype!="jpeg"){
			// alert('Wrong Format (Only .png, .jpg and .jpeg are allowed)');
            show_error('Wrong Format (Only .png, .jpg and .jpeg are allowed)');
            setTimeout(function(){
                hide_error();
            },4000);
		}
		else
		{
		    $(this).parents('form').submit();
		    // $(this).val('');
		}
	}


function numbersonly(myfield, e, dec) {
    var key;
    var keychar;
    if (window.event) key = window.event.keyCode;
    else if (e) key = e.which;
    else return true;
    keychar = String.fromCharCode(key);
    // control keys
    if ((key == null) || (key == 0) || (key == 8) || (key == 9) || (key == 13) || (key == 27)) return true;
    // numbers
    else if ((("0123456789").indexOf(keychar) > -1)) return true;
    // decimal point jump
    else if (dec && (keychar == ".")) {
        myfield.form.elements[dec].focus();
        return false;
    } else return false;
}

function show_success(msg){
    $("#success_msg").show();
    $("#success_msg_area").append('<b>'+msg+'</b>');
}

function hide_success(){
    $("#success_msg").hide();
}

function show_error(msg){
    $("#error_msg").show();
    $("#error_msg_area").append('<b>'+msg+'</b>');
}

function hide_error(){
    $("#error_msg").hide();
}