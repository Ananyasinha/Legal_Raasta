    <footer class="footer">
        <div class="container">
            <nav class="pull-left">
                <ul>
                    <li>
                        <a href="whyus.php">
                            <i class="material-icons">info</i> Pourquoi nous ?
                        </a>
                    </li>
                    <li>
                        <a href="termsofuse.php">
                            <i class="material-icons">verified_user</i> Conditions
                        </a>
                    </li>
                    <li>
                        <a href="faq.php">
                            <i class="material-icons">live_help</i> FAQ
                        </a>
                    </li>
                    <li>
                        <a href="contactus.php">
                            <i class="material-icons">contact_phone</i>&nbsp; Contactez nous
                        </a>
                    </li>
                </ul>
            </nav>
            <div class="copyright pull-right">
                © 2018 mat&maps.be
            </div>
        </div>
    </footer>
</body>
<?php if($_SERVER['SCRIPT_NAME'] == "/index.php"){?>
    <script src="//maps.googleapis.com/maps/api/js?key=AIzaSyA79lcIAMSzxyQeQSg2yYMzRNMSYqENzWg" type="text/javascript"></script>
<?php } ?>
<script src="assets/js/jquery.min.js" type="text/javascript"></script>


<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/material.min.js"></script>

<script src="assets/js/moment.min.js"></script>

<script src="assets/js/nouislider.min.js" type="text/javascript"></script>

<!-- <script src="assets/js/bootstrap-datetimepicker.js" type="text/javascript"></script> -->

<script src="assets/js/bootstrap-selectpicker.js" type="text/javascript"></script>

<script src="assets/js/bootstrap-tagsinput.js"></script>

<script src="assets/js/jasny-bootstrap.min.js"></script>

<script type="text/javascript" src="assets/js/common.js?v=2.0"></script>

<script src="assets/js/material-kit23cd.js?v=1.2.1" type="text/javascript"></script>

<!-- <script src="assets/datepicker/js/formden.js"></script> -->

<?php if($_SERVER['SCRIPT_NAME'] == "/index.php"){?>
    <!-- For map -->
<script type="text/javascript" src="testassets/js/gmap3.min.js"></script>
<script type="text/javascript" src="testassets/js/map.js?ver=1.5"></script>

<?php } ?>
</html>