<?php 
    error_reporting(0);

    if (!session_id())
        session_start();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="assets/img/logo.png">
    <link rel="icon" type="image/png" href="assets/img/logo.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

    <title>Mat & Maps</title>

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
    <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css" />

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />
    <link href="assets/css/material-kit23cd.css?v=1.2.1" rel="stylesheet" />

    <link href="assets/assets-for-demo/vertical-nav.css" rel="stylesheet" />
    <link href="assets/assets-for-demo/demo.css?v=1.1.2" rel="stylesheet" />

<!--     <link href="testassets/css/leaflet.css" rel="stylesheet" type="text/css">
    <link href="testassets/css/leaflet.markercluster.css" rel="stylesheet" type="text/css">
    <link href="testassets/css/leaflet.markercluster.default.css" rel="stylesheet" type="text/css"> -->

    <!-- <link rel="stylesheet" type="text/css" href="assets/datepicker/css/bootstrap-datepicker.css" /> -->
</head>
<?php 
$productPageArray = array("/post_sand.php",
    "/sand_details.php",
    "/faq.php",
    "/whyus.php",
    "/termsofuse.php",
    "/construction.php",
    "/construction-listings.php"
);
if($_SERVER['SCRIPT_NAME'] == "/index.php" || $_SERVER['SCRIPT_NAME'] == "/" || $_SERVER['SCRIPT_NAME'] == ""){ 
    echo '<body class="index-page">';
}else if($_SERVER['SCRIPT_NAME'] == "/register.php" || $_SERVER['SCRIPT_NAME'] == "/contactus.php"){
    echo '<body class="signup-page">';
}else if($_SERVER['SCRIPT_NAME'] == "/login.php"){
    echo '<body class="login-page">';
}else if(in_array($_SERVER['SCRIPT_NAME'], $productPageArray)){
    echo '<body class="product-page">';
}
?>
<div id="success_msg" class="alert alert-success">
    <div id="success_msg_area" class="container">
        <div class="alert-icon">
            <i class="material-icons">check</i>
        </div>
    </div>
</div>

<div id="error_msg" class="alert alert-danger">
    <div id="error_msg_area" class="container">
        <div class="alert-icon">
            <i class="material-icons">error</i>
        </div>
    </div>
</div>

<nav class='navbar navbar-default navbar-transparent navbar-fixed-top navbar-color-on-scroll' id="sectionsNav" <?php if($_SERVER['SCRIPT_NAME'] == "/index.php" || $_SERVER['SCRIPT_NAME'] == "" || $_SERVER['SCRIPT_NAME'] == "/register.php" || $_SERVER['SCRIPT_NAME'] == "/contactus.php" || in_array($_SERVER['SCRIPT_NAME'], $productPageArray)){echo 'color-on-scroll="70"';}?>>
    <div class="container">
        <div class="navbar-header" style="width:8%">
            <button type="button" class="navbar-toggle" data-toggle="collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/"><img src="assets/img/fulllogo.png" style="margin-top:-8px"></a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav navbar-right">
                <li>
                    <a href="/">
                        <i class="material-icons">home</i> Accueil
                    </a>
                </li>
                <?php if(empty($_SESSION['id'])){ ?>
                    <li>
                        <a href="register.php">
                            <i class="material-icons">person_add</i>&ensp;S'inscrire
                        </a>
                    </li>
                    <li>
                        <a href="login.php">
                            <i class="material-icons">account_circle</i>&ensp;Se connecter
                        </a>
                    </li>
                <?php }else { ?>
                    <?php if($_SESSION['usertype'] == "supplier"){ ?>
                    <li>
                        <a href="construction.php">
                            <i class="material-icons">business</i>&ensp;Matériaux de construction
                        </a>
                    </li>
                    <li>
                        <a href="post_sand.php">
                            <i class="material-icons">games</i>&ensp;POST SABLE
                        </a>
                    </li>
                    <?php } ?>
                    <li>
                        <a href="logout.php">
                            <i class="material-icons">account_circle</i>&ensp;<?php echo $_SESSION['firstname'];?>
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>
