<?php
	error_reporting(0);
	if($_SERVER['SCRIPT_NAME'] != "/post_sand.php" && $_SERVER['SCRIPT_NAME'] != "/index.php" && $_SERVER['SCRIPT_NAME'] != "/sand_details.php"){
		session_start();
	}

	$timezone 	= "Asia/Calcutta";
	date_default_timezone_set($timezone);
	$datetime 	= date('Y-m-d H:i:s');
	$date     	= date('Y-m-d');

	$servername = "52.66.163.164";
	$username 	= "ambulance";
	$password	= "amb_app1@dn";
	
	/*$servername = "localhost";
	$username 	= "root";
	$password	= "";*/
	$dbname 	= "mat_and_maps";

	$conn 		= new mysqli($servername, $username, $password, $dbname);


	function sendMail($to, $from, $reply_to="no-reply@mat&maps.be", $subject, $body, $html=false) 
	{
		$headers = "From: $from\r\n";
		$headers .= "Reply-To: $reply_to\r\n";
		$headers .= "MIME-Version: 1.0\r\n";
		if ($html)
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
		return mail($to, $subject, $body, $headers);
    }	

?>