<?php 
	session_start();
	if(!empty($_SESSION['email'])) {
		header('location:/');
	}
	include 'inc/header.php'; 
?>
	<div class="modal fade" id="forgot_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Entrer votre Email</h5>
                </div>
                <div class="modal-body">
                	<div class="row">
						<div class="col-md-12">
							<div class="alert-danger text-center" id="error_forgot_email" style="height:40px;background-color:#e66767;padding-top:10px;display:none">
							</div>
						</div>
					</div>
                    <div class="input-group" style="width:100%">
                		<input type="text" class="form-control email_forgot" placeholder="Email">
                	</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" id="send_veri_code">Envoyer le code de vérification</button>
                </div>
            </div>
        </div>
    </div>

	<div class="modal fade" id="otp_modal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Entrez le code de vérification</h5>
                </div>
                <div class="modal-body">
                	<div class="row">
						<div class="col-md-12">
							<div class="alert-danger text-center" id="error_otp" style="height:40px;background-color:#e66767;padding-top:10px;display:none">
							</div>
						</div>
					</div>
                    <div class="input-group" style="width:100%">
                		<input type="text" class="form-control otp" placeholder="Code de vérification">
                	</div>
                    <div class="input-group" style="width:100%">
                		<input type="password" class="form-control password" placeholder="Mot de passe">
                	</div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" id="send_otp">Vérifier et mettre à jour</button>
                </div>
            </div>
        </div>
    </div>

	<div class="page-header header-filter" filter-color="orange" style="background-image:url('assets/img/wall1.jpg');background-size:cover;background-position:top center;">
		<div class="container"  style="margin-bottom:50px">
			<div class="row" style="margin-top:50px">
				<div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
					<div class="card card-signup">
						<div class="header text-center" style="background-color: #f39c12">
							<h4 class="card-title" style="color: white">Se connecter</h4>
						</div>
						<div class="card-content">
							<div class="row">
								<div class="col-md-12">
									<div id="error_login" style="width:107%"></div>
								</div>
							</div>
							<div class="input-group">
								<span class="input-group-addon">
									<i class="material-icons">email</i>
								</span>
								<input type="text" class="form-control loginemail" placeholder="Email">
							</div>
							<div class="input-group">
								<span class="input-group-addon">
									<i class="material-icons">lock_outline</i>
								</span>
								<input type="password" placeholder="mot de passe" class="form-control loginpass" />
							</div>
							<div class="row" style="margin-top:5px;margin-bottom:-20px;margin-left:2px">
								<div class="col-md-12 text-center">
									<a href="#" class="call_forgot_modal">Mot de passe oublié</a>
								</div>
							</div>
						</div>
						<div class="footer text-center" style="margin-top:10px">
							<a class="btn btn-primary btn-round" id="login" style="background-color: #f39c12">Se connecter</a>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include 'inc/footer.php'; ?>
<script type="text/javascript">
	$(".call_forgot_modal").on('click',function(){
		$("#forgot_modal").modal('show');
	});

	$("#send_veri_code").on('click',function(){
		var email = $('.email_forgot').val();
		
		if(email != "" && email != undefined){
			$("#error_forgot_email").hide();
			var ref   = "email_forgot";
	    	$.ajax({
	    		url  	 : "ajax/common.php",
	    		type 	 : "POST",
	    		dataType : "JSON",
	    		data : {
	    			ref                  : ref,
	    			email 				 : email 
	    		}
	    	}).done(function(res){
	    		if(res.success){
					$("#otp_modal").modal('show');
	    		}else{
	    			$("#error_forgot_email").show();
	    			$("#error_forgot_email").html(res.message);
	    		}
	    	});
		}else {
			$("#error_forgot_email").show();
			$("#error_forgot_email").html("S'il vous plaît entrer votre email ci-dessous");
		}
	});

	$("#send_otp").on('click',function() {
		var otp = $('.otp').val();
		var password = $('.password').val();
		
		if(otp != "" && otp != undefined && password != "") {
			$("#error_otp").hide();
			var ref   = "verify_otp";
	    	$.ajax({
	    		url  	 : "ajax/common.php",
	    		type 	 : "POST",
	    		dataType : "JSON",
	    		data : {
	    			ref                 : ref,
	    			otp                 : otp,
	    			password 			: password 
	    		}
	    	}).done(function(res){
	    		if(res.success){
	    			$("#forgot_modal").modal('hide');
	    			$("#otp_modal").modal('hide');
					show_success(res.message); 
	    		    setTimeout(function(){ 
	    		        hide_success();
	    		    },2500);
	    		}else{
	    			$("#error_otp").show();
	    			$("#error_otp").html(res.message);
	    		}
	    	});
		}else {
			$("#error_otp").show();
			$("#error_otp").html("Veuillez entrer les détails ci-dessous");
		}
	});

</script>