<?php include 'inc/header.php'; ?>
	<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	</div>
	<div class="section section-gray">
	    <div class="container">
	        <div class="main main-raised main-product">
	            <div class="row">
		            <div class="col-md-12 text-center">
		            	<h3 style="margin-top:10px"><b>Qui sommes-nous ?</b></h3>
		            </div>
		        </div>
		        <div class="row">
		        	<div class="col-md-12" style="text-align: justify">
		        		<h4>
		        			Cette application créée en 2017 est née de l'association d'un architecte, Bonasera Giuseppe, et d'un développeur informatique Cisse Gaoussou. Il s'adresse aux particuliers mais aussi aux professionnels de la construction désireux de réaliser des économies écologiques et d'engendrer des bénéfices grâce aux déchets provenant de leurs chantiers.
		        		</h4>	
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Les fondateurs :</b><br>
		        			<b>Bonasera Giuseppe : </b>Architecte indépendant depuis 1998. Enseignant à la faculté d'architecture UMons depuis 2009.Coordinateur sécurité santé depuis 2002 Agréé en performances énergétiques des bâtiments depuis 2011. Mon expérience me permettra de vous aider dans vos recherches et à affiner le site afin de le rendre plus adapté à vos besoins. Je suis aussi curieux de tout et ne me satisfais que de la perfection. Je suis convaincu que le repos existe mais je n’en ai pas encore fait l’expérience 😊.
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align: justify;">
		        		<h4>
		        			<b>Cisse Gaoussou : </b>Développeur .Net. Anciennement employé dans le Marketing pendant une dizaine d’années je me suis réorienté dans le développement qui a toujours été une passion enfouie sous les décombres du politiquement correct. Bref j’en avais marre ... 😉 Et voilà je mets mon talent à votre disposition. MatMaps c’est un gros bébé qu’on va faire grandir avec votre aide… Bon surf sur notre site !
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Matmaps :</b><br>
		        			• C'est un carnet d'adresses proche de votre projet. Pourquoi aller chercher loin ce que l'on peut trouver proche de chez nous ? <br>
		        			• Se débarrasser de vos déchets peut vous coûter très cher, alors que votre voisin souhaiterait les récupérer gratuitement. <br>
		        			• Non seulement vous ferez des économies mais vous pouvez créer des bénéfices. Votre voisin viendra vous acheter vos déchets à un bon prix alors que vous auriez dû payer pour vous en débarrasser.

		        		</h4>
		        	</div>
		        </div>
	        </div>
	    </div>

	</div>
<?php include 'inc/footer.php'; ?>