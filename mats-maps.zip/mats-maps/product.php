<?php include 'inc/header.php'; ?>
<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
    <div class="container">
        <div class="row title-row">
            <div class="col-md-4 col-md-offset-8">
				<button class="btn btn-white pull-right"><i class="material-icons">add_to_photos</i> &nbspAdd Sand</button>
            </div>
        </div>
    </div>
</div>

<div class="section section-gray">
    <div class="container">
        <div class="main main-raised main-product">
            <div class="row">
                <div class="col-md-12 text-center" style="margin-bottom:15px">
                    <h4 style="font-size:22px"><b>POSTED SAND</b></h4>
                </div>
                <div class="col-md-10 col-md-offset-1">
                    <div class="table-responsive" style="box-shadow:0px 0px 0px 1px #e0e0e0">
                    <table class="table table-shopping">
                        <thead>
                            <tr>
                                <th class="text-center" style="font-size:16px"><b>Image</b></th>
                                <th class="text-center" style="font-size:16px"><b>Region</b></th>
                                <th class="text-center" style="font-size:16px"><b>Type Of Sand</b></th>
                                <th class="text-center" style="font-size:16px"><b>Date Of Avalibility</b></th>
                                <th class="text-center" style="font-size:16px"><b>Price</b></th>
                                <th class="text-center" style="font-size:16px"><b>Actions</b></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>
                                    <div class="img-container">
                                        <img src="assets/img/deal1.jpg">
                                    </div>
                                </td>
                                <td class="td-name text-center">
                                    <a href="#">Antwrep</a>
                                    <br /><small>11002</small>
                                </td>
                                <td class="text-center">Déblaiement</td>
                                <td class="text-center">20-01-2018</td>
                                <td class="text-center">€ 725</td>
                                <td class="text-center">
                                	<i class="material-icons" style="font-size:20px;color:#3498db">border_color</i>&nbsp
                                	<i class="material-icons" style="font-size:24px;color:#e74c3c">delete_forever</i>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="img-container">
                                        <img src="assets/img/deal2.jpg"/>
                                    </div>
                                </td>
                                <td class="td-name text-center">
                                    <a href="#">Ghent</a>
                                    <br /><small>11003</small>
                                </td>
                                <td class="text-center">Remblaiement</td>
                                <td class="text-center">21-01-2018</td>
                            	<td class="text-center">€ 325</td>
                            	<td class="text-center">
                            		<i class="material-icons" style="font-size:20px;color:#3498db">border_color</i>&nbsp
                            		<i class="material-icons" style="font-size:24px;color:#e74c3c">delete_forever</i>
                            	</td>
                            </tr>
                            <tr>
                                <td>
                                    <div class="img-container">
                                       <img src="assets/img/deal3.jpg">
                                    </div>
                                </td>
                                <td class="td-name text-center">
                                    <a href="#">Brussels</a>
                                    <br /><small>11004</small>
                                </td>
                                <td class="text-center">Arable</td>
                                <td class="text-center">22-01-2018</td>
                                <td class="text-center">€ 625</td>
                                <td class="text-center">
                                	<i class="material-icons" style="font-size:20px;color:#3498db">border_color</i>&nbsp
                                	<i class="material-icons" style="font-size:24px;color:#e74c3c">delete_forever</i>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>