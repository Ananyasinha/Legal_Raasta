-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 04, 2018 at 11:30 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mat_and_maps`
--

-- --------------------------------------------------------

--
-- Table structure for table `construction`
--

CREATE TABLE `construction` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `address` text,
  `region` text,
  `postal_code` text,
  `type_of_good` text,
  `good_image` text,
  `price` text,
  `datetime` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `construction`
--

INSERT INTO `construction` (`id`, `email`, `address`, `region`, `postal_code`, `type_of_good`, `good_image`, `price`, `datetime`) VALUES
(1, 'abc@ui.com', 'abc', 'abc', '12345', 'foyers', '1.jpg', '123445', '2018-01-05 02:50:45');

-- --------------------------------------------------------

--
-- Table structure for table `sand_posts`
--

CREATE TABLE `sand_posts` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `address_build` text,
  `region` text,
  `postal_code` text,
  `coordinates` text,
  `type_of_sand` text,
  `volume` text,
  `trans_cost` text,
  `date_avail` text,
  `price` text,
  `post_image` text,
  `datetime` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sand_posts`
--

INSERT INTO `sand_posts` (`id`, `email`, `address_build`, `region`, `postal_code`, `coordinates`, `type_of_sand`, `volume`, `trans_cost`, `date_avail`, `price`, `post_image`, `datetime`) VALUES
(2, 'ankush@developersnation.com', '1050 Ixelles', 'Belgium', '1050', '[\"50.82517183651189\", \"4.378783808837852\"]', 'remblaiement', '345', '30', '05/02/2018', '567', '2.png', '2018-01-01 21:17:44'),
(3, 'abc@ui.com', 'New', 'Mons', '1000', '[\"50.82012\",\"4.367950000000064\"]', 'remblaiement', '250', '124000', '12/02/2019', '130000', '3.jpg', '2018-01-02 00:45:54'),
(18, 'abc@ui.com', 'abc', 'abc', '12000', '[\"50.8229131\",\"4.3677348999999595\"]', 'arable', '12000', '1200', '12/12/2019', '12000', '18.jpg', '2018-01-02 01:55:54'),
(19, 'abc@ui.com', 'EFGH', 'EFGHI', '1050', '[\"50.82012\",\"4.367950000000064\"]', 'arable', '12000', '120000', '12/02/2019', '120000', '19.jpeg', '2018-01-02 01:57:04'),
(20, 'abc@ui.com', 'XYZ', 'XYZ', '1400', '[\"50.8511292\",\"4.360091699999998\"]', 'inerte', '19000', '10000', '02/02/2019', '13900', '20.jpg', '2018-01-02 01:58:24'),
(21, 'abc@ui.com', 'efgh', 'sTUV', '12000', '[\"50.8511292\",\"4.360091699999998\"]', 'arable', '13000', '13000', '13/12/2019', '120000', '21.jpg', '2018-01-02 01:59:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` text NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `address` text NOT NULL,
  `password` text,
  `usertype` text,
  `datetime` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `firstname`, `lastname`, `address`, `password`, `usertype`, `datetime`) VALUES
(1, 'abc@ui.com', 'abc', 'abc', 'abc', '900150983cd24fb0d6963f7d28e17f72', 'supplier', '2017-12-25 03:02:58'),
(2, 'abhishek@abc.com', 'Abhishek', '.', 'Delhi', 'f589a6959f3e04037eb2b3eb0ff726ac', 'supplier', '2017-12-25 03:08:24'),
(3, 'ankush@developersnation.com', 'Ankush', 'Goel', 'Developers Nation, Shiva Road, Rohini, Delhi, India', '25d55ad283aa400af464c76d713c07ad', 'supplier', '2017-12-31 20:22:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `construction`
--
ALTER TABLE `construction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sand_posts`
--
ALTER TABLE `sand_posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `construction`
--
ALTER TABLE `construction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `sand_posts`
--
ALTER TABLE `sand_posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
