<?php 
    session_start();

    if($_SESSION['usertype'] != "supplier") {
        header("location:/");
    }
	include 'inc/header.php'; 
	include 'inc/db.php'; 

?>

<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
    <div class="container">
        <div class="row title-row">
            <div class="col-md-4 col-md-offset-8">
				<button id="open_post_modal" class="btn btn-white pull-right" data-toggle="modal" data-target="#constModal"><i class="material-icons">add_to_photos</i> &nbsp;Add</button>
            </div>
        </div>
    </div>
</div>

<!-- Modal Core -->
<div class="modal fade" id="constModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog" style="width:65%">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel" style="font-size:20px;font-weight:600">DÉTAILS DE CONSTRUCTION</h4>
      </div>
      <div class="modal-body">
      		<input type="hidden" class="post_id" />
      		<div class="row">
      			<div class="col-md-12">
		        	<div class="form-group label-floating">
						<label class="control-label">ADRESSE DU BÂTIMENT</label>
						<input type="text" class="form-control const_address_build reset_const">
					</div>
				</div>
			</div>
			<div class="row">		
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">RÉGION</label>
						<input type="text" class="form-control const_region reset_const">
					</div>
				</div>
			</div>
			<div class="row">		
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">CODE POSTAL</label>
						<input type="text" maxlength="6" class="form-control const_postal_code reset_const" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
			<div class="row" style="margin-top:15px;margin-bottom:3px;">
				<div class="col-md-12">
					<select id="product_type" class="selectpicker const_type_of_pro reset_const" data-style="select-with-transition" title="TYPE DE BIENS" data-size="7">
						<option value="chassis">CHÂSSIS PORTES, TUILES, ARDOISES</option>
						<option value="bois">BOIS DE CHARPENTE</option>
						<option value="poutres">POUTRES MÉTALLIQUES (CUIVRE, ACIER, FONTE)</option>
						<option value="foyers">FOYERS EN FONTE, CHEMINÉES</option>
                        <option value="pierres">PIERRES BLEUES</option>
                        <option value="sanitaries">SANITAIRES ET CUISINES</option>
                        <option value="payage">PAVAGE ET CARRELAGE À DÉMONTER (PRÉCISER SI C’EST À DÉMONTER OU PRÊT)</option>
                        <option value="cloture">CLÔTURE ET PORTAIL</option>
					</select>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group label-floating">
						<label class="control-label">PRIX</label>
						<input type="text" class="form-control const_price reset_const" onkeypress="return numbersonly(this,event)">
					</div>
				</div>
			</div>
            <input type="hidden" class="product_image" />
			<div class="row">
      			<div class="col-md-12">
	  				<center>
	  					<form id="uploadProduct" action="upload.php" method="post">
		  					<div class="fileinput fileinput-new text-center" data-provides="fileinput">
								<div class="fileinput-new thumbnail img-raised">
									<img class="dummyImg" src="assets/img/sandicon.png">
								</div>
								<div class="fileinput-preview fileinput-exists thumbnail img-raised"></div>
								<div>
									<span class="btn btn-raised btn-round btn-default btn-file">
										<span class="fileinput-new upload_sand_image" style="cursor: pointer;">Télécharger l'image du produit</span>
										<span class="fileinput-exists">Change</span>
											<input type="file" name="productImage" class="inputFile" />
											<button type="submit" value="Submit" id="constbtnSubmit" style="display:none"></button>
									</span>
									<a href="#pablo" class="btn btn-danger btn-round fileinput-exists" data-dismiss="fileinput"><i class="fa fa-times"></i> Retirer</a>
								</div>
							</div>
						</form>
					</center>	
      			</div>
      		</div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default btn-simple" data-dismiss="modal">Fermer</button>
        <button type="button" id="const_product" class="btn btn-info btn-simple">POSTER</button>
        <button type="button" id="update_product" class="btn btn-info btn-simple" style="display: none">MISE À JOUR DU PRODUIT</button>
      </div>
    </div>
  </div>
</div>
<div class="section section-gray">
    <div class="container">
        <div id="post_goods" class="main main-raised main-product">
            <div class="row">
                <div class="col-md-12 text-center" style="margin-bottom:15px">
                    <h4 style="font-size:22px;cursor:default;"><b>BIENS AFFICHÉS</b></h4>
                </div>
                <div class="col-md-10 col-md-offset-1">
                    <div class="table-responsive" style="box-shadow:0px 0px 0px 1px #e0e0e0;margin-bottom:50px">
                    <table class="table table-shopping">
                        <thead>
                            <tr>
                                <th class="text-center" style="font-size:16px;">
                                    <b style="margin-left:-25px">Image</b>
                                </th>
                                <th class="text-center" style="font-size:16px"><b>Région</b></th>
                                <th class="text-center" style="font-size:16px"><b>Type de marchandises</b></th>
                                <th class="text-center" style="font-size:16px"><b>Prix</b></th>
                                <th class="text-center" style="font-size:16px"><b>Actes</b></th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php 
                        		$email 	   		= $_SESSION['email'];
                        	    $select_img		= "SELECT * FROM construction WHERE email='$email'";
                        	    //for server
								$selected_img 	= $conn->query($select_img);
								if($selected_img->num_rows != 0){	
									while($row = $selected_img->fetch_assoc()){
								//for local
								// while($row){
                        	?>
	                        	<tr>
	                                <td class="text-center">
	                                    <div class="img-container" style="margin-left:50px">
	                                        <?php if(!empty($row['good_image'])){?>
                                               <img src="construction/<?php echo $row['good_image'];?>" style="width:200px;height:100px">
                                            <?php }else{ ?>
                                                <img src="assets/img/sandicon.png" style="width:200px;height:100px">
                                            <?php } ?>
	                                    </div>
	                                </td>
	                                <td class="text-center">
	                                    <a href="#"><?php echo $row['region'];?></a>
	                                    <br /><small><?php echo $row['postal_code'];?></small>
	                                </td>
	                                <td class="text-center"><?php echo ucfirst($row['type_of_good']);?></td>
	                                
	                                <td class="text-center">€ <?php echo $row['price']; ?></td>
	                                <td class="text-center">
	                                	<i class="material-icons edit_post_goods" style="cursor:pointer;font-size:20px;color:#3498db" data-id="<?php echo $row['id']; ?>">border_color</i>&nbsp
	                                	<i class="material-icons delete_post_goods" style="cursor:pointer;font-size:24px;color:#e74c3c" data-id="<?php echo $row['id']; ?>">delete_forever</i>
	                                </td>
	                            </tr>
                            <?php 
                        			}
                        		}else { 
                        	?>
	                        		<tr>
	                        			<td colspan="6"><p class="text-center" style="margin-top:20px;margin-bottom:-3px">Aucune annonce postée</p></td>
	                        		</tr>
                        	<?php 
                        		} 
                        	?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'inc/footer.php'; ?>
<script>

    $('[name=productImage]').on('change', validateFileType);
    
    $("#const_product").click(function(){
    	var const_address_build  = $(".const_address_build").val();
    	var const_region         = $(".const_region").val();
    	var const_postal_code    = $(".const_postal_code").val();
    	var product_type         = $("#product_type").val();
    	var const_price          = $(".const_price").val();
        var product_image        = $(".product_image").val();
    	var ref                  = "post_product";
    	$.ajax({
    		url  : "ajax/common.php",
            // dataType : "JSON",
    		type : "POST",
    		data : {
    			ref                  : ref,
                const_address_build  : const_address_build,
                const_region         : const_region,
                const_postal_code    : const_postal_code,
                product_type         : product_type,
                const_price          : const_price,
                product_image        : product_image,
    		}
    	}).done(function(res){
            if(res == "inserted_construction"){
                $('#constModal .close').click();
                show_success('Product Added Successfully.'); 
                setTimeout(function(){ 
                    hide_success();
                    window.location.reload();
                },1500);
            }else{
                show_error('Something went wrong'); 
                setTimeout(function(){ 
                    hide_error();
                },1500);
            }
    	});
    });

    $("#constModal").on('click','#update_product',function(event){
    	var dataId               = $(this).data('id');  
        var const_address_build  = $(".const_address_build").val();
        var const_region         = $(".const_region").val();
        var const_postal_code    = $(".const_postal_code").val();
        var product_type         = $("#product_type").val();
        var const_price          = $(".const_price").val();
        var product_image        = $(".product_image").val();
        var ref                  = "update_posted_product";
    	$.ajax({
    		url : "ajax/common.php",
    		type : "POST",
            dataType: "JSON",
    		data : {
    			ref                  : ref,
                const_address_build  : const_address_build,
                const_region         : const_region,
                const_postal_code    : const_postal_code,
                product_type         : product_type,
                const_price          : const_price,
                product_image        : product_image,
    		    dataId               : dataId   
            }
    	}).done(function(res){
            if(res.success){
                $('#constModal .close').click();
                show_success('Product Updated Successfully.'); 
                setTimeout(function(){ 
                    hide_success();
                    window.location.reload();
                },1500);
            }else{
                show_error(res.message);
                setTimeout(function(){
                    hide_error();
                });
            }
    	});
    });


    // $("#post_goods").on('click',".edit_post_goods",function(){
    //     $("#open_post_modal").click();
    //     var dataId  = $(this) .data('id');
    //     var ref     = "edit_construction";
    //     $.ajax({
    //         url : "ajax/common.php",
    //         type : "POST",
    //         dataType: "JSON",
    //         data : {
    //             ref : ref,
    //             dataId : dataId
    //         }
    //     }).done(function(res){
            
    //     });
    // });
</script>