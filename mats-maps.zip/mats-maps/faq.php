<?php include 'inc/header.php'; ?>
	<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	</div>
	<div class="section section-gray">
	    <div class="container">
	        <div class="main main-raised main-product">
	            <div class="row">
		            <div class="col-md-12 text-center">
		            	<h3 style="margin-top:5px"><b>FAQ</b></h3>
		            </div>
		        </div>
		        <div class="row">
		        	<div class="col-md-12" style="text-align: justify">
		        		<h4>
		        			<b>Pourquoi utiliser MatMaps ?</b><br>
		        			• C&#39;est un carnet d&#39;adresses proche de votre projet. Pourquoi aller chercher loin ce que l&#39;on peut trouver proche de chez nous ?<br>
		        			• Se débarrasser de vos déchets peut vous coûter très cher, alors que votre voisin
		        			souhaiterait les récupérer gratuitement.<br>
		        			• Non seulement vous ferez des économies mais vous pouvez créer des bénéfices. 	Votre voisin viendra vous acheter vos déchets à un bon prix alors que vous auriez dû payer pour vous en débarrasser.
		        		</h4>	
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Quelques exemples :</b><br>
		        			<b>1.</b> Vous démolissez un mur ? Pas loin de chez vous un chantier souhaite récupérer ou acheter vos gravats pour les utiliser comme empierrement. Ce potentiel acquéreur sera ravi de récupérer vos gravats qui lui auraient coûté plus cher ailleurs. Les coûts de transport sont considérablement réduits et la proximité vous fait gagner un temps inestimable.<br>
		        			<b>2.</b> Vous terrassez ? L&#39;enlèvement de vos terres est onéreux à cause de la manutention. Le grutier doit attendre le retour du livreur pour continuer à terrasser. Ce temps et cette attente coûtent cher. Avec MatMaps vous trouverez quelqu&#39;un proche de chez vous qui souhaite récupérer vos terres. Cela vous coûtera moins cher en main d&#39;œuvre etdéplacements, en outre vous négocierez la revente de vos terres. Pour ces mêmes raisons l&#39;acheteur réalisera également de sérieuses économies pour des terres qu&#39;il aurait dû
		        			acheter au prix plein.<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align: justify;">
		        		<h4>
		        			<b>Ecologie :</b><br>
		        			MatMaps contribue à réduire le bilan carbone. Avec MatMaps, votre projet peut se vanter de contribuer à réduire notre empreinte écologique. Afin de réduire les émissions de gaz à effet de serre, nos futures constructions ne pourront plus être réalisées sans tenir compte du bilan carbone. Quel serait l&#39;intérêt de construire passif, si pour la production des matériaux employés il aura fallu dépenser des tonnes de CO2 ?<br><br>
		        			Certains pays comme la France ont adopté l&#39;outil de comptabilisation du bilan carbone afin de mesurer le degré polluant d&#39;une entreprise ou pour la construction d&#39;un bâtiment. En
		        			utilisant MatMaps nous sommes précurseurs d&#39;une politique écologique qui indéniablement fera partie de notre paysage normatif européen dans les prochaines années. Réduire les distances entre l&#39;acquéreur et le donneur permettra de réduire considérablement les consommations de fuel et d&#39;émission de CO2 !<br><br>
		        			MatMaps est une application sérieuse et professionnelle. Elle est le résultat de recherches ayant conduit à un constat, c’est qu’à l’heure où il est plus qu’urgent de réaliser des économies tout en ayant une action positive sur son environnement, il n’existe pas d’équivalent. L’un des principaux atouts de MatMaps est qu’il permet d&#39;obtenir un réseau social et professionnel sérieux sur base d&#39;un outil cartographique qui se trouve être Google Maps. Pour ce faire les créateurs seront vigilants à ce qu&#39;il soit alimenté par des personnes sérieuses et des informations pertinentes.
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Comment s’inscrire ?</b><br>
		        			Pour s’inscrire, il vous suffit de vous rendre sur la page d’accueil et de remplir le formulaire d’inscription rapide qui y est proposé. Vous pouvez également y accéder en cliquant directement sur le lien suivant :  www.matmaps.be/inscription.<br><br>
		        			Pour une meilleure visibilité et un meilleur référencement, nous vous prions de remplir ces informations avec la plus grande attention et précision. De ce fait, les autres utilisateurs n’auront aucune difficulté à retrouver vos coordonnées. Et votre chantier sera clairement visible sur la carte Google Maps.<br><br>
		        			Une fois l’inscription confirmée, vous recevrez dans les instants qui suivent un mail à l’adresse email que vous aurez renseigné et contenant un lien par lequel vous pourrez valider votre inscription.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align: justify;">
		        		<h4>
		        			<b>Que faire si je me suis trompé, si j’ai entré de mauvaises coordonnées ?</b><br>
		        			Une fois inscrit, vous aurez accès à votre page de profil. Cette page vous offre la possibilité de modifier ou mettre à jour les informations concernant le(s) chantier(s) que vous aurez renseigné(s) sur www.matmaps.be. Vous pourrez également mettre à jour vos données personnelles.<br><br>
		        			MatMaps est une application intuitive. Votre premier accès au site se fera sur la page d’accueil qui a comme principale particularité d’avoir une carte google Maps sur laquelle tous les chantiers de remblais, déblais etc… sont visibles et sont représentées sous forme d’icônes vertes ou brunes en fonction de leur type.<br><br>
		        			Comme ça, vous voyez tout de suite où vous mettez les pieds.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Je veux mettre une annonce en ligne :</b><br>
		        			Cela nécessitera de remplir le formulaire d&#39;inscription. Car seuls les visiteurs inscrits ont cette possibilité. Une fois le formulaire dûment complété et l’inscription confirmée vous pourrez entreprendre des transactions avec l’un ou l’autre membre en fonction de sa proposition. Par la suite vous n&#39;aurez plus rien à faire. Vous serez en possession d&#39;un login et d&#39;un code d&#39;accès unique permettant de protéger l&#39;ensemble de vos données.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Comment est-ce que les visiteurs peuvent réagir à mon annonce ?</b><br>
		        			- par téléphone si vous avez indiqué votre numéro de téléphone sur votre Page Personnelle.<br><br>
		        			- via l&#39;option &quot;E-mail cet annonceur&quot;. Ce bouton se situe à droite de chaque petite annonce. Vous recevrez ainsi un e-mail.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Après avoir placé mon offre, je n&#39;ai pas reçu de mail de confirmation. Est-ce possible ?</b><br>
		        			Veuillez ajouter l&#39;adresse noreply@matmaps.be dans votre carnet d&#39;adresses. De cette manière, votre filtre anti-spam ne bloquera pas nos e-mails.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4>
		        			<b>Comment fonctionnent les offres ?</b><br>
		        			Une offre n&#39;engage à rien. L&#39;annonceur n&#39;est pas obligé de choisir l&#39;offre la plus haute et il peut décider de supprimer une offre. En tant qu&#39;offrant, vous pouvez également décider de retirer votre offre.<br><br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4>
		        			<b>Est-ce que je dois payer quelque chose ?</b><br>
		        			MatMaps est un site internet complètement gratuit. Aucun moyen de paiement n’y est exigé. Les transactions, si toutefois sont payantes, elles se font entre les utilisateurs et sont laissées à leur entière discrétion.<br><br>
		        			<b>À quoi dois-je faire attention lors d&#39;un contact avec le vendeur ou l&#39;acheteur ?</b><br>
		        			5 conseils en or pour s&#39;assurer de sa sécurité : ne faites rien en ligne que vous ne feriez dans la vie réelle !<br><br>
		        			Faites preuve de bon sens : si quelque chose semble trop beau pour être vrai, c&#39;est fort probablement le cas.<br>
		        			• Faites preuve de bon sens : si quelque chose semble trop beau pour être vrai, c&#39;est fort probablement le cas.<br>
		        			• Regardez depuis combien de temps le vendeur est actif sur notre site, vérifiez ses autres annonces, ses évaluations et prenez personnellement contact avec lui.<br>
		        			• Vérifiez les données du vendeur sur internet et/ou vérifiez ses données téléphoniques et bancaires via le service de Fraude Informatique.<br>
		        			• Si vous payez par PayPal, vos achats sont généralement protégés de façon illimitée.<br>
		        			• Restez vigilant avec les vendeurs ou acheteurs étrangers et n&#39;acceptez aucune méthode de paiement (anonyme) telle que Western Union.<br><br>
		        			<b>Comment entrer en contact avec un annonceur ?</b><br>
		        			- Par email : en envoyant un email à l’adresse qu’il aura indiquée<br>
		        			- Par téléphone : si bien sûr l’annonceur en a donné un.<br><br>
		        			<b>Mon compte est bloqué. Que faire ?</b><br><br>
		        			Un compte est bloqué une fois que les règles et les conditions d&#39;utilisation ont été outrepassées à plusieurs reprises. S&#39;il s&#39;avère que vous avez clairement fait de la publicité ou du spamming, vous ne pouvez plus insérer d&#39;annonces sur notre site. Si vous pensez qu&#39;il s&#39;agit d&#39;une erreur, envoyez-nous une demande de réactivation de votre compte via le Formulaire de contact.<br><br>
		        			<b>Qu&#39;est-ce qu&#39;une évaluation ?</b><br><br>
		        			Votre sécurité est notre cheval de bataille. Si vous avez connu une expérience positive ou négative avec un annonceur ou un acheteur, vous pouvez insérer une évaluation sur son profil. Grâce aux évaluations, les autres visiteurs du site peuvent avoir une idée de la fiabilité d&#39;un annonceur ou d&#39;un acheteur.<br><br>Vous pouvez insérer des évaluations si vous avez créé votre Page Personnelle il y a plus d&#39;une semaine. Vous pouvez insérer des évaluations pour toutes les personnes avec qui vous avez eu un contact. Il est donc important que vous possédiez l&#39;adresse e-mail de la personne que vous souhaitez évaluer.<br><br>
		        			<b>Je ne parviens pas à ouvrir une session. Que faire ?</b><br><br>
		        			Vérifiez d&#39;abord que les données que vous avez introduites sont correctes et que vous n&#39;avez pas fait de fautes de frappe. Cela ne fonctionne toujours pas ? Remplissez alors le Formulaire de Contact, nous pourrons rapidement nous occuper de votre problème.<br><br>
		        			<b>Pourquoi l&#39;offrant ne réagit-il pas à mon e-mail ou à mon message instantané ?</b><br><br>
		        			C&#39;est en effet ennuyeux. La plupart du temps, cela signifie que l&#39;offrant n&#39;est plus intéressé, ou qu’il n’a pas encore vu votre message.<br><br>
		        			<b>Comment supprimer une offre ?</b><br><br>
		        			Seul l&#39;annonceur ou l&#39;acheteur peut supprimer une offre. Pour cela, depuis votre page d&#39;annonce sous le champ &quot;Offres&quot;, cliquez sur l&#39;icône de suppression pour supprimer l&#39;offre insérée. Vous devez naturellement avoir ouvert votre session pour pouvoir faire cela.
		        		</h4>
		        	</div>
		        </div>
	        </div>
	    </div>

	</div>
<?php include 'inc/footer.php'; ?>