<?php include 'inc/header.php'; ?>
	<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	</div>
	<div class="section section-gray">
	    <div class="container">
	        <div class="main main-raised main-product">
	            <div class="row">
		            <div class="col-md-12 text-center">
		            	<h3 style="margin-top:5px"><b>Conditions générales d'utilisation</b></h3>
		            </div>
		        </div>
		        <div class="row">
		        	<div class="col-md-12" style="text-align: justify">
		        		<h4>
		        			<b>1. Bienvenue sur www.matmaps.be!</b><br>
		        			Ces conditions d'utilisation (les "Conditions d'utilisation") sont applicables à l'utilisation et au fonctionnement du site internet, qui est, entre autres, accessible via le nom de domaine www.matmaps.be (aussi bien via un ordinateur que via un appareil mobile ou par toute autre application software) (le "Site Internet"), pour les services qui sont offerts par www.matmaps.be et pour tous les contrats que www.matmaps.be conclut pour l'utilisation du Site Internet et la prestation de ses services.<br><br>
		        			www.matmaps.be est une plateforme de commerce en ligne, où l'offre et la demande en provenance de toute la Belgique sont réunies, grâce à la mise à disposition d'espace pour l'affichage d'annonces (le "Service"). La prestation de certains services payants pourra dépendre, vu la nature de ces services, de l'espace publicitaire disponible sur le Site Internet au moment de la commande.<br><br>
		        			En utilisant ou en consultant le Site Internet et en faisant usage du Service, vous reconnaissez avoir pris connaissance des Conditions d'utilisation et en acceptez intégralement les termes. C'est pourquoi www.matmaps.be conseille à chaque utilisateur du Site Interne de bien lire les Conditions d'utilisation avant d'utiliser le Site Internet et par la suite à intervalles réguliers.
		        		</h4>	
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:20px">
		        			<b>1.1 Mineurs</b><br>
		        			Le Service n’est accessible qu’aux personnes juridiquement capables de conclure des
		        			contrats (l&#39; &quot;Utilisateur&quot; ou &quot;vous&quot;). Sans préjudice de ce qui précède, le Service n&#39;est
		        			accessible aux Utilisateurs qui sont mineurs que dans la mesure où ils ont obtenu le
		        			consentement de leur représentant légal ou dans la mesure où ils posent un acte juridique
		        			dont il est admit qu&#39;un mineur de cet âge puisse le poser de manière autonome.
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align: justify;">
		        		<h4>
		        			<b>2.</b> Règles pour l&#39;enregistrement en tant qu&#39;utilisateur et pour l&#39;affichage des annonces
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:20px">
		        			<b>2.1</b> Enregistrement et identification de l&#39;Utilisateur
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align: justify;">
		        		<h4 style="margin-left:40px">
			        		<b>2.1.1</b> L&#39;Utilisateur du Site Internet peut s&#39;enregistrer en tant qu&#39;annonceur (l&#39; &quot;Annonceur&quot;) en remplissant le formulaire d&#39;enregistrement en ligne (la &quot;Page Personnelle&quot;). L&#39;Utilisateur peut,
			        		à tout moment, modifier sa Page Personnelle et se retirer du Site Internet.<br>
			        		<b>2.1.2</b> L&#39;Utilisateur doit remplir ses données personnelles de manière correcte et sincère et est, par conséquent, responsable de l&#39;exhaustivité et de l&#39;exactitude de ces informations. L&#39;Utilisateur se doit ainsi de maintenir lui-même sa Page Personnelle à jour.<br>
			        		<b>2.1.3</b> L&#39;Utilisateur est personnellement responsable du maintien de la confidentialité de son adresse e-mail et de son mot de passe. Ces informations ne peuvent pas être communiquées à des tiers ou leur être transmis d&#39;une autre manière.<br>
			        		<b>2.1.4</b> Lors de la création d&#39;une Page Personnelle, il n&#39;est pas permis de créer plusieurs Pages Personnelles qui auraient principalement pour but de faire apparaitre l&#39;Utilisateur comme un Utilisateur différent sur le Site Internet ou de permettre à l&#39;Utilisateur de placer les mêmes Annonces à plusieurs reprises sur le Site Internet. Il est également interdit d&#39;utiliser un nom d&#39;Annonceur contenant un URL (ou une partie de celui-ci) ou une adresse e-mail.<br>
			        	</h4>	
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:20px">
		        			<b>2.2</b> Conclusion du contrat entre www.matmaps.be et l&#39;Annonceur pour le placement d&#39;annonces<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:40px">
		        			<b>2.2.1</b> Sur le Site Internet, l&#39;Utilisateur peut examiner les annonces (&quot;Annonces&quot;) d&#39;Annonceurs et y réagir. Si l&#39;Utilisateur est enregistré, il peut également placer lui-même des Annonces sur le Site Internet en tant qu&#39;Annonceur.<br>
		        			<b>2.2.2</b> Via le bouton &#39;Placer une Annonce gratuite&#39; l&#39;Annonceur peut rédiger une Annonce et la placer sur le Site Internet. Après avoir placé l&#39;Annonce, l&#39;Annonceur peut, à tout moment, modifier cette Annonce. Le placement des Annonces est en principe gratuit mais peut être payant dans les cas décrits au chapitre II, titre 2, au choix de l&#39;Annonceur.<br>
		        			<b>2.2.3</b> En plaçant une Annonce gratuite, l&#39;Annonceur concut avec www.matmaps.be un contrat pour le placement des Annonces (le &quot;Contrat d&#39;Annonces&quot;). Pour les Annonces payantes, le Contrat d&#39;Annonces est conclu comme exposé au chapitre II, titre 2.<br>
		        			<b>2.2.4</b> Les Annonces restent en principe 4 mois sur le Site Internet, à condition que les Conditions d&#39;utilisation soient respectées et que les Annonceurs n&#39;aient pas eux-mêmes enlevé leurs Annonces. Une (1) semaine et un (1) jour avant l&#39;expiration de cette période, l&#39;Annonceur concerné recevra une notification l&#39;informant que ses Annonces peuvent être prolongées gratuitement pour la même période.<br>
		        			<b>2.2.5</b> L&#39;Annonceur doit supprimer ses Annonces dès l&#39;achat ou la vente des produits ou des services concernés. Dès la suppression de l&#39;Annonce ou l&#39;achat ou la vente des produits ou des services concernés, le Contrat d&#39;Annonces arrive à son terme.<br>
		        			<b>2.2.6</b> www.matmaps.be. conserve toutes les données de chaque Contrat d&#39;Annonces pendant 4 mois après le retrait de l&#39;Annonce concernée, tant que la Page Personnelle de l&#39;Annonceur n&#39;est pas supprimée. Après l&#39;expiration de ce délai, nous conservons les données concernant le Contrat d&#39;Annonces de la manière décrite dans notre politique sur le respect de la vie privée.
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:20px">
		        			<b>2.3</b> Règles générales pour le placement d&#39;Annonces sur le Site Internet<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12" style="text-align:justify;">
		        		<h4 style="margin-left:40px">
		        			<b>2.3.1</b> Les Annonces qui sont placées par l&#39;Annonceur sur le Site Internet, doivent sastisfaire aux règles reprises ci-après. Si les Annonces ne remplissent pas ces conditions, www.matmaps.be peut les retirer:<br>
		        		</h4>
		        		<h4 style="margin-left:60px">
		        			<b>a.</b> Mise en forme de l&#39;Annonce:<br>
		        		</h4>
		        		<h4 style="margin-left:80px">
		        			<b>(i).</b> Les Annonces doivent être placées dans la section, rubrique et catégorie la plus appropriée. Après le placement de son Annonce, l&#39;Annonceur peut, à tout moment, modifier la section, rubrique et catégorie dans laquelle cette Annonce a été placée.<br>
		        			<b>(ii).</b> Concernant les Annonces relatives aux produits, seul un produit concret peut être demandé ou offert.<br>
		        			<b>(iii).</b> Le titre et le texte des Annonces doivent être rédigés en français sur www.matmaps.be (ou en néerlandais sur 2dehands.be). Lors de la création et à tout moment après le placement de son Annonce, l&#39;Annonceur peut décider d’écrire son Annonce aussi en néerlandais, en choisissant l’option « Oui, j ‘écris mon annonce aussi en néerlandais » lorsqu’il place ou modifie son Annonce.<br>
		        			<b>(iv).</b> Le titre et le texte des Annonces ne peuvent pas être trompeurs, inexacts ou incorrects.<br>
		        		</h4>
		        		<h4 style="margin-left:80px">
		        			<b>(v).</b> Le titre et le texte des Annonces doivent décrire clairement et de manière correcte les produits ou services qui sont offerts, et en particulier leurs caractéristiques et leurs prix. Les règles concernant les méthodes de tarification ou le paiement des Annonces sont décrites cidessous dans le chapitre I, titre 2. 6.<br>
		        			<b>(vi).</b> Les photos reprises dans les Annonces doivent toujours porter sur les produits ou les services offerts. Il n&#39;est pas autorisé de placer des photos dans les Annonces qui porteraient atteinte au droit d&#39;auteur ou au droit à l’image d&#39;un tiers sans le consentement de ce tiers.<br>
		        			<b>(vii).</b> Les Annonces peuvent être placées une seule fois, et ce, quel que soit la section, la rubrique et la catégorie choisie et quelle que soit la Page personnelle utilisée. Il n&#39;est pas autorisé de supprimer et ré-insérer des annonces quotidiennement avant que la période d&#39;annonce initiale soit expirée. Des annonces qui ont été ré-insérées, peuvent être perçus comme du spam par nos visiteurs. Si nous recevons une notification des visiteurs de www.matmaps.be, l&#39;annonce concernée pourrait éventuellement être retirée du site web.<br>
		        			<b>(viii).</b> Les Annonces ne peuvent pas contenir une quantité excessive de caractères ou de mots clés pour attirer l&#39;attention ou accroitre artificiellement la probabilité de leur apparition lors de différentes recherches.
		        		</h4>
		        		<h4 style="margin-left:60px">
		        			<b>b.</b> Contenu non autorisé au sein des Annonces:<br>
		        		</h4>
		        		<h4 style="margin-left:80px">
		        			<b>(i).</b> Les Annonces ne peuvent contenir de réserve quant à l&#39;authenticité des produits ou des services offerts. En effet, les Annonceurs doivent toujours s&#39;assurer que les produits ou les services qu’ils offrent sont authentiques.<br>
		        			<b>(ii).</b> Les Annonces ne peuvent contenir de messages purement commerciaux dont le seul but est de promouvoir, directement ou indirectement, une entreprise.<br>
		        			<b>(iii).</b> Les Annonces ne peuvent mentionner des sites internet ou contenir des liens vers des sites internet qui contiennent entièrement ou partiellement des liens vers d&#39;autres sites internet d&#39;annonces ou vers d&#39;autres annonces qui sont destinées au traitement des revenus publicitaires en générant des clics.<br>
		        			<b>(iv).</b> Lors du placement des Annonces, l&#39;Utilisateur doit prendre en compte les exemples – non exhaustifs – de contenus non autorisés sur le Site Internet, tels que décrits au chapitre I, titre 5, ainsi que les dispositions relatives aux droits de propriété intellectuelle des tiers, tels que décrits dans le chapitre I, point 3.1.4.<br>
		        		</h4>
		        		<h4 style="margin-left:40px">
		        			<b>2.3.2</b> Les Utilisateurs sont présumés connaître la loi et la réglementation applicables aux produits ou aux services qu&#39;ils vendent, achètent ou consultent et, avant de les placer sur le Site Internet, les Annonceurs doivent s&#39;assurer que les produits ou services qu&#39;ils offrent ou demandent, peuvent être vendus, conformément à la loi et à la réglementation en vigueur. En cas de doute, nous vous recommandons de recueillir de plus amples renseignements ou
		        			conseils auprès des autorités compétentes.<br>
		        			<b>2.3.3</b> Lors de la rédaction des Annonces, l&#39;Annonceur a, sous réserve de paiement, la possibilité de promouvoir son Annonce (&quot;Promotion&quot;). Dans ce cas, les Conditions d&#39;utilisation particulières s&#39;appliquent comme décrit au chapitre II, titre 2.<br>
		        			<b>2.3.4</b> Via le Site Internet, l&#39;Annonceur peut aussi placer son Annonce ou créer un renvoi à cette Annonce sur Hyves, Facebook, Twitter et d’autres partenaires de www.matmaps.be Dans ce cas, les règles de ces tiers (notamment concernant la vie privée) s&#39;appliquent comme décrit au chapitre I, titre 6.4. Si vous avez des questions sur les règles des sites Internet de tiers, nous vous renvoyons vers ces tiers.<br>
		        			<b>2.3.5</b> Sauf accord exprès de www.matmaps.be (par exemple, dans le cas des partenaires de l&#39;API), il n&#39;est pas autorisé de:<br>
		        		</h4>
		        		<h4 style="margin-left:60px">
		        			<b>a.</b> placer des Annonces sur le Site Internet via un système automatisé ou d&#39;une autre manière que par le biais de la touche &quot;Placer une annonce&quot; ; ou<br>
		        			<b>b.</b> placer des Annonces au nom ou pour le compte de tiers.<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4 style="margin-left:20px">
		        			<b>2.4</b> Offres
		        		</h4>
		        		<h4 style="margin-left:40px">
		        			<b>2.4.1</b> A moins que les Conditions d&#39;utilisation n’en disposent autrement, une offre portant sur un produit ou sur un service n’est pas contraignante pour l&#39;Annonceur.<br>
		        			<b>2.4.2</b> L&#39;Annonceur n&#39;a aucune obligation d&#39;accepter une offre. Si une offre est acceptée par l&#39;Annonceur, elle n’oblige pas l&#39;offrant à acheter.<br>
		        			<b>2.4.3</b> Il n&#39;est pas autorisé de placer des offres dans le seul but de perturber le processus d&#39;offres (par exemple, des offres « pour le plaisir »).<br>
		        			<b>2.4.4</b> Si en raison de l&#39;expiration du délai de placement ou pour toute autre raison, une Annonce est supprimée, les offres correspondantes seront également supprimées.<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4 style="margin-left:20px">
		        			<b>2.5</b> Evaluations
		        		</h4>
		        		<h4 style="margin-left:40px">
		        			<b>2.5.1</b> Seul un Utilisateur enregistré peut évaluer le comportement d’achat ou de vente d’autres Utilisateurs avec lesquels il a conclu un contrat. Les évaluations pourront alors seulement être placées via l&#39;adresse e-mail avec laquelle les Utilisateurs ont été en contact. Les évaluations du comportement d’achat ou de vente d’un Utilisateur par d’autres Utilisateurs restent sur son profil.<br>
		        			<b>2.5.2</b> www.matmaps.be se réserve le droit de retirer les évaluations suivantes:<br>
		        		</h4>
		        		<h4 style="margin-left:60px">
		        			<b>a.</b> les évaluations ayant un contenu offensant ou sensible au regard de la protection des données personnelles ou injurieux;<br>
		        			<b>b</b>. les évaluations qui n’ont pas de liens avec les prestations d’un Utilisateur;<br>
		        			<b>c</b>. les évaluations données par des Utilisateurs qui ont enfreint certaines règles ou les présentes Conditions d’utilisation ; et<br>
		        			<b>d</b>. les évaluations avec un contenu commercial (par exemple, les évaluations dans lesquelles il est renvoyé à un autre commerçant).<br>
		        		</h4>
		        		<h4 style="margin-left:40px">
		        			<b>2.5.3</b> Si une évaluation – qui correspond à l&#39;une des conditions décrites sous le point précédent – est placée sur votre profil, vous pouvez la signaler via la procédure décrite au chapitre I, paragraphe 5.1.<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4 style="margin-left:20px">
		        			<b>2.6</b> Les règles concernant les méthodes de tarification ou de paiement au sein des Annonces<br>
		        		</h4>
		        		<h4 style="margin-left:40px">
		        			<b>2.6.1</b> Dans une Annonce, l&#39;Annonceur ne peut pas obliger un Utilisateur à utiliser certaines méthodes de paiement. Cliquez ici pour en savoir plus sur le paiement sécurisé.<br>
		        			<b>2.6.2</b> L&#39;Annonceur doit toujours mentionner le prix total dans le champ de l&#39;Annonce réservé au prix. Les Annonceurs qui offrent des produits ou services aux consommateurs en tant commerçants doivent mentionner les prix totaux en ce compris tous les impôts et tous les coûts de transport, livraison, frais de port et autres frais éventuels.<br>
		        			<b>2.6.2</b> L&#39;Annonceur doit toujours mentionner le prix total dans le champ de l&#39;Annonce réservé au prix. Les Annonceurs qui offrent des produits ou services aux consommateurs en tant commerçants doivent mentionner les prix totaux en ce compris tous les impôts et tous les coûts de transport, livraison, frais de port et autres frais éventuels.<br>
		        		</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4><b>3.</b> Droits et obligations</h4>
		        	</div>
		        	<div class="col-md-12">
		        		<h4 style="margin-left:20px"><b>3.1</b> L&#39;Utilisateur<br></h4>
		        		<h4 style="margin-left:40px"><b>3.1.1</b> L&#39;Utilisateur garantit qu&#39;il dispose des droits de propriété intellectuelle sur le contenu qu&#39;il publie sur le Site Internet, en ce compris mais sans s&#39;y limiter, les droits d&#39;auteurs, les
		        		droits voisins, les droits de marque, les brevets, les dessins et modèles, les droits sur les noms commerciaux, la protection des banques de données ainsi que les droits relatifs à la protection du savoir-faire (les &quot;Droits de propriété intellectuelle&quot;).<br></h4>
		        		<h4 style="margin-left:40px"><b>3.1.2</b> L&#39;Utilisateur concède :</h4>
		        		<h4 style="margin-left:60px"><b>a.</b> à www.matmaps.be une licence gratuite, mondiale, non exclusive, cessible et sous-licenciable d&#39;utiliser, publier et reproduire, par un moyen connu ou futur, le contenu dans le cadre du fonctionnement et de la promotion de notre Service et de celui de tiers. www.matmaps.be se réserve le droit de modifier techniquement le contenu, et en particulier le contenu des Annonces, de manière à ce qu&#39;elles soient accessibles par divers canaux, par exemple les téléphones portables; et<br>
		        		<b>b.</b> aux autres Utilisateurs une licence gratuite, mondiale et non-exclusive pour utiliser, publier et reproduire le contenu dans le cadre de l&#39;utilisation du Service.<br><h4>
		        		<h4 style="margin-left:40px"><b>3.1.3</b> Les licences accordées en conformité avec le point précédent prennent fin lorsque le contenu du Site Internet est retiré par www.matmaps.be ou l&#39;Utilisateur.<br></h4>
						<h4 style="margin-left:40px"><b>3.1.4</b> L&#39;Utilisateur ne peut pas reproduire dans les Annonces des produits ou services qui portent atteinte aux Droits de propriété intellectuelle de tiers. Cela signifie par exemple que:<br></h4>
		        		<h4 style="margin-left:60px"><b>a.</b> il est interdit d&#39;offrir des produits ou des services qui portent atteinte aux:<br></h4>
		        		<h4 style="margin-left:80px"><b>(i).</b> droits d&#39;auteur d&#39;un tiers, tels que la fourniture d&#39;un logiciel développé par un tiers ou des
		        		œuvres musicales, photographiques ou de peintures créées par un tiers sans l&#39;autorisation de ce tiers;<br>
		        		<b>(ii).</b> droits de marque d&#39;un tiers, par exemple en offrant un vêtement sur lequel un logo d&#39;un tiers est reproduit sans l&#39;autorisation de ce tiers; ou<br>
		        		<b>(iii).</b> droits de modèle d&#39;un tiers, par exemple en offrant un sac qui est reproduit sans l&#39;autorisation de ce tiers;<br>ou<br>
		        	</h4>
		        	<h4 style="margin-left:60px">
		        		<b>b.</b> ne peuvent figurer dans le titre et / ou le texte d&#39;une Annonce, par exemple, que:<br>
		        	</h4>
		        	<h4 style="margin-left:80px">
		        		<b>(i).</b> le nom de la marque des produits ou services qui sont réellement offerts ou demandés dans l&#39;Annonces; ou<br>
		        		<b>(ii).</b> ii. le nom commercial de l&#39;entreprise d&#39;où le produit ou le service concerné provient. Il est interdit de mentionner un nom commercial qui n&#39;a pas de liens avec les produits ou les services qui sont offerts dans l&#39;Annonce;<br>ou<br>
		        	</h4>
		        	<h4 style="margin-left:60px;">
		        		<b>c.</b> les produits ou services offerts ne peuvent pas être comparés avec d&#39;autres produits ou services dans le titre des Annonces. Dans le reste du contenu de l&#39;Annonce, une comparaison ne peut en aucune manière créer une confusion concernant l&#39;origine commerciale des produits ou services offerts.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.1.5</b> Rien de ce qui est mentionné dans les Conditions d&#39;utilisation ou sur le Site Internet ne peut être interprété comme conférant à l&#39;Utilisateur des droits plus larges d&#39;utiliser le Service.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>3.2</b> www.matmaps.be<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.2.1</b> À l’exception du contenu qui est publié par les Utilisateurs et les tiers sur le Site Internet, www.matmaps.be et ses donneurs de licence détiennent les Droits de propriété intellectuelle sur le Service.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.2.1</b> À l’exception du contenu qui est publié par les Utilisateurs et les tiers sur le Site Internet, www.matmaps.be et ses donneurs de licence détiennent les Droits de propriété intellectuelle sur le Service.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.2.2</b> www.matmaps.be accorde aux Utilisateurs une licence limitée, personnelle, révocable, non exclusive, non cessible et non sous-licenciable pour utiliser le contenu inséré conformément à l’objet du Service.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.2.3</b> www.matmaps.be et ses donneurs de licence se réservent tous les droits, dont le droit d&#39;extraire une partie non-substantielle du contenu du Site Internet de manière répétée et systématique et de la réutiliser au sens de la loi sur la protection des bases de données.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.2.4</b> Si vous visitez le Site Internet via un appareil mobile et qu&#39;en outre vous utilisez l&#39;application de www.matmaps.be (l&#39; &quot;Application&quot;), www.matmaps.be vous donne uniquement le droit d&#39;utiliser cette Application pour un usage personnel. L&#39;Application ne permet pas d&#39;offrir aux Utilisateurs les mêmes fonctionnalités que celles disponibles sur le Site Internet.<br>
		        		2dehands.be est le propriétaire ou le titulaire de licence de tous les droits sur son
		        		Application, en ce compris tous les Droits de propriété intellectuelle applicables et tous les autres droits de propriété, en ce compris les demandes, renouvellements, extensions, et les procédures de restaurations qui y sont applicables.<br>
		        	</h4>
		        	<h4>
		        		<b>4.</b> Utilisation non autorisée du Site Internet et de l&#39;Application<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>4.1</b> Il n&#39;est, par exemple, pas permis de publier sur le Site Internet, en ce compris dans les
		        		Annonces, un contenu :<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>(i).</b> qui contient un lien ou du matériel pornographique ou contraire d’une autre façon à l’ordre public et aux bonnes mœurs;<br>
		        		<b>(ii).</b> qui est discriminatoire sur base de l’opinion politique, de la religion, de la race, du sexe, de la nationalité, de l’orientation ou qui est autrement blessant, offensant, menaçant ou provocateur;<br>
		        		<b>(iii).</b> qui est (sexuellement) intimidant;<br>
		        		<b>(iv).</b> qui est incorrect, trompeur ou incomplet;<br>
		        		<b>(v).</b> qui vise à faire une blague ou à harceler quelqu&#39;un;<br>
		        		<b>(vi).</b> dans lequel des données à caractère personnel de tiers sont traitées;<br>
		        		<b>(vii).</b> concernant des chaînes de lettres, des pourriels ou des spams;<br>
		        		<b>(viii).</b> qui contient des virus, des vers, des chevaux de Troie, des &#39;cancelbots&#39; ou d’autres logiciels pouvant nuire au Service ou aux droits et intérêts des Utilisateurs;<br>
		        		<b>(ix).</b> qui surcharge ou perturbe le bon fonctionnement de l’infrastructure du Site Internet de façon déraisonnable;<br>
		        		<b>(x).</b> qui implique des activités commerciales sans le consentement écrit préalable de www.matmaps.be, en ce compris des loteries, des concours et des jeux de pyramide;<br>
		        		<b>(xi).</b> qui incite ou constitue des activités illégales;<br>
		        		<b>(xii).</b> qui viole les Droits de propriété intellectuelle, le respect de la vie privée ou tout autre droit de www.matmaps.be, ses donneurs de licence, ses Utilisateurs ou des tiers;<br>
		        		<b>(xiii).</b> qui concerne les produits ou services dont le commerce ou la livraison est contraire à la loi et à la réglementation en vigueur et l&#39;offre ou la demande qui, suivant la liste indicative des produits ou services interdits ou soumis à des limitations, est interdite ou limitée sur le Site Internet ; et<br>
		        		<b>(xiv).</b> avec lequel www.matmaps.be ne peut raisonnablement pas être d’accord pour toute autre raison que celles citées ci-dessus.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>4.2</b> Le contenu du Site Internet ne peut pas être reproduits et/ou communiqués au public par l’Utilisateur, à l&#39;exception des flux RSS pour un usage personnel et/ou des nouvelles pour un nombre maximum de 100 Annonces ou 100 liens vers des Annonces, tel que pour l&#39;utilisation de blogs-web personnels ou autres sites personnels.<br>
		        		<b>4.3</b> L’Utilisateur ne peut pas extraire ni réutiliser des parties substantielles du contenu de la base de données des Annonces, ni extraire ou réutiliser des parties non substantielles du contenu de la base de données des Annonces au sens de la loi sur les bases de données, à moins qu’une autorisation écrite préalable de www.matmaps.be n’ait été obtenue, ou à moins que l&#39;exception pour usage personnel ou pour les nouvelles ne soit remplie.<br>
		        		<b>4.4</b> En ce qui concerne l&#39;Application, les opérations ou les interventions ci-dessous ne sont pas permises:<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>(i).</b> la modification, l’adaptation, la traduction, la création d’œuvres dérivées, la dissolution, la reconstruction (par ‘reverse engineering’), le démontage ou toutes autres manières en vue de récupérer le code source de l&#39;Application;<br>
		        		<b>(ii).</b> la modification, la copie, la publicité, l’octroi de licences, la vente ou tout autre moyen de commercialisation de l&#39;Application ou toute information en rapport avec (ou logiciel lié à) l’Application;<br>
		        		<b>(iii).</b> la location, le prêt ou tout autre moyen de transférer des droits sur l&#39;Application ;<br>
		        		<b>(iv).</b> la suppression, l&#39;altération ou la modification de la notice de www.matmaps.be, concernant ses droits d&#39;auteur, droits de marques ou autres droits de propriété y attachés, contenue dans ou distribuée avec l&#39;Application ; et<br>
		        		<b>(v).</b> l’utilisation de l&#39;Application d&#39;une façon qui peut affecter le Site Internet d’une quelconque manière ou perturber l&#39;usage du Site Internet par d’autres parties.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>4.5</b> L’application doit être utilisée en conformité avec les lois et règlements en vigueur.<br>
		        		<b>4.6</b> L&#39;Utilisateur ne peut reproduire des messages purement commerciaux sur le Site Internet à moins qu’il n’ait reçu une autorisation écrite préalable de www.matmaps.be ou à moins que l&#39;exception pour usage personnel ou pour les nouvelles ne soit remplie.<br>
		        		<b>4.7</b> L’Utilisateur ne peut pas modifier le Site Internet d’une autre façon que celle décrite dans les Conditions d’utilisation.<br>
		        	</h4>
		        	<h4>
		        		<b>5.</b> Utilisation abusive du Site Internet et de l’Application et les conséquences y afférentes<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>5.1</b> Via le bouton « Rapporter un Abus », vous pouvez à tout moment nous envoyer un message concernant l’utilisation abusive du Site Internet, par exemple si vous découvrez sur le Site Internet un contenu qui n’est pas conforme aux Conditions d’utilisation. Vous devez alors compléter les données suivantes dans le formulaire de notification :<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>(a).</b> les raisons de votre notification contenant une explication claire de l’abus constaté;<br>
		        		<b>(b).</b> le lien vers l’Annonce concernée;<br>
		        		<b>(c).</b> une explication démontrant que le contenu concerné contrevient aux règles relatives à la protection de votre vie privée ou tout autre de vos droits.<br>
		        		Si vous être d’avis que le contenu contrevient à vos droits de propriété intellectuelle, alors vous pouvez utiliser le formulaire particulier de notification d’atteinte à la propriété intellectuelle.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>5.2</b> Selon la nature et la gravité de l’infraction, www.matmaps.be peut ou non, à son gré et sans aucune justification, notamment prendre les mesures suivantes, suite aux messages et aux plaintes des Utilisateurs et des tiers<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>(a).</b> retirer le contenu placé par l’Utilisateur concerné, comme son Annonce ou sa Page Personnelle. Le retrait des évaluations est uniquement possible suivant les cas décrits au chapitre I, titre 2,5;<br>
		        		<b>(b).</b> limiter ou mettre fin à l’utilisation du Service à l’égard des Utilisateurs concernés, dont l’accès au Site Internet ou à certaines de ces fonctionnalités;<br>
		        		<b>(c).</b> limiter ou mettre fin à l’utilisation de l’Application à l’égard des Utilisateurs concernés;<br>
		        		<b>(d).</b> communiquer les données personnelles des Utilisateurs concernés à certains tiers tels que décrit dans la politique sur le respect de la vie privée et en particulier au Procureur du Roi conformément à l’article XII. 19, §3 du Code de droit économique.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>5.3</b> www.matmaps.be se réserve le droit d’engager des poursuites judiciaires et, pour autant que l’utilisation abusive du Site Interne ait induit un dommage, de réclamer un dédommagement à l’Utilisateur concerné.<br>
		        		<b>5.4</b> Par ailleurs, www.matmaps.be est un prestataire de services qui fournit un service d’hébergement conformément à l’article XII. 9, §1 du Code de droit économique, elle n’est dès lors pas en mesure et pas obligée de surveiller le contenu qui est placé par les Utilisateurs et les tiers sur le Site Internet.<br>
		        		www.matmaps.be n’est par ailleurs pas partie ou d’une quelconque autre manière impliquée dans l&#39;exécution des contrats entre Utilisateurs ou ceux entre les Utilisateurs et les tiers. C’est pourquoi les Utilisateurs doivent résoudre leurs conflits ou les conflits avec des tiers entre eux, sans intervention de www.matmaps.be.
		        	</h4>
		        	<h4>
		        		<b>6.</b> Responsabilité<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>6.1</b> Limitation de la responsabilité de www.matmaps.be<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.1.1</b> Pour autant que la loi le permette, www.matmaps.be exclut toute responsabilité pourtoute forme de dommage, direct ou indirect, que l&#39;Utilisateur subit ou a subi du fait de:<br>
		        	</h4>
		        	<h4 style="margin-left:60px">
		        		<b>(a).</b> l&#39;utilisation du Service;<br>
		        		<b>(b).</b> la non-disponibilité, ou la disponibilité non sécurisée du Site Internet ou de certaines parties du Site Internet;<br>
		        		<b>(c).</b> d&#39;informations incorrectes sur le Site Internet;<br>
		        		<b>(d).</b> l&#39;utilisation de produits ou l&#39;achat de services par l&#39;intermédiaire du Site Internet;<br>
		        		<b>(e).</b> modifications au Service et/ou modifications du Site Internet; ou<br>
		        		<b>(f).</b> l&#39;utilisation de l&#39;Application.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.1.2</b> www.matmaps.be décline en tous les cas toute responsabilité pour des dommages particuliers, indirects et collatéraux qui sont liés à l&#39;utilisation et au fonctionnement du Service ou de l&#39;Application, parmi lesquels notamment l&#39;atteinte à l&#39;honneur et à la réputation, la perte de profit ou la perte de données personnelles.<br>
		        		<b>6.1.3</b> Si, pour toute raison autre que celles mentionnées aux points précédents,
		        		www.matmaps.be voyait sa responsabilité engagée, sa responsabilité par rapport à un
		        		Utilisateur est limitée au maximum:<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>(a).</b> au montant total des frais que l&#39;Utilisateur a payés à www.matmaps.be durant les 12 mois précédent l&#39;acte ayant causé le dommage; ou<br>
		        		<b>(b).</b> 100 euros, si le montant total est supérieur à 100 euros.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.1.4</b> L&#39;action en dommages et intérêts dans le chef de l&#39;Utilisateur se prescrit après l&#39;écoulement de 12 mois à compter du moment où l&#39;acte causant le dommage s&#39;est produit.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.1.5</b> www.matmaps.be est un prestataire de services qui fournit des services consistant à stocker des informations fournies par un destinataire du service au sens de l&#39;article XII. 19, §1 du Code de droit économique. Cela implique notamment que www.matmaps.be n&#39;a pas le pouvoir ni l&#39;obligation d&#39;effectuer un contrôle sur la légalité des produits ou services offerts dans les Annonces, ou sur la capacité de contracter ou la capacité en général de ses Utilisateurs.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>6.2</b> Nous ne donnons pas de garanties<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.2.1</b> www.matmaps.be ne peut pas garantir que les produits et services qui sont offerts par les Annonceurs sur le Site Internet correspondent en tous points aux attentes de l&#39;Utilisateur.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.2.2</b> Vu que la plupart du contenu du Site Internet émane des autres Utilisateurs, www.matmaps.be n&#39;offre aucune de garantie concernant:<br>
		        	</h4>
		        	<h4 style="margin-left:60px">
		        		<b>(a).</b> l&#39;exactitude et la précision des Annonces et autres messages;<br>
		        		<b>(b).</b> la qualité, la sécurité et la légalité des produits ou services offerts;<br>
		        		<b>(c).</b> la capacité des Annonceurs de contracter, et la capacité des Utilisateurs d&#39;acheter des produits ou services; et<br>
		        		<b>d.</b> la capacité des Utilisateurs à payer le prix convenu pour les produits ou services achetés.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.2.3</b> www.matmaps.be n&#39;offre aucune garantie quant à la disponibilité ou à la sécurité du Service.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>6.3</b> Modifications du Site Internet, du Service et de l&#39;Application de www.matmaps.be<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.3.1</b> www.matmaps.be se réserve le droit de modifier à tout moment le Site Internet, ou certaines de ses parties.<br>
		        		<b>6.3.2</b> www.matmaps.be se réserve le droit de modifier ou terminer à tout moment le Service. Une modification éventuelle ou la terminaison éventuelle du Service sera annoncée dans un délai raisonnable à sa mise en œuvre.<br>
		        		<b>6.3.3</b> www.matmaps.be se réserve le droit de modifier ou terminer à tout moment
		        		l&#39;Application, ou certaines de ses parties.
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>6.4</b> Sites internet et services de tiers</h4>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.4.1</b> Le Site Internet, le Service ou l&#39;Application peuvent contenir des liens (par exemple des hyperliens ou bannières) vers, ou peuvent faire utilisation de sites internet et services de tiers qui ne sont pas la propriété de www.matmaps.be, et qui ne sont pas contrôlés par www.matmaps.be (par exemple Google Maps API).<br>
		        		www.matmaps.be n&#39;a aucun contrôle sur, et n&#39;est pas responsable du contenu, des politiques, des conditions d&#39;utilisation ou du fonctionnement des sites internet ou des services de quelque tiers que ce soit. Si vous utilisez ceux-ci, vous êtes soumis à la politique et aux conditions d&#39;utilisation d&#39;application prévue par ces tiers.<br>
		        		Au cas où vous utilisez le Service ou l&#39;Application qui fonctionnent sur base des services de Google (par exemple Google Maps API), vous acceptez d&#39;être lié par les conditions d&#39;utilisation de Google.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.4.2</b> Si l&#39;Application fait usage du système d&#39;exploitation iOS d&#39;Apple, vous devez prendre en considération les conditions d&#39;utilisation et les politiques suivantes:
		        	</h4>
		        	<h4 style="margin-left:60px">
		        		<b>i.</b> Apple n&#39;est pas partie aux Conditions d&#39;utilisation ni au Contrat d&#39;Annonces existant entre www.matmaps.be et vous. Apple n&#39;est pas responsable de l&#39;Application ni de son contenu;<br>
		        		<b>ii.</b> www.matmaps.be vous octroie seulement le droit d&#39;utiliser l&#39;Application sur un produit iOS dont vous êtes le propriétaire ou dont vous avez le contrôle, et conformément à ce qui est autorisé par les règles d&#39;utilisation établies dans les conditions d&#39;utilisation de l&#39;App Store;<br>
		        		<b>iii.</b> Apple n&#39;a aucune obligation de fournir des services de maintenance ou de support en relation avec l&#39;Application;<br>
		        		<b>iv.</b> Apple n&#39;est pas responsable de défense, de l&#39;examen ou du règlement des réclamations relative à des droits intellectuels introduite par un tiers quel qu&#39;il soit;<br>
		        		<b>v.</b> Apple n&#39;est pas responsable de la gestion de toute réclamation introduite par vous ou par un tiers en rapport avec l&#39;Application ou sur la base de votre utilisation de l&#39;Application, y compris, mais pas exclusivement: des réclamations non-conformité de l&#39;Application avec la législation et la réglementation en vigueur; et des réclamations concernant la protection des
		        		consommateurs ou des réclamations fondées sur des législations similaires;<br>
		        		<b>vi.</b> Si l&#39;Application ne satisfait pas aux garanties applicables, vous pouvez en informer Apple. Apple vous remboursera le prix d&#39;achat de l&#39;Application, si le remboursement est d&#39;application. Dans la mesure autorisée par la loi applicable, Apple n&#39;aura aucune autre obligation en relation avec l&#39;Application;<br>
		        		<b>vii.</b> Apple et ses filiales sont des tiers-bénéficiaires de ces Conditions d&#39;utilisation, et par votre acceptation des Conditions d&#39;utilisation, vous acceptez qu&#39;Apple est en droit, en tant que tiers-bénéficiaire (et Apple sera présumée avoir accepté ce droit) d&#39;invoquer ces Conditions d&#39;utilisation à votre encontre.<br>
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>6.4.3</b> Par l&#39;utilisation du Site Internet, du Service ou de l&#39;Application, vous exonérez expressément www.matmaps.be de toute responsabilité qui découlerait de votre utilisation de quelque site internet ou service de tout tiers que ce soit et vers lequel un accès vous serait donné via le Site internet, le Service ou l&#39;Application qui l&#39;héberge.<br>
		        		L&#39;Utilisateur exonère www.matmaps.be de sa responsabilité envers les tiers en rapport avec les dommages subis par:<br>
		        	</h4>
		        	<h4 style="margin-left:60px">
		        		<b>a.</b> la passation d&#39;une convention sur la base d&#39;une Annonce; et<br>
		        		<b>b.</b> l&#39;utilisation de produits ou services offerts via le Site Internet.<br>
		        	</h4>
		        	<h4>
		        		<b>7.</b> Règlement des plaintes<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>7.1</b> En cas de plaintes au sujet du fonctionnement du Service, l&#39;Utilisateur peut contacter www.matmaps.be via le formulaire de contact ou par e-mail (redactie@2dehands.be). Les plaintes doivent être introduites par l&#39;Utilisateur auprès www.matmaps.be dans un délai raisonnable et au plus tard dans les 2 mois de la constatation d&#39;un défaut en rapport avec le Service.<br>
		        		<b>7.2</b> Les plaintes doivent être aussi complètes que possible et doivent être clairement rédigées. Lors de l&#39;introduction de votre plainte, vous devez inscrire le mot &quot;plainte&quot; dans le champ réservé à la description de votre question dans le formulaire de contact ou dans le titre de votre e-mail.<br>
		        		<b>7.3</b> Après réception de la plainte, www.matmaps.be vous confirmera la bonne
		        		réception de votre plainte et vous serez informé dans les cinq jours ouvrables à
		        		propos des délais dans lesquels vous recevrez de notre part une proposition en vue
		        		de la solution du problème. Nous ferons de notre mieux pour résoudre les plaintes
		        		introduites le plus vite possible.<br>
		        	</h4>
		        	<h4>
		        		<b>8.</b> Autres dispositions
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>8.1</b> Les Conditions d&#39;utilisation sont applicables au Contrat d&#39;Annonces. Les conventions orales ne sont pas opposables.<br>
		        		<b>8.2</b> Si www.matmaps.be n&#39;applique pas immédiatement une ou plusieurs dispositions des Conditions d&#39;utilisation, il ne peut en être déduit aucune renonciation à quelques droits que ce soit.<br>
		        		<b>8.3</b> Si une ou plusieurs dispositions des Conditions d&#39;utilisation sont nulles, cela n&#39;entache pas la validité des autres dispositions.
		        		8.4 Les Conditions d&#39;utilisation et le Contrat d&#39;Annonces forment la totalité du contrat entre www.matmaps.be et vous, et remplacent toutes les autres conventions. Les Conditions d&#39;utilisation et les conventions qui découlent de tous les services de www.matmaps.be de même que les litiges éventuels qui en découleraient doivent être compris et interprétés conformément au droit belge.<br> 
		        		Nous tenterons de résoudre tous les litiges éventuels qui découleraient de ces conventions à l&#39;amiable avant de les amener au tribunal qui est compétent pour en connaître à Bruxelles. Si l&#39;Utilisateur le souhaite, le litige peut être soumis au comité de surveillance de BeCommerce.<br>
		        		<b>8.5</b> Pour les questions relatives à l&#39;utilisation et au fonctionnement du Service, les Utilisateurs peuvent contacter www.matmaps.be via le formulaire de contact ou par e-mail (redactie@2dehands.be).<br>
		        	</h4>
		        	<h4>
		        		<b>II.</b> Conditions particulières d&#39;utilisation<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>1.</b> Général
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>1.1</b> Pour les catégories &quot;Annonces Payantes&quot; et &quot;Voitures&quot;, les présentes contions particulières d&#39;utilisation (les &quot;Conditions particulières d&#39;utilisation&quot;) sont applicables.<br>
		        		<b>1.2</b> Les Conditions particulières d&#39;utilisation ont priorité sur les dispositions des Conditions d&#39;utilisation, qui demeurent applicables pour le surplus.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>2.</b> Annonces payantes
		        	</h4>
		        	<h4 style="margin-left:40px">
		        		<b>2.1</b> L&#39;Annonceur a la possibilité de promouvoir des Annonces (&quot;Annonces payantes&quot;), moyennant le payement d&#39;un tarif (&quot;Tarif d&#39;Annonces&quot;). Pour les Annonces payantes, le Contrat d&#39;Annonces entre en vigueur au moment où la procédure de payement est achevée sur le site internet du prestataire de services de paiements.<br>
		        		<b>2.2</b> L&#39;Annonceur dispose ou non, en fonction de la Promotion choisie, du droit de se rétracter de son achat. Cliquez ici pour plus d&#39;informations concernant l&#39;application du droit de rétractation.
		        		<b>2.3</b> Un Annonceur peut, moyennant le payement du Tarif d&#39;Annonces par Annonce, placer son Annonce au sommet de la liste des Annonces (le &quot;Placement au Sommet&quot;). Le Placement au Sommet d&#39;une Annonce se produit après le payement du Tarif d&#39;Annonces. Quelques minutes peuvent être nécessaires avant que l&#39;Annonce soit placée au sommet.<br>
		        		<b>2.4</b> Cliquez ici pour consulter les autres Promotions disponibles et pour les Tarifs d&#39;Annonces applicables à ces Promotions. www.matmaps.be peut à tout moment modifier le Tarif d&#39;Annonces des Annonces payantes.<br>
		        		<b>2.5</b> Si l&#39;Annonceur place son annonce au sommet par le biais d&#39;une autre Promotion disponible et que cette Annonce ne satisfait pas aux Conditions (particulières) d&#39;utilisation, l&#39;Annonce concernée peut être retirée. L&#39;Annonceur n&#39;a en ce cas aucun droit de récupérer le Tarif d&#39;Annonces de l&#39;Annonce Payante.<br>
		        		<b>2.6</b> Dans l&#39;hypothèse de dysfonctionnements techniques, comme la non-disponibilité du Site internet, ou dans tous les autres cas de force majeure, www.matmaps.be n&#39;est pas responsable des dommages qui découlent du fait que les Annonces Payantes n&#39;ont pas été affichées. L&#39;Annonceur n&#39;a dans ces cas aucun droit de récupérer le Tarif d&#39;Annonces de l&#39;Annonce payante. Les plaintes relatives au fonctionnement du Service peuvent être introduite selon la procédure décrite au chapitre I, titre 7.<br>
		        	</h4>
		        	<h4 style="margin-left:20px"><b>3.</b> Voitures</h4>
		        	<h4 style="margin-left:40px">
		        		<b>3.1</b> Chaque Annonce ne peut concerner qu&#39;une seule voiture. Il n&#39;est donc pas autorisé d&#39;offrir plusieurs voitures à la vente dans une Annonce, et/ou de réutiliser l&#39;Annonce après la vente de la voiture pour une autre voiture.<br>
		        		<b>3.2</b> Chaque Annonce doit être placée dans la bonne catégorie. Il n&#39;est pas autorisé de mentionner dans l&#39;Annonce d&#39;autres marques ou modèles de voitures que ceux qui sont effectivement offerts à la vente. Il n&#39;est donc pas autorisé de mentionner dans l&#39;Annonce toutes les marques et tous les modèles que l&#39;Annonceur peut offrir par ailleurs.<br>
		        		<b>3.3</b> Le titre et le texte de l&#39;Annonce doivent décrire précisément et clairement l&#39;a voiture offerte à la vente, en particulier en ce qui concerne le prix et la propriété.<br>
		        		<b>3.4</b> Il est interdit d&#39;utiliser une photo autre que celle de la voiture offerte à la vente. Il est donc interdit d&#39;utiliser une photo originaire d&#39;un site internet ou d&#39;un catalogue de la marque de la voiture.<br>
		        		<b>3.5</b> Il est interdit de mentionner dans le champ réservé au prix dans l&#39;Annonce un autre montant que le prix total (p.ex l&#39;acompte de la voiture ou un prix mensuel en cas de leasing).<br>
		        		<b>3.6</b> Il est interdit de placer une Annonce sous la rubrique &quot;Voitures&quot; dans laquelle aucune voiture n&#39;est offerte à la vente, telle une Annonce relative à une assurance voiture, ou à d&#39;autres services relatifs à des voitures. De telles Annonces doivent être placées dans larubrique &quot;pièces de voiture&quot; sous la rubrique &quot;Accessoires de voiture&quot;.<br>
		        		<b>3.7</b> Il est interdit de faire de la publicité dans une Annonce pour, ou renvoyer vers, d&#39;autres sites internet avec des rubriques de publicité pour voitures.<br>
		        		<b>3.8</b> Si la voiture offerte à la vente dans l&#39;Annonce est vendue, l&#39;Annonceur doit retirer l&#39;Annonce concernée.<br>
		        	</h4>
		        	<h4 style="margin-left:20px">
		        		<b>Conditions générales d&#39;utilisation</b>
		        	</h4>
		        	<h4 style="margin-left:20px"><b>1.2</b> Vie privée</h4>
		        	<h4 style="margin-left:20px">
		        		Dans notre politique sur le respect de la vie privée, nous expliquons comment nous traitons vos données personnelles et quelles sont les mesures que nous prenons pour protéger votre vie privée quand vous utilisez notre Site Internet.<br>
		        		Comme décrit dans notre politique sur le respect de la vie privée, vous nous autorisez à traiter vos données personnelles.<br>
		        		Dans ce cadre, www.matmaps.be souhaite attirer votre attention sur le fait que les
		        		présentes Conditions d&#39;utilisation et la politique sur le respect de la vie privée interdisent la collecte (par exemple le &#39;harvesting&#39;) des données personnelles des Utilisateurs, parmi lesquelles l&#39;adresse e-mail et les numéros de téléphone, ainsi que le fait d&#39;inciter des Utilisateurs à offrir leurs propres produits ou services en dehors de la plate-forme de négociation de www.matmaps.be
		        	</h4>
	        	</div>
	        </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>