<?php
include '../inc/db.php';
if (is_array($_FILES)) {
	if (is_uploaded_file($_FILES['productImage']['tmp_name'])) {
		// $ext         = findexts($_FILES['productImage']['name']);
		$fileName = str_replace(' ', '-', strtolower($_FILES['productImage']['name']));
		$ext 	  = ".".pathinfo($fileName, PATHINFO_EXTENSION);
		if ($ext != ".png" && $ext != ".jpg" && $ext != ".jpeg") {
			echo json_encode(array("success"=> false, "message"=>"Wrong Format (Only .png, .jpg and .jpeg are allowed)"));
			die();
		}
		$sourcePath = $_FILES['productImage']['tmp_name'];
		$fileName = str_replace(' ', '-', strtolower($_FILES['productImage']['name']));
		$RandomNum = rand(11111, 99999);
		$fileName = preg_replace("/\.[^.\s]{3,4}$/", "", $fileName);
		$imgname = $fileName . '-' . $RandomNum . '' . $ext;
		
		// $email 		 = $_SESSION['email'];
		// $select_id 	 = "SELECT * FROM construction WHERE email='$email' ORDER BY id DESC";
		// $selected_id = $conn->query($select_id);
		// $row 		 = $selected_id->fetch_assoc();
		// $id 		 = $row['id'];
		// $id 		 = $_POST['postId'];
		// $imgname	 = $id.'.'.$ext;

		// $update_img  = "UPDATE construction SET good_image='$imgname' WHERE id='$id'";
		// $updated 	 = $conn->query($update_img);

		$targetPath  = "../construction/".$imgname;

		if (move_uploaded_file($sourcePath, $targetPath)) {
			echo json_encode(array("success"=> true, "name"=> $imgname));
		}
	}
}

function findexts($filename){ 
	$filename = strtolower($filename) ; 
	$exts = split("[/\\.]", $filename) ; 
	$n = count($exts)-1; 
	$exts = $exts[$n]; 
	return $exts; 
}