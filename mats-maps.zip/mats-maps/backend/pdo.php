<?php
/*Common Functions
 *CRUD - qInsert, qSelect, qUpdate, qDelete & qExecute
 *unsetSession($array) - pass muliple parameters to
 *                       function in form of array
 */
error_reporting(0);
$timezone = "Asia/Calcutta";
date_default_timezone_set($timezone);
$datetime = date('d-m-Y H:i:s');
$date = date('Y-m-d');

if (!session_id())
	session_start();

function &getConnection() {
	// $db = new PDO('mysql:host=localhost;dbname=ambulance', 'root', '1234'); //local
    $db = new PDO('mysql:host=52.66.163.164;dbname=mat_and_maps', 'ambulance', 'amb_app1@dn'); //server
	return $db;
}


function getLastError() {
	global $rs;
	$error = $rs->errorInfo();
	return $error[2];
}


function qExecute($sql)
{
    global $db;
    //echo $sql;
    /*$rs = $db->prepare($sql);
    $rs->execute();
    $err = getLastError();
    if ($err && $err != '') {
        return 0;
    }
    return $rs->fetch();*/
    return $db->query($sql);
}

function qExecuteAssocArray($sql)
{
	global $db;
	$rs = $db->query($sql);
    return $rs->fetchAll(PDO::FETCH_ASSOC);
}

function qExecuteObject($table,$col,$where="",$order=""){
    global $rs;
    $rs = $db->query($sql);
    return $rs->fetch(PDO::FETCH_OBJ);
}

function qSelect($table,$col,$where="",$order="")
{
	global $db;
	global $rs;
    $sql = "SELECT $col FROM `$table`";
    if($where!="")
    {
    	$whr = " WHERE ";
    	$i=1;
    	$len = count($where);
    	foreach($where as $key=>$v)
        {
            $whr .="$key='$v'";
            if($i!=$len)
                $whr.=" and ";
            $i++;
        }
        $sql.=" $whr";
    }
    if($order!="")
    {
    	$sql.=" ORDER BY $order";
    }
    $rs = $db->prepare($sql);
    $rs->execute();
	return $rs->fetch();
}

function qSelectObject($table,$col,$where="",$order=""){
	global $rs;
	qSelect($table,$col,$where,$order);
	$rs->execute();
	return $rs->fetch(PDO::FETCH_OBJ);
}

function qSelectAssocArray($table,$col,$where="",$order="") {
	global $rs;
	qSelect($table,$col,$where,$order);
	$rs->execute();
	$rs->setFetchMode(PDO::FETCH_ASSOC);
	//return $rs->fetch(PDO::FETCH_ASSOC);
	return $rs->fetchAll();
}

function qInsert($table,$values)
{
	global $db;
	global $rs;
	$col = "";
	$val = "";
	foreach($values as $k=>$v)
	{
		$col .= "$k,";
		$val .= "'$v',";
	}
	$col = trim($col, ",");
	$val = trim($val, ",");
	$sql = "insert into `$table` ($col) values ($val)";
	$rs = $db->prepare($sql);
	$rs->execute();
	$err = getLastError();
	if ($err && $err != '') {
		return 0;
	}
	return $db->lastInsertId();
}

function qUpdate($table,$values,$zupd_var,$zupd_val)
{
    global $db;
    $val = "";
    foreach($values as $key=>$v)
    {
        $val .= "$key='$v',";
    }
    $val = trim($val,',');
    return $db->query("update $table set $val where $zupd_var='$zupd_val'");
}

function qUpdateMultiCondition($table,$values,$zupd_values="") {
    global $db;
    $val = "";
    foreach($values as $key=>$v)
    {
        if ($v)
            $val .= "$key='$v',";
        else
            $val .= "$key=NULL,";
    }
    $val = trim($val,',');
	$whr = "";
	if($zupd_values!="")
    {
        $len = count($zupd_values);
        $i=1;
		foreach($zupd_values as $key=>$v)
        {
            $whr .="$key='$v'";
            if($i!=$len)
                $whr.=" and ";
            $i++;
        }
    }
    return $db->query("update `$table` set $val where $whr");
}

function qDelete($table,$where)
{
    global $db;
    if($where=="")
    	return 0;
    $len = count($where);
    $i=1;
    $whr = "";
	foreach($where as $key=>$v)
    {
        $whr .="$key='$v'";
        if($i!=$len)
            $whr.=" and ";
        $i++;
    }
    return $db->exec("delete from $table where $whr");
}

function closeConnection ($db){
	$db = NULL;
}

// Utility function to return json, given a keyed array
function jsonResponse($array) {
    header('Content-Type: application/json');
    return json_encode($array);
}

function unsetSession($arr){
    foreach ($arr as $k => $v) {
        unset($_SESSION[$v]);
    }
}


function encrypt_decrypt($action, $string)
{
    $output = false;
    //$encrypt_method = "AES-256-CBC";
    $encrypt_method = "CAST5-CBC";
    $secret_key = 'LegalRaastaCloud';
    $secret_iv = 'ItsHimanshuAndPulkitInitiative';

    // hash
    $key = hash('md5', $secret_key);

    // iv - encrypt method AES-256-CBC expects 16 bytes - else you will get a warning
    //$iv = substr(hash('sha256', $secret_iv), 0, 16);
    $iv = substr(hash('md5', $secret_iv), 0, 8);

    if( $action == 'encrypt' )
    {
        $output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
        $output = base64_encode($output);
    }
    else if( $action == 'decrypt' )
    {
        $output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
    }

    return $output;
}

function hash_pass($value)
{
    $one   = md5($value);
    $two   = crypt($one, "salt");
    $three = hash('md5', $one . "-" . $two);
    $id    = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 15);
    return $id;
}

    // class getData {
    //         private $form;

    //         function __construct($form) {
    //                 $this->form = $form;
    //         }

    //         function filter($var) {
    //                 return stripos($var['type'], $this->form) !== false;
    //         }
    // }

function getFormData($data, $form){
    // $temp = array();
    // $formArraykeys  = array_keys(array_column($data, 'type'), $form);
    // for ($i=0; $i < sizeof($formArraykeys); $i++) { 
    //     $index = $formArraykeys[$i];
    //     array_push($temp, $data[$index]);
    // }
    
    // Using oop concept(getData class)
    // $temp = array_values(array_filter($data, array(new getData($form), 'filter')));

    //using closure inside array_filter
    $temp = array_values(array_filter($data, function($var) use($form){ 
        return (stripos($var['type'], $form) !== false); 
    }));

    if (!empty($temp))
        return json_encode($temp);
    else
        return NULL;
}

function getUserIP()
{
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }

    return $ip;
}



?>