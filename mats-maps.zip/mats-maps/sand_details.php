<?php 
	include 'inc/header.php';
	include 'inc/db.php';

	if (isset($_GET['sand_id']) && $_GET['sand_id'] != '') {
		$sand_id = $_GET['sand_id'];
		$select_post   = "SELECT * FROM sand_posts WHERE id = '$sand_id'";
		$selected_post = $conn->query($select_post);
		if($selected_post->num_rows > 0){
			$row = $selected_post->fetch_assoc();
			    $address_build = $row['address_build'];
			    $region = $row['region'];
			    $postal_code = $row['postal_code'];
			    $volume = $row['volume'];
			    $type_of_sand = $row['type_of_sand'];
			    $trans_cost = $row['trans_cost'];
			    $price = $row['price'];
			    $date_avail = $row['date_avail'];
			    $post_image = $row['post_image'];
			
		}
	}else{
		header('location:/');
	}
?>
	<input type="hidden" class="sand_id" value="<?php echo $sand_id; ?>"/>
	<div class="modal fade" id="contact_sand_supplier" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Contact Supplier</h5>
                </div>
                <div class="modal-body">
                	<div class="row">
						<div class="col-md-12">
							<div class="alert-danger text-center" id="error_contact_sand" style="height:40px;background-color:#e66767;padding-top:10px;display:none">
							</div>
						</div>
					</div>
                    <div class="form-group label-floating bmd-form-group">
                		<label class="form-control-label bmd-label-floating" for="exampleInputTextarea">Contact Number</label>
                		<input type="text" class="form-control contact_number" onkeypress="return numbersonly(this,event)" placeholder="Your number on which supplier can contact you.">
                	</div>
                	<div class="form-group label-floating bmd-form-group">
	                    <label class="form-control-label bmd-label-floating">Write Your message Here (Optional)</label>
	                    <textarea class="form-control contact_msg" rows="5" placeholder="A message to supplier about required sand."></textarea>
	                </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" id="contact_sand_supply">Contact Supplier</button>
                </div>
            </div>
        </div>
    </div>

	<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	    <div class="container">
	        <div class="row title-row">
	            <div class="col-md-4 col-md-offset-8">
					<?php if(!empty($_SESSION['email'])){?>
						<button class="btn pull-right contact_supplier" style="background-color:#f39c12">
							Contact Supplier &nbsp;&nbsp;&nbsp;&nbsp;<i class="material-icons">contact_mail</i>
							<div class="ripple-container"></div>
						</button>
					<?php } ?>
	            </div>
	        </div>
	    </div>
	</div>
	<div class="section section-gray">
	    <div class="container">
	        <div class="main main-raised main-product">
	            <div class="row">
	                <div class="col-md-5">
	                	<div class="row">
	                		<div class="col-md-12 text-center">
	                			<img src="posts/<?php echo $post_image; ?>" style="margin-top:30px"/>
	                		</div>	
	                	</div>
	                	<div class="row" style="margin-top:-25px;">
	                		<div class="col-md-12">
	                			<center>
	                				<b>
	                					<h3><?php echo strtoupper($type_of_sand); ?></h3>
	                				</b>
	                			</center>
	                		</div>
	                	</div>
	                </div>
	                <div class="col-md-7" style="box-shadow:0px 0px 0px 1px #e0e0e0">
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">TYPE OF SAND</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p>
	                				<h4><?php echo strtoupper($type_of_sand); ?></h4>
	                			</p>
	                		</div>
	                	</div>
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">ADDRESS OF BUILDING</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p><h5><?php echo $address_build; ?></h5></p>
	                			<p><h5><?php echo $region; ?></h5></p>
	                			<p><h5><?php echo $postal_code; ?></h5></p>
	                		</div>
	                	</div>
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">VOLUME</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p><h5><?php echo $volume; ?>&nbsp&nbspcubic meter</h5></p>
	                		</div>
	                	</div>
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">TRANSPORT COST</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p><h5>€&nbsp<?php echo $trans_cost; ?></h5></p>
	                		</div>
	                	</div>
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">DATE OF AVALIABILITY</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p><h5><?php echo $date_avail; ?></h5></p>
	                		</div>
	                	</div>
	                	<div class="row" style="box-shadow:0px 1px 0px 0px #e0e0e0">
	                		<div class="col-md-12">
	                			<h4 style="margin-left:-10px;font-size:17px;font-weight:400;">PRICE</h4>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12">
	                			<p><h5>€&nbsp<?php echo $price; ?></h5></p>
	                		</div>
	                	</div>
	                	<div class="row">
	                		<div class="col-md-12 text-center">
		                		<?php if(!empty($_SESSION['email'])){?>
		                			<button class="btn contact_supplier" style="background-color:#f39c12">
		                				Contact Supplier &nbsp;&nbsp;&nbsp;&nbsp;<i class="material-icons">contact_mail</i>
		                				<div class="ripple-container"></div>
		                			</button>
		                		<?php }else { ?>
		                			<h4><p style="color:#0099ff;margin-bottom:20px;cursor:default;">Login / SignUp To Contact Supplier</p></h4>
		                		<?php } ?>
	                		</div>
	                	</div>
	                </div>
	            </div>
	        </div>
	    </div>
	</div>
<?php include 'inc/footer.php'; ?>

<script type="text/javascript">
	$(".contact_supplier").click(function(){
		$("#contact_sand_supplier").modal('show');
	});

	$("#contact_sand_supply").on('click',function(){
		var contact_number  = $('.contact_number').val();
		var contact_msg 	= $('.contact_msg').val();
		var sand_id			= $('.sand_id').val();

		if(contact_number != ""){
			var ref   = "email_contact_sand";
	    	$.ajax({
	    		url  	 : "ajax/common.php",
	    		type 	 : "POST",
	    		dataType : "JSON",
	    		data : {
	    			ref                  : ref,
	    			contact_number 		 : contact_number,
	    			contact_msg			 : contact_msg,
	    			sand_id				 : sand_id, 
	    		}
	    	}).done(function(res){
	    		if(res.success){
	   				$("#contact_sand_supplier").modal('toggel');
	   				show_success(res.msg);
	   				setTimeout(function(){
	   					hide_success();
	   				},4000);
	    		}else{
	    			$("#contact_sand_supplier").modal('toggel');
	   				show_error(res.msg);
	   				setTimeout(function(){
	   					hide_error();
	   				},2000);
	    		}
	    	});
		}else{
			$("#error_contact_sand").show();
			$("#error_contact_sand").html("<center>Please Fill Your Contact Number</center>");
			$('.contact_number').focus();
			setTimeout(function(){
				$("#error_contact_sand").hide();
			},4000);
		}
	});
</script>