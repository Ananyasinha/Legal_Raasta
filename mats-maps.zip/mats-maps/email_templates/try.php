'<div class="mail">
      <div class="mailTemp">
         <table width="100%" bgcolor="#f2f2f2" cellpadding="0" cellspacing="0" border="0" style="background-color:#f2f2f2;width:100%!important;line-height:100%!important;border-collapse:collapse;margin:0;padding:0">
            <tbody>
               <tr>
                  <td style="border-collapse:collapse">
                     <table width="542" bgcolor="#5bbc2e" cellpadding="0" cellspacing="0" border="0" align="center" style="background-color:#ff793f;display:block;border-collapse:collapse">
                        <tbody style="display:table;width:100%">
                           <tr>
                              <td style="border-collapse:collapse">
                                 <table width="100%" cellpadding="0" cellspacing="0" border="0" align="center" style="border-collapse:collapse">
                                    <tbody>
                                       <tr>
                                          <td valign="middle" width="100%" align="center" style="border-collapse:collapse;padding:20px 0">
                                             <div class="m_-5574203305000109844imgpop">
                                                <a href="http://matmaps.be">
                                                <img src="http://matmaps.be/assets/img/fulllogo.png" alt="Upwork" width="101" height="39" border="0" style="display:block;outline:none;text-decoration:none;border:none">
                                                </a>
                                             </div>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
      <div class="m_-5574203305000109844block">
         <table width="100%" bgcolor="#f2f2f2" cellpadding="0" cellspacing="0" border="0" id="m_-5574203305000109844backgroundTable" style="background-color:#f2f2f2;width:100%!important;line-height:100%!important;border-collapse:collapse;margin:0;padding:0">
            <tbody>
               <tr>
                  <td style="border-collapse:collapse">
                     <table bgcolor="#ffffff" width="542" align="center" cellspacing="0" cellpadding="0" border="0" class="m_-5574203305000109844devicewidth" style="background-color:#ffffff;border-collapse:collapse">
                        <tbody>
                           <tr>
                              <td>
                                 <table width="502" align="center" cellspacing="0" cellpadding="0" border="0" class="m_-5574203305000109844devicewidthinner" style="border-collapse:collapse">
                                    <tbody style="border-collapse:collapse">
                                       <tr>
                                          <td width="100%" height="30" style="border-collapse:collapse"></td>
                                       </tr>
                                       <tr>
                                          <td style="font-family:Helvetica,arial,sans-serif;font-size:14.5px;color:#666666;text-align:left;line-height:20px;border-collapse:collapse">
                                             <table width="100%" align="center" cellspacing="0" cellpadding="0" border="0" class="m_-5574203305000109844devicewidthinner" style="border-collapse:collapse">
                                                <tbody>
                                                   <tr>
                                                      <td style="font-family:Helvetica;font-size:24px;color:#494949;text-align:left;line-height:20px;font-weight:bold;border-collapse:collapse" align="left">
                                                         Hi '.$supply_name.',
                                                      </td>
                                                   </tr>
                                                   <tr>
                                                      <td width="100%" height="40" style="border-collapse:collapse"></td>
                                                   </tr>
                                                   <tr>
                                                      <td style="font-family:Helvetica,arial,sans-serif;font-size:14.5px;color:#666666;text-align:left;line-height:20px;border-collapse:collapse" align="left">
                                                         <b>"'.$firstname.' '.$lastname.'"</b> just shown interest in your <b>"'.$type_of_sand.'"</b> sand present at <b>"'.$address_build.' '.$region.' '.$postal_code.'"</b> address.<br>You can directly contact <b>'.$firstname.' '.$lastname.'</b> on below provided contact number.
                                                      </td>
                                                   </tr>
                                                   <tr style="height:50px">
                                                      <td></td>
                                                   </tr>
                                                   <tr>
                                                      <td style="font-family:Helvetica,arial,sans-serif;font-size:14.5px;color:#666666;text-align:left;line-height:20px;border-collapse:collapse" align="left">
                                                         Name : <b>'.$firstname.' '.$lastname.'</b><br>
                                                         Contact Number : <b>'.$contact_number'</b><br>
                                                         Message : <b>'.$contact_msg.'</b>
                                                      </td>
                                                   </tr>
                                                   <tr>
                                                      <td width="100%" height="40" style="border-collapse:collapse"></td>
                                                   </tr>
                                                   <tr>
                                                      <td style="font-family:Helvetica,arial,sans-serif;font-size:14.5px;color:#666666;text-align:left;line-height:20px;border-collapse:collapse" align="left">
                                                         Thanks,<br>
                                                         Mat&Maps support
                                                      </td>
                                                   </tr>
                                                </tbody>
                                             </table>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td width="100%" height="40" style="border-collapse:collapse"></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </td>
                           </tr>
                        </tbody>
                     </table>
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
   </div>