<?php include 'inc/header.php'; ?>
	<div class="page-header header-filter" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
	    	<div class="container" style="padding-top: 180px">
				<div class="row">
	    			<div class="col-md-10 col-md-offset-1">
						<div class="card card-signup">
	                        <h2 class="card-title text-center">Contactez nous</h2>
	                        <div class="row">
	                            <div class="col-md-10 col-md-offset-1">
	                            		<div id="error_register" class="alert alert-dismissible" style="margin-bottom: 50px"></div>
										<div class="card-content" style="margin-top:-62px">
											<div class="row">
												<div class="col-md-6">
													<div class="input-group">
														<span class="input-group-addon">
															<i class="material-icons" style="margin-top:12px">face</i>
														</span>
														<input type="text" class="form-control firstname reg-details" placeholder="Prénom">
													</div>
												</div>
												<div class="col-md-6">
													<input type="text" class="form-control lastname reg-details" placeholder="Nom de famille">
												</div>
											</div>

											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">email</i>
												</span>
												<input type="text" class="form-control email reg-details" placeholder="EMAIL">
											</div>

											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">lock_outline</i>
												</span>
												<input type="text" placeholder="Sujet" class="form-control subject reg-details" />
											</div>
											
											<div class="input-group">
												<span class="input-group-addon">
													<i class="material-icons" style="margin-top:12px">lock_outline</i>
												</span>
												<textarea placeholder="Votre message" class="form-control message reg-details" ></textarea>
											</div>
											
											</div>
										</div>
										<div class="footer text-center">
											<a class="btn btn-primary btn-round" id="contact">Envoyer</a>
										</div>
	                            </div>
	                        </div>
	                	</div>
	                </div>
<?php include 'inc/footer.php'; ?>