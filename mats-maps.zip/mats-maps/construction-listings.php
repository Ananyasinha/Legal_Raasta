<?php 
    include 'inc/header.php'; 
    include 'inc/db.php';
?>

<div class="page-header header-filter" data-parallax="true" filter-color="orange" style="background-image: url('assets/img/wall1.jpg'); background-size: cover; background-position: top center;">
</div>
<div class="section section-gray">
    <div class="container-fluid">
        <div class="main main-raised main-product">
            <div class="row" style="margin-top:-20px;margin-bottom:25px">
                <div class="col-md-12 text-center">
                    <h3 style="font-weight:600">VIEW ALL DEALS</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="row">
                        <?php
                            $select_posts   = "SELECT * FROM construction ORDER BY id DESC";
                            $selected_posts = $conn->query($select_posts);
                            if($selected_posts->num_rows != 0){   
                                $i = 0;
                                while($row = $selected_posts->fetch_assoc()){
                                    
                        ?>          
                                    <div class="col-md-3" style="box-shadow:0px 0px 1px 1px #e0e0e0;">
                                        <div class="card-image" style="box-shadow:0px 0px 1px 1px #000;border-radius:20px 20px 20px 20px;overflow:hidden;margin-top:20px">
                                            <?php if(!empty($row['good_image'])){ ?>
                                                <img src="<?php echo "construction/".$row['good_image'];?>" alt="<?php echo $row['type_of_sand'];?>" style="width:300px;height:250px"/>
                                            <?php }else{ ?>
                                                <img src="assets/img/sandicon.png" alt="<?php echo $row['type_of_sand'];?>" style="width:300px;height:250px"/>
                                            <?php } ?>    
                                        </div>
                                        <div class="card-content">
                                            <h4 class="card-title text-center" style="cursor: pointer"><?php echo strtoupper($row['type_of_good']);?></h4>
                                            <p class="description">
                                                <b>ADDRESS :</b> <?php echo ucfirst($row['address']).' '.ucfirst($row['region']).' '.ucfirst($row['postal_code']); ?>
                                                
                                            </p>
                                            <div class="footer">
                                                <p class="description">
                                                    <b>PRICE :</b>  &euro; <?php echo $row['price'];?>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                        <?php
                                } 
                            }else {
                        ?>
                            <div class="col-md-12">
                                <center style="margin-top:40px;"><img src="assets/img/not_found.png"></center>
                                <center><h3 style="margin-left:-40px">No Deal Found</h3></center>
                            </div>
                        <?php } ?>
                    </div>    
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>